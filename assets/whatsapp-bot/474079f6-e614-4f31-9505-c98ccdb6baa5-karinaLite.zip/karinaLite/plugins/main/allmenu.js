import config from '../../config.js'
import { pluginStore } from '../../src/plugins.js'
import { createFakeQuoted, _mCtx } from '../../src/lib/ctx.js'

// Fungsi konversi teks ke font aesthetic (mathematical sans-serif bold)
function toAestheticFont(str) {
  const map = {
    a: '𝗮', b: '𝗯', c: '𝗰', d: '𝗱', e: '𝗲', f: '𝗳', g: '𝗴', h: '𝗵',
    i: '𝗶', j: '𝗷', k: '𝗸', l: '𝗹', m: '𝗺', n: '𝗻', o: '𝗼', p: '𝗽',
    q: '𝗾', r: '𝗿', s: '𝘀', t: '𝘁', u: '𝘂', v: '𝘃', w: '𝘄', x: '𝘅',
    y: '𝘆', z: '𝘇',
    A: '𝗔', B: '𝗕', C: '𝗖', D: '𝗗', E: '𝗘', F: '𝗙', G: '𝗚', H: '𝗛',
    I: '𝗜', J: '𝗝', K: '𝗞', L: '𝗟', M: '𝗠', N: '𝗡', O: '𝗢', P: '𝗣',
    Q: '𝗤', R: '𝗥', S: '𝗦', T: '𝗧', U: '𝗨', V: '𝗩', W: '𝗪', X: '𝗫',
    Y: '𝗬', Z: '𝗭'
  }
  return str.replace(/[a-zA-Z]/g, c => map[c] || c)
}

export const config_ = {
  name: 'allmsnu',
  alias: ['allmenu', 'semuamenu'],
  category: 'main',
  description: 'Menampilkan daftar command',
  usage: '.menu',
  example: '.menu',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  prefix:    false,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock, isOwner, isPremium }) {
  const categories = {}
  const seen = new Set()

  for (const [key, plugin] of pluginStore.entries()) {
    const cfg = plugin.config
    if (cfg.name !== key) continue
    if (seen.has(cfg.name)) continue
    seen.add(cfg.name)

    const cat = cfg.category || 'other'
    if (!categories[cat]) categories[cat] = []
    categories[cat].push(cfg)
  }

  const prefix = Array.isArray(config.command?.prefix)
    ? config.command.prefix[0]
    : config.command?.prefix || '.'

  const now = new Date()
  const timeStr = now.toLocaleTimeString('id-ID', { hour12: false })
  const dateStr = now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })

  let menuText = ''

  // Header dekoratif
  menuText += ` ⁠ ⁠   ֪ ⁠  ⡞⠉⠓⢦⣀⣀⣀⡴⠊⠉⢦ 
  ⁠   ⁠  ⡇  ⁠ ⁠  ⢈⣽⣿⠉⣿⣏  ⁠   ⣸ ֪ 
 ⁠  ⁠     ⠹⠤⢴⠞⢹⠿⡍⠳⡦⠴⠏ ⁺ִ 𝖼⃘𐑋‎ 𝗌𝖾𝖾 𝗍𝗁𝖾 *𝗅𝗂𝗌𝗍* 𝖻𝗎𝖻𝖻𝗒
 ⁠  ⁠   ⁠   ⁠  ⁠  ֪ ⣃⡀⡏ ⁠   ⢷⢀⣹ ⁠  ֪  ⁠  *내 사정 내 사랑* 🎀 ₊˚⊹ 
 ⁠  ⁠  ⁠    ⁠ ⁠    ⁠  ⁠ ⠛⠁  ⁠  ⠘⠋
˒˓ 𝝑᭪݁ 𝗁𝖺𝗒𝗂𝗂𝖾 𝗐𝖾𝗅𝖼𝗈𝗆𝖾─𝖼𝗎𝗍𝗍𝗂𝖾'𝗌 ៸៸ 𓄼.🌷
━┽ ꤥ‌ ⸼ 𝖺꯭𝖽𝗈꯭𝗋꯭𝖺𝖻𝗅𝖾'𝗌 𝖻𝖾𝖺𝗎𝗍𝗂𝖿𝗎𝗅 *𝗅𝗂𝗌𝗍* ׂ 𓈒 ⸙ 

 ⁠  ⁠ 𐔌 ࣪˖⁩ ⸙ 𝗎𝗌𝖾𝗋 ⦂ @${m.pushName || 'user'}
 ⁠  ⁠ 𐔌 ࣪˖⁩ ⸙ 𝗍𝗂𝗆𝖾 ⦂ ${timeStr}
 ⁠  ⁠ 𐔌 ࣪˖⁩ ⸙ 𝖽𝖺𝗍𝖾 ⦂ ${dateStr}

`

  // Urutan kategori
  const order = ['main', 'user', 'group', 'owner', 'maker', 'tools', 'downloader', 'fun']
  const catList = [
    ...order.filter(c => categories[c]),
    ...Object.keys(categories).filter(c => !order.includes(c)).sort()
  ]

  for (const cat of catList) {
    const plugins = categories[cat]
    if (!plugins?.length) continue

    const catName = toAestheticFont(cat.charAt(0).toUpperCase() + cat.slice(1))
    menuText += `╭┅ 🩰 𝅄 ꞌꞋ𝓜𝗲𝗻𝘂 ${catName} ꘓꘓ ˒˓\n`

    for (const p of plugins) {
      menuText += `┃ ප  ${p.name}\n`
    }
    menuText += `╰╍ ··⊹ ·· ┄ · 🍄 · ┄ · ⊹┄ ·· 𑣿 ׁ⸼\n\n`
  }

  // Footer dekoratif
  menuText += ` ⁠  ⋮ ៸៸ 𓄼🪷 *𝖼𝗎𝗍𝗍𝗂𝖾'𝗌 𝗇𝗈𝗍𝖾* !! 𖥻 ࣪ ִֶָ
 ⁠  ִֶָ 𐀔 𝗄𝗍𝗂𝗄 ${prefix}<command> 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗇𝗀𝗀𝗎𝗇𝖺𝗄𝖺𝗇
 ⁠  ִֶָ 𐀔 𝗉𝗋𝖾𝖿𝗂𝗑 𝗒𝖺𝗇𝗀 𝗍𝖾𝗋𝗌𝖾𝖽𝗂𝖺 ⦂ ${prefix}
   ִֶָ 𐀔 𝗈𝗐𝗇𝖾𝗋 ⦂ ${config.owner.name}
 ⁠  ִֶָ 𐀔 𝖻𝗈𝗍 ⦂ ${config.bot.name} v${config.bot.version}
`

  await sock.sendMessage(
    m.chat,
    { text: menuText, contextInfo: _mCtx(m.sender) },
    { quoted: createFakeQuoted() }
  )
}