import { writeErrorLog, analyzeAndFix, getGroqKeyStats } from './file-manager.js'
import { notifyError } from '../lib/telegram-notify.js'
import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import logger from '../lib/logger.js'

const INTERCEPTOR_CONFIG = {
  autoAnalyze:         true,
  analyzeDebounceMs:   5000,
  maxPendingErrors:    10,
  notifyOnCritical:    true,
  exitOnUncaught:      false,
  ignoredMessages: [
    'write EOF',
    'ECONNRESET',
    'EPIPE',
    'ETIMEDOUT',
    'ENOTFOUND',
    'ECONNREFUSED',
    'EHOSTUNREACH',
    'EADDRINUSE',
  ],
  ignoredSources: [
    'Baileys',
    'pino',
  ],
}

const STATS = {
  totalErrors:       0,
  totalIgnored:      0,
  totalAnalyzed:     0,
  totalFixed:        0,
  totalFailed:       0,
  lastAnalysis:      null,
  lastFixSuccess:    null,
  criticalErrors:    0,
}

let _analyzeTimer   = null
let _pendingErrors  = []
let _initialized    = false
let _analyzing      = false

function shouldIgnore(error) {
  const msg = error?.message ?? String(error)

  for (const pattern of INTERCEPTOR_CONFIG.ignoredMessages) {
    if (msg.includes(pattern) || error?.code === pattern) {
      return true
    }
  }

  const stack = error?.stack ?? ''
  for (const src of INTERCEPTOR_CONFIG.ignoredSources) {
    if (stack.includes(src)) return true
  }

  return false
}

function isCritical(error) {
  const msg = error?.message ?? String(error)
  const CRITICAL_KEYWORDS = [
    'cannot find module',
    'syntaxerror',
    'referenceerror',
    'fatal',
    'crash',
    'database',
  ]
  const lower = msg.toLowerCase()
  return CRITICAL_KEYWORDS.some(kw => lower.includes(kw))
}

async function scheduleAnalysis() {
  if (!INTERCEPTOR_CONFIG.autoAnalyze) return
  if (_analyzing) {
    logger.debug('ERROR-INTERCEPTOR', 'Analysis already running, skipping...')
    return
  }

  if (_analyzeTimer) clearTimeout(_analyzeTimer)

  _analyzeTimer = setTimeout(async () => {
    _analyzeTimer = null

    if (_pendingErrors.length === 0) return

    const count = _pendingErrors.length
    const hasCritical = _pendingErrors.some(e => e.critical)

    logger.info('ERROR-INTERCEPTOR', `${count} error(s) queued${hasCritical ? ' (CRITICAL)' : ''} — analyzing...`)

    _analyzing = true
    _pendingErrors = []
    STATS.totalAnalyzed++
    STATS.lastAnalysis = new Date().toISOString()

    try {
      const result = await analyzeAndFix({ verbose: true, dryRun: false })

      if (result.success) {
        const fixed = (result.patchResults ?? []).filter(r => r.success).length

        if (fixed > 0) {
          STATS.totalFixed += fixed
          STATS.lastFixSuccess = new Date().toISOString()
          logger.success('ERROR-INTERCEPTOR', `✓ Auto-fixed ${fixed} file(s)`)

          if (INTERCEPTOR_CONFIG.notifyOnCritical && hasCritical) {
            await notifyError(
              'AUTO-FIX',
              `${fixed} file(s) berhasil diperbaiki oleh AI.\n${result.analysis?.summary || '-'}`,
              ''
            ).catch(() => {})
          }
        } else {
          logger.info('ERROR-INTERCEPTOR', `Analysis completed — no patches applied (low confidence or LOG_ONLY)`)
        }

        const keyStats = getGroqKeyStats()
        const availableKeys = keyStats.filter(k => k.available).length
        if (availableKeys === 0) {
          logger.warn('ERROR-INTERCEPTOR', '⚠️ Semua Groq key sedang rate-limited atau failed!')
        }
      } else {
        STATS.totalFailed++
        logger.error('ERROR-INTERCEPTOR', `Analysis failed: ${result.error}`)

        if (INTERCEPTOR_CONFIG.notifyOnCritical && hasCritical) {
          await notifyError(
            'AUTO-FIX FAILED',
            `AI gagal memperbaiki error: ${result.error}`,
            ''
          ).catch(() => {})
        }
      }
    } catch (err) {
      STATS.totalFailed++
      logger.error('ERROR-INTERCEPTOR', `Analysis exception: ${err.message}`)

      if (INTERCEPTOR_CONFIG.notifyOnCritical && hasCritical) {
        await notifyError(
          'AUTO-FIX CRASH',
          `Exception saat auto-fix: ${err.message}`,
          err.stack || ''
        ).catch(() => {})
      }
    } finally {
      _analyzing = false
    }
  }, INTERCEPTOR_CONFIG.analyzeDebounceMs)
}

function captureError(source, error) {
  if (shouldIgnore(error)) {
    STATS.totalIgnored++
    return
  }

  STATS.totalErrors++
  const critical = isCritical(error)

  if (critical) {
    STATS.criticalErrors++
    logger.error('ERROR-INTERCEPTOR', `🔴 CRITICAL: ${error.message}`)
  }

  writeErrorLog(source, error)

  if (_pendingErrors.length >= INTERCEPTOR_CONFIG.maxPendingErrors) {
    logger.warn('ERROR-INTERCEPTOR', `Max pending errors (${INTERCEPTOR_CONFIG.maxPendingErrors}) reached — dropping oldest`)
    _pendingErrors.shift()
  }

  _pendingErrors.push({ source, error, critical, timestamp: Date.now() })
  scheduleAnalysis()
}

export function setupErrorInterceptor(options = {}) {
  if (_initialized) {
    logger.warn('ERROR-INTERCEPTOR', 'Already initialized — skipping')
    return
  }
  _initialized = true

  Object.assign(INTERCEPTOR_CONFIG, options)

  const LOGS_DIR = join(process.cwd(), 'storage', 'logs')
  mkdir(LOGS_DIR, { recursive: true }).catch(() => {})

  process.on('uncaughtException', (error, origin) => {
    logger.error('CRASH', `Uncaught exception (${origin}): ${error.message}`)
    
    if (error.stack) {
      const stack = error.stack.split('\n').slice(0, 5).join('\n')
      logger.error('CRASH', stack)
    }

    captureError('uncaughtException', error)

    if (INTERCEPTOR_CONFIG.exitOnUncaught) {
      logger.error('CRASH', 'Exiting process in 3 seconds...')
      setTimeout(() => process.exit(1), 3000)
    } else {
      logger.warn('CRASH', 'exitOnUncaught=false — process continues (dangerous!)')
    }
  })

  process.on('unhandledRejection', (reason, promise) => {
    const error = reason instanceof Error ? reason : new Error(String(reason))
    logger.error('REJECTION', `Unhandled promise rejection: ${error.message}`)
    
    if (error.stack) {
      const stack = error.stack.split('\n').slice(0, 5).join('\n')
      logger.error('REJECTION', stack)
    }

    captureError('unhandledRejection', error)
  })

  process.on('warning', (warning) => {
    if (warning.name === 'DeprecationWarning') return
    logger.warn('WARNING', `${warning.name}: ${warning.message}`)
  })

  logger.success('ERROR-INTERCEPTOR', 'Initialized — auto-analyze enabled')
  logger.info('ERROR-INTERCEPTOR', `Config: debounce=${INTERCEPTOR_CONFIG.analyzeDebounceMs}ms, maxPending=${INTERCEPTOR_CONFIG.maxPendingErrors}`)
}

export async function runManualAnalysis(options = {}) {
  logger.info('ERROR-INTERCEPTOR', 'Running manual analysis...')
  
  try {
    const result = await analyzeAndFix({ verbose: true, ...options })
    
    if (result.success) {
      const fixed = (result.patchResults ?? []).filter(r => r.success).length
      logger.success('ERROR-INTERCEPTOR', `Manual analysis done — ${fixed} file(s) fixed`)
      return result
    } else {
      logger.error('ERROR-INTERCEPTOR', `Manual analysis failed: ${result.error}`)
      return result
    }
  } catch (err) {
    logger.error('ERROR-INTERCEPTOR', `Manual analysis exception: ${err.message}`)
    throw err
  }
}

export function withErrorCapture(source, fn) {
  return async (...args) => {
    try {
      return await fn(...args)
    } catch (err) {
      captureError(source, err)
      throw err
    }
  }
}

export function getInterceptorStats() {
  return {
    ...STATS,
    pendingCount: _pendingErrors.length,
    isAnalyzing: _analyzing,
    config: { ...INTERCEPTOR_CONFIG },
  }
}

export function clearPendingErrors() {
  const count = _pendingErrors.length
  _pendingErrors = []
  logger.info('ERROR-INTERCEPTOR', `Cleared ${count} pending error(s)`)
  return count
}

export function triggerImmediateAnalysis() {
  if (_analyzeTimer) clearTimeout(_analyzeTimer)
  scheduleAnalysis()
}

export default {
  setupErrorInterceptor,
  runManualAnalysis,
  withErrorCapture,
  getInterceptorStats,
  clearPendingErrors,
  triggerImmediateAnalysis,
}