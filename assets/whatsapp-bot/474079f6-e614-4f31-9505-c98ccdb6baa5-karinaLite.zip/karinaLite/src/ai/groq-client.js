import axios from 'axios'
import config from '../../config.js'
import logger from '../lib/logger.js'

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'

const KEY_COOLDOWN_MS = 60_000   // 1 menit jika kena 429
const REQUEST_TIMEOUT = 12_000   // 12 detik
const RATE_LIMIT_MS   = 1_000    // jeda minimum antar request global

let currentKeyIdx   = 0
let currentModelIdx = 0
let lastCallTime    = 0

const keyCooldown = new Map()      // idx → timestamp sampai kapan key tidak boleh dipakai

function getActiveKey() {
  const keys = config.groq.keys
  if (!keys || keys.length === 0) throw new Error('Tidak ada Groq API key yang dikonfigurasi')

  const now = Date.now()
  // cari key yang tidak dalam cooldown
  for (let i = 0; i < keys.length; i++) {
    const idx      = (currentKeyIdx + i) % keys.length
    const cooldown = keyCooldown.get(idx) || 0
    if (now >= cooldown) {
      currentKeyIdx = idx
      return { key: keys[idx], idx }
    }
  }

  // semua key cooldown → cari yang cooldownnya paling dekat
  let minCooldown = Infinity
  let minIdx = 0
  for (const [idx, ts] of keyCooldown.entries()) {
    if (ts < minCooldown) { minCooldown = ts; minIdx = idx }
  }
  const waitMs = Math.max(0, minCooldown - now)
  logger.warn('GROQ-CLIENT', `Semua key cooldown, tunggu ${(waitMs / 1000).toFixed(1)}s...`)
  return { key: keys[minIdx], idx: minIdx, waitMs }
}

function markKeyCooldown(idx) {
  keyCooldown.set(idx, Date.now() + KEY_COOLDOWN_MS)
  logger.warn('GROQ-CLIENT', `Key #${idx + 1} rate-limited, cooldown 60s`)
  // pindah ke key berikutnya
  currentKeyIdx = (idx + 1) % config.groq.keys.length
}

function rotateKey() {
  currentKeyIdx = (currentKeyIdx + 1) % config.groq.keys.length
}

function getCurrentModel() {
  const models = config.groq.fallbackModels || ['llama-3.3-70b-versatile']
  return models[currentModelIdx] || models[0]
}

function fallbackModel() {
  const models = config.groq.fallbackModels || ['llama-3.3-70b-versatile']
  if (currentModelIdx < models.length - 1) {
    currentModelIdx++
    logger.warn('GROQ-CLIENT', `Switch model → ${models[currentModelIdx]}`)
    return true
  }
  logger.error('GROQ-CLIENT', 'Semua model sudah dicoba')
  return false
}

function resetModel() {
  if (currentModelIdx !== 0) currentModelIdx = 0
}

export async function chatCompletion(messages, {
  model,
  temperature = 0.7,
  maxTokens  = 1024,
  jsonMode   = false,
  signal     = null
} = {}) {
  const maxAttempts = config.groq.keys.length * (config.groq.fallbackModels?.length || 1) + 2
  let attempt = 0

  while (attempt < maxAttempts) {
    attempt++
    const { key, idx, waitMs } = getActiveKey()
    if (waitMs) await new Promise(r => setTimeout(r, waitMs))

    // rate limiting global
    const now = Date.now()
    const wait = RATE_LIMIT_MS - (now - lastCallTime)
    if (wait > 0) await new Promise(r => setTimeout(r, wait))
    lastCallTime = Date.now()

    const selectedModel = model || getCurrentModel()
    const payload = {
      model: selectedModel,
      temperature,
      max_tokens: maxTokens,
      messages,
    }
    if (jsonMode) payload.response_format = { type: 'json_object' }

    try {
      const res = await axios.post(GROQ_URL, payload, {
        headers: {
          Authorization: `Bearer ${key}`,
          'Content-Type': 'application/json',
        },
        timeout: REQUEST_TIMEOUT,
        signal,
      })

      const raw = res.data?.choices?.[0]?.message?.content
      if (!raw) throw new Error('Respons kosong dari Groq')

      // sukses → rotate key dan reset model
      rotateKey()
      resetModel()
      return raw

    } catch (err) {
      const status = err.response?.status
      if (status === 429) {
        markKeyCooldown(idx)
        continue
      }
      if (status === 401) {
        logger.error('GROQ-CLIENT', `Key #${idx + 1} invalid (401), di-skip permanen sesi ini`)
        keyCooldown.set(idx, Date.now() + 24 * 60 * 60 * 1000)
        continue
      }
      if (status === 400 && !jsonMode && !model) {
        // coba fallback model
        if (fallbackModel()) continue
      }
      if (!status || status >= 500) {
        await new Promise(r => setTimeout(r, 1500))
        continue
      }
      throw err
    }
  }
  throw new Error('Semua percobaan ke Groq gagal')
}

export function getStatus() {
  const now = Date.now()
  return {
    activeModel:  getCurrentModel(),
    modelIdx:     currentModelIdx,
    activeKeyIdx: currentKeyIdx,
    keys: config.groq.keys.map((_, i) => ({
      index:    i + 1,
      cooldown: keyCooldown.has(i)
        ? Math.max(0, Math.ceil((keyCooldown.get(i) - now) / 1000)) + 's'
        : 'ready',
    })),
  }
}