import { chatCompletion } from '../groq-client.js'
import { getDatabase } from '../../database.js'
import { AIRich } from '../../lib/_build-m.js'
import { createFakeQuoted, _mCtx } from '../../lib/ctx.js'
import { toAestheticFont } from '../../lib/text-formater.js'
import { buildStoreContext, buildUserOrderContext } from './cs-store-context.js'
import { parseIntent } from './cs-intent-parser.js'
import { getHistory, pushHistory } from './cs-session.js'
import config from '../../../config.js'

const SYSTEM_PROMPT = (storeCtx) => `
Kamu adalah asisten customer service WhatsApp untuk toko online bernama ${config.bot?.name || 'Bot'}.
Bahasa: Bahasa Indonesia yang santai namun sopan.

${storeCtx}

=== ATURAN OUTPUT ===
Output HARUS **JSON murni**, tanpa teks lain, tanpa markdown fence, tanpa komentar.
Hanya keluarkan satu objek JSON dengan schema berikut:

{
  "intent": "chat" | "show_products" | "show_order" | "show_table" | "show_stats",
  "text": "teks utama jawaban kamu (bisa berisi markdown ringan)",
  "tip": "tips singkat atau null",
  "products": [
    {
      "title": "nama produk",
      "brand": "nama kategori",
      "price": "harga formatted (contoh: Rp 10.000)",
      "sale_price": "harga diskon atau null",
      "image_url": "",
      "product_url": "wa.me command: .buy <key>/<id>"
    }
  ],
  "table": {
    "headers": ["Kolom1", "Kolom2"],
    "rows": [["data1", "data2"]]
  },
  "suggests": ["pertanyaan lanjutan 1", "pertanyaan lanjutan 2", "pertanyaan lanjutan 3"]
}

=== ATURAN TAMBAHAN ===
- JANGAN PERNAH menambahkan teks di luar JSON.
- JANGAN PERNAH membungkus JSON dalam \`\`\`json ... \`\`\`.
- Jika tidak ada produk, produk array kosong [].
- Jika tidak ada tabel, table = null.
- Jika tidak ada tips, tip = null.
- suggests selalu diisi 3 pertanyaan relevan.
- Format harga selalu Rp xxx.xxx (contoh: Rp 10.000).
- Berikan saran command bot yang relevan (contoh: .buy netflix/1, .myorder, .list).
`.trim()

function isCSEnabled(m, db) {
  if (!m.isGroup) {
    return db.setting('cs_ai_private') !== false
  }
  const group = db.getGroup(m.chat)
  return group?.cs_ai === true
}

function isBotMentioned(m, sock) {
  const botJid = sock.user?.id || ''
  if (!botJid) return false
  if (m.mentionedJid?.includes(botJid)) return true
  const quotedSender = m.quoted?.sender || m.quoted?.key?.participant
  if (quotedSender && quotedSender === botJid) return true
  if (m.quoted && m.quoted.key?.remoteJid === m.chat) return true
  return false
}

export async function handleCSAI(m, sock) {
  const db = getDatabase()
  if (!isCSEnabled(m, db)) return false
  if (m.isCommand) return false
  if (!m.body?.trim()) return false
  if (!isBotMentioned(m, sock)) {
    if (m.isGroup) return false
  }

  const userId = m.senderNumber
  const question = m.body.replace(/@\d+/g, '').trim()
  if (!question) return false

  const storeCtx = buildStoreContext()
  const orderCtx = buildUserOrderContext(userId)
  const history = getHistory(userId)

  const messages = [
    {
      role: 'system',
      content: SYSTEM_PROMPT(storeCtx) + `\n\nRiwayat order user ini:\n${orderCtx}`,
    },
    ...history,
    { role: 'user', content: question },
  ]

  try {
    await m.react('⏳')
    const raw = await chatCompletion(messages, { maxTokens: 1500, temperature: 0.6 })
    const intent = parseIntent(raw)
    pushHistory(userId, 'user', question)
    pushHistory(userId, 'assistant', intent.text || raw)
    await renderCSResponse(m, sock, intent)
    await m.react('✅')
    return true
  } catch (err) {
    await m.react('❌')
    await m.reply(`Maaf, asisten sedang tidak tersedia. Coba lagi ya! 🙏`)
    console.error('[CS-AI]', err.message)
    return true
  }
}

async function renderCSResponse(m, sock, intent) {
  const bf = t => String(t).split('').map(c => ({
    a:'𝗮',b:'𝗯',c:'𝗰',d:'𝗱',e:'𝗲',f:'𝗳',g:'𝗴',h:'𝗵',i:'𝗶',j:'𝗷',k:'𝗸',l:'𝗹',m:'𝗺',
    n:'𝗻',o:'𝗼',p:'𝗽',q:'𝗾',r:'𝗿',s:'𝘀',t:'𝘁',u:'𝘂',v:'𝘃',w:'𝘄',x:'𝘅',y:'𝘆',z:'𝘇',
    A:'𝗔',B:'𝗕',C:'𝗖',D:'𝗗',E:'𝗘',F:'𝗙',G:'𝗚',H:'𝗛',I:'𝗜',J:'𝗝',K:'𝗞',L:'𝗟',M:'𝗠',
    N:'𝗡',O:'𝗢',P:'𝗣',Q:'𝗤',R:'𝗥',S:'𝗦',T:'𝗧',U:'𝗨',V:'𝗩',W:'𝗪',X:'𝗫',Y:'𝗬',Z:'𝗭',
  }[c] ?? c)).join('')

  let safeText = intent.text || ''
  if (/^\{/.test(safeText.trim()) && /^\s*\{/.test(safeText.trim())) {
    safeText = 'Maaf, saya mengalami kendala teknis. Silakan coba lagi ya! 🙏'
  }

  const builder = new AIRich(sock)
    .setTitle(`${bf('CS')} ${config.bot?.name || 'Bot'} 🤖`)
    .setSubtitle(toAestheticFont('customer service'))
    .setContextInfo({ ..._mCtx(m.sender) })

  if (safeText) {
    builder.addText(safeText)
  }

  const products = intent.products.map(p => ({
    title: p.title,
    brand: p.brand || '',
    price: p.price || '',
    sale_price: p.sale_price || undefined,
    image_url: config.assets?.storeProductImage || 'https://files.catbox.moe/bkgro8.jpeg',
    product_url: p.product_url || '',
  }))

  if (products.length > 0) {
    builder.addProduct(products)
  }

  if (intent.table?.headers?.length && intent.table?.rows?.length) {
    builder.addTable([intent.table.headers, ...intent.table.rows])
  }

  if (intent.tip) {
    builder.addTip(`💡 ${intent.tip}`)
  }

  if (intent.suggests?.length) {
    builder.addSuggest(intent.suggests.slice(0, 4))
  }

  await builder.send(m.chat, { quoted: m.raw })
}