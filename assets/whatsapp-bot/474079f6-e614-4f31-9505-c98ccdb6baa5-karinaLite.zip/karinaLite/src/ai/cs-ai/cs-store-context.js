import { getAllCategories, getOrders, getStoreStats } from '../../lib/store-db.js'
import { fmtPrice } from '../../lib/math.js'
export function buildStoreContext() {
  const cats   = getAllCategories()
  const stats  = getStoreStats()
  const lines  = []

  lines.push('=== KATALOG PRODUK ===')
  for (const [key, cat] of Object.entries(cats)) {
    if (!cat.visible) continue
    lines.push(`\n[${cat.emoji} ${cat.name}] (key: ${key})`)
    if (cat.description) lines.push(`  Deskripsi: ${cat.description}`)
    lines.push(`  Items:`)
    for (const item of (cat.items || [])) {
      if (!item.visible) continue
      const stok  = item.stock > 0 ? `stok: ${item.stock}` : 'HABIS'
      const disc  = item.discountPct > 0 ? ` [DISKON ${item.discountPct}%]` : ''
      const harga = item.discountPct > 0
        ? `${fmtPrice(item.price)}${disc} (asli: ${fmtPrice(item.originalPrice)})`
        : fmtPrice(item.price)
      lines.push(`  - #${item.id} ${item.name}: ${harga}, ${stok}`)
      if (item.description) lines.push(`    Desc: ${item.description}`)
    }
  }

  lines.push('\n=== INFO TOKO ===')
  lines.push(`Total kategori: ${stats.totalCategories}`)
  lines.push(`Total produk: ${stats.totalItems}`)
  lines.push(`Order selesai: ${stats.completedOrders}`)

  return lines.join('\n')
}

export function buildUserOrderContext(senderNum) {
  const { orders } = getOrders()
  const userOrders = orders
    .filter(o => o.senderNum === senderNum)
    .slice(-5)

  if (!userOrders.length) return 'User belum pernah melakukan order.'

  return userOrders.map(o =>
    `Order ${o.orderId}: ${o.categoryName} - ${o.itemName}, ` +
    `${fmtPrice(o.total)}, status: ${o.status}, tanggal: ${new Date(o.createdAt).toLocaleDateString('id-ID')}`
  ).join('\n')
}