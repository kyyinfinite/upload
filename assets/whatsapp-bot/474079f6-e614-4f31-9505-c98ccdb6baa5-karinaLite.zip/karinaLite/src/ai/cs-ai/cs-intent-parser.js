// src/ai/cs-intent-parser.js
export function parseIntent(raw) {
  if (!raw || typeof raw !== 'string') {
    return {
      intent: 'chat',
      text: raw || '',
      products: [],
      table: null,
      tip: null,
      suggests: [],
    }
  }

  try {
    let clean = raw.trim()

    // 1) Kalau ada blok ```json ... ```, ambil isinya saja
    const fenceMatch = clean.match(/```(?:json|javascript|js)?\s*\n?([\s\S]*?)\n?```/i)
    if (fenceMatch) {
      clean = fenceMatch[1].trim()
    } else {
      // 2) Kalau tidak ada fence, coba cari JSON object/array paling luar
      const firstBrace = clean.indexOf('{')
      const firstBracket = clean.indexOf('[')
      let start = -1
      if (firstBrace !== -1 && firstBracket !== -1) {
        start = Math.min(firstBrace, firstBracket)
      } else if (firstBrace !== -1) {
        start = firstBrace
      } else if (firstBracket !== -1) {
        start = firstBracket
      }

      if (start !== -1) {
        // Cari pasangan penutup yang sesuai
        const stack = []
        let end = -1
        for (let i = start; i < clean.length; i++) {
          const ch = clean[i]
          if (ch === '{' || ch === '[') {
            stack.push(ch)
          } else if (ch === '}' || ch === ']') {
            const last = stack.pop()
            if ((ch === '}' && last !== '{') || (ch === ']' && last !== '[')) {
              break // struktur rusak
            }
            if (stack.length === 0) {
              end = i
              break
            }
          }
        }
        if (end !== -1) {
          clean = clean.substring(start, end + 1)
        }
      }
    }

    const parsed = JSON.parse(clean)

    return {
      intent: parsed.intent || 'chat',
      text: parsed.text || '',
      products: Array.isArray(parsed.products) ? parsed.products : [],
      table: parsed.table || null,
      tip: parsed.tip || null,
      suggests: Array.isArray(parsed.suggests) ? parsed.suggests : [],
    }
  } catch {
    // 3) Jika semua gagal, coba ambil teks sebelum JSON (fallback terakhir)
    const lines = raw.split('\n')
    const textLines = []
    for (const line of lines) {
      const trimmed = line.trim()
      if (trimmed.startsWith('{') || trimmed.startsWith('```')) break
      if (trimmed) textLines.push(trimmed)
    }
    const fallbackText = textLines.join('\n').trim()

    return {
      intent: 'chat',
      text: fallbackText || raw.trim(),
      products: [],
      table: null,
      tip: null,
      suggests: [],
    }
  }
}