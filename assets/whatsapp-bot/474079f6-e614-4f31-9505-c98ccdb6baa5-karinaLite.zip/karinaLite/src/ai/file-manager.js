import fs from 'fs'
import path from 'path'
import axios from 'axios'
import { fileURLToPath } from 'url'
import config from '../../config.js'
import logger from '../lib/logger.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT_DIR  = path.resolve(__dirname, '../../')

const CONFIG = {
  groqModel:      'llama-3.3-70b-versatile',
  maxTokens:      4096,
  temperature:    0.1,
  errorLogPath:   path.join(ROOT_DIR, 'storage/logs/error-log.log'),
  logDir:         path.join(ROOT_DIR, 'storage/logs'),
  backupDir:      path.join(ROOT_DIR, 'storage/backups'),
  maxFileChars:   2500,
  maxFilesCtx:    6,
  maxErrorChars:  3000,
  maxPromptChars: 18000,
  scanExtensions: ['.js', '.ts', '.json'],
  ignoreDirs:     ['node_modules', '.git', 'session', 'storage', 'dist', '.cache'],
  retryDelayMs:   1500,
  timeoutMs:      60000,
}

const FALLBACK_MODELS = [
  'llama-3.3-70b-versatile',
  'llama-3.1-70b-versatile',
  'llama-3.1-8b-instant',
  'gemma2-9b-it',
  'mixtral-8x7b-32768',
]

function _resolveGroqKeys() {
  const fromConfig = config.groq?.keys
  if (Array.isArray(fromConfig) && fromConfig.length) {
    return fromConfig.filter(k => typeof k === 'string' && k.trim())
  }

  const keys = []
  const single = config.groq?.['groq-manage'] || config.groq?.key
  if (single) keys.push(single)

  for (let i = 1; i <= 5; i++) {
    const k = config.groq?.[`key${i}`] || config.groq?.[`groq-key-${i}`]
    if (k && !keys.includes(k)) keys.push(k)
  }

  return keys.filter(Boolean)
}

const GROQ_KEYS = _resolveGroqKeys()

if (!GROQ_KEYS.length) {
  logger.warn('FILE-MANAGER', 'Tidak ada Groq API key. AI features disabled.')
} else {
  logger.info('FILE-MANAGER', `${GROQ_KEYS.length} Groq key(s) loaded.`)
}

class KeyRotator {
  constructor(keys) {
    this.keys = [...keys]
    this.index = 0
    this.states = {}

    for (const k of keys) {
      this.states[k] = {
        failures:     0,
        rateLimitedUntil: 0,
        cooledDownAt: 0,
        totalCalls:   0,
        totalSuccess: 0,
      }
    }
  }

  _isAvailable(key) {
    const s = this.states[key]
    const now = Date.now()
    if (s.rateLimitedUntil > now) return false
    if (s.failures >= 5) {
      if (now - s.cooledDownAt < 5 * 60 * 1000) return false
      s.failures = 0
    }
    return true
  }

  next() {
    const now = Date.now()
    let attempts = 0

    while (attempts < this.keys.length) {
      const key = this.keys[this.index]
      this.index = (this.index + 1) % this.keys.length

      if (this._isAvailable(key)) return key
      attempts++
    }

    const earliest = this.keys.reduce((best, k) => {
      const s = this.states[k]
      const wait = Math.max(s.rateLimitedUntil, s.cooledDownAt + 5 * 60 * 1000)
      return wait < best.wait ? { key: k, wait } : best
    }, { key: this.keys[0], wait: Infinity })

    logger.warn('FILE-MANAGER', `Semua key sedang cooldown. Menggunakan ${earliest.key.slice(0, 8)}...`)
    return earliest.key
  }

  markRateLimited(key, retryAfter = 60) {
    const s = this.states[key]
    s.rateLimitedUntil = Date.now() + retryAfter * 1000
    logger.warn('FILE-MANAGER', `Key ${key.slice(0, 8)}... rate limited ${retryAfter}s`)
  }

  markFailed(key) {
    const s = this.states[key]
    s.failures++
    s.cooledDownAt = Date.now()
    logger.warn('FILE-MANAGER', `Key ${key.slice(0, 8)}... failure #${s.failures}`)
  }

  markSuccess(key) {
    const s = this.states[key]
    s.failures = Math.max(0, s.failures - 1)
    s.totalCalls++
    s.totalSuccess++
  }

  getStats() {
    return this.keys.map(k => {
      const s = this.states[k]
      const now = Date.now()
      return {
        key:         k.slice(0, 8) + '...',
        available:   this._isAvailable(k),
        failures:    s.failures,
        rateLimited: s.rateLimitedUntil > now
          ? `${Math.ceil((s.rateLimitedUntil - now) / 1000)}s`
          : 'no',
        calls:       s.totalCalls,
        success:     s.totalSuccess,
      }
    })
  }
}

const keyRotator = new KeyRotator(GROQ_KEYS)

const SYSTEM_PROMPT = `You are CORTEX — a WhatsApp bot AI repair engine.

Given an error log and relevant source files, you must:
1. Identify the exact bug location
2. Provide complete fixed file content

Respond ONLY with valid JSON. No markdown. No prose.

Schema:
{
  "diagnosis": "clear explanation of root cause",
  "severity": "LOW|MEDIUM|HIGH|CRITICAL",
  "fixes": [
    {
      "filePath": "relative/path/from/root.js",
      "action": "PATCH_FILE|LOG_ONLY",
      "confidence": 0.0,
      "reason": "why this fix is needed",
      "content": "COMPLETE file content or null"
    }
  ],
  "summary": "one-line summary"
}

Rules:
- filePath: relative to project root (src/handler.js)
- content: COMPLETE file, never partial
- confidence < 0.75 → use LOG_ONLY
- If uncertain → LOG_ONLY`

function estimateTokens(text) {
  return Math.ceil(text.length / 3.5)
}

async function callGroq(userPrompt, options = {}) {
  if (!GROQ_KEYS.length) throw new Error('Tidak ada Groq API key')

  const {
    maxRetries  = GROQ_KEYS.length * 2,
    forceModel  = null,
  } = options

  const promptTokens = estimateTokens(userPrompt)
  logger.info('FILE-MANAGER', `Prompt size: ~${promptTokens} tokens`)

  if (promptTokens > 25000) {
    throw new Error(`Prompt terlalu besar (${promptTokens} tokens). Reduce maxFileChars.`)
  }

  const models = forceModel
    ? [forceModel]
    : FALLBACK_MODELS.filter((v, i, a) => a.indexOf(v) === i)

  let lastError = null
  let modelIdx  = 0

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const apiKey      = keyRotator.next()
    const currentModel = models[modelIdx % models.length]

    logger.debug('FILE-MANAGER', `Attempt ${attempt + 1}/${maxRetries} — key: ${apiKey.slice(0, 8)}... model: ${currentModel}`)

    try {
      const res = await axios.post(
        'https://api.groq.com/openai/v1/chat/completions',
        {
          model:           currentModel,
          messages:        [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user',   content: userPrompt },
          ],
          temperature:     CONFIG.temperature,
          max_tokens:      CONFIG.maxTokens,
          top_p:           1,
          stream:          false,
          response_format: { type: 'json_object' },
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization:  `Bearer ${apiKey}`,
          },
          timeout:        CONFIG.timeoutMs,
          validateStatus: s => s < 600,
        }
      )

      if (res.status === 200 && res.data?.choices?.[0]?.message?.content) {
        keyRotator.markSuccess(apiKey)
        logger.info('FILE-MANAGER', `Groq success — model: ${currentModel}, key: ${apiKey.slice(0, 8)}...`)
        return res.data.choices[0].message.content
      }

      if (res.status === 413) {
        logger.warn('FILE-MANAGER', `413 Payload Too Large — model: ${currentModel}. Truncating prompt next attempt.`)
        lastError = new Error('Prompt terlalu besar (413)')
        modelIdx++
        continue
      }

      if (res.status === 429) {
        const retryAfter = parseInt(res.headers?.['retry-after'] || '60', 10)
        keyRotator.markRateLimited(apiKey, retryAfter)
        lastError = new Error('Rate limited')
        await new Promise(r => setTimeout(r, Math.min(retryAfter * 1000, 10000)))
        continue
      }

      if (res.status === 401 || res.status === 403) {
        for (let i = 0; i < 5; i++) keyRotator.markFailed(apiKey)
        lastError = new Error(`Auth failed (${res.status})`)
        continue
      }

      if (res.status === 400) {
        const errMsg = res.data?.error?.message || 'Bad request'
        if (errMsg.includes('model') || errMsg.includes('not found') || errMsg.includes('not available')) {
          logger.warn('FILE-MANAGER', `Model ${currentModel} tidak tersedia, next model...`)
          modelIdx++
          lastError = new Error(`Model unavailable: ${currentModel}`)
          continue
        }
        if (errMsg.includes('context_length') || errMsg.includes('too long') || errMsg.includes('tokens')) {
          logger.warn('FILE-MANAGER', `Context too long untuk ${currentModel}, next model...`)
          modelIdx++
          lastError = new Error('Context too long')
          continue
        }
        throw new Error(errMsg)
      }

      if (res.status >= 500) {
        lastError = new Error(`Server error (${res.status})`)
        await new Promise(r => setTimeout(r, CONFIG.retryDelayMs * (attempt + 1)))
        continue
      }

      lastError = new Error(`HTTP ${res.status}: ${JSON.stringify(res.data).slice(0, 200)}`)
    } catch (err) {
      if (err.message?.includes('413') || err.message?.includes('terlalu besar')) {
        modelIdx++
        lastError = err
        continue
      }
      if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
        lastError = new Error('Timeout')
        await new Promise(r => setTimeout(r, 2000))
        continue
      }
      if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND') {
        lastError = new Error('Tidak bisa koneksi ke Groq')
        await new Promise(r => setTimeout(r, 3000))
        continue
      }
      keyRotator.markFailed(apiKey)
      lastError = err
    }
  }

  throw lastError || new Error('Semua attempt gagal')
}

function ensureDirs() {
  for (const dir of [CONFIG.logDir, CONFIG.backupDir]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  }
}

function timestamp() {
  return new Date().toISOString()
}

export function writeErrorLog(source, error) {
  ensureDirs()
  const entry = [
    `\n${'─'.repeat(60)}`,
    `[${timestamp()}] SOURCE: ${source}`,
    `ERROR:   ${error?.name ?? 'Error'}: ${error?.message ?? String(error)}`,
    `STACK:\n${(error?.stack ?? '').split('\n').slice(0, 8).map(l => '  ' + l).join('\n')}`,
    `${'─'.repeat(60)}`,
  ].join('\n')

  try {
    fs.appendFileSync(CONFIG.errorLogPath, entry + '\n', 'utf-8')
  } catch (e) {
    logger.error('FILE-MANAGER', 'Gagal tulis error log: ' + e.message)
  }
}

export function readErrorLog(maxChars = CONFIG.maxErrorChars) {
  try {
    if (!fs.existsSync(CONFIG.errorLogPath)) return '(no errors logged yet)'
    const content = fs.readFileSync(CONFIG.errorLogPath, 'utf-8')
    if (content.length <= maxChars) return content
    return '...[earlier entries truncated]\n' + content.slice(-maxChars)
  } catch {
    return '(failed to read error log)'
  }
}

function scanFiles(dir = ROOT_DIR, results = []) {
  let entries
  try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch { return results }

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name)
    const rel      = path.relative(ROOT_DIR, fullPath)

    if (entry.isDirectory()) {
      const isIgnored = CONFIG.ignoreDirs.some(
        ig => rel === ig || rel.startsWith(ig + path.sep) || entry.name.startsWith('.')
      )
      if (!isIgnored) scanFiles(fullPath, results)
      continue
    }

    if (CONFIG.scanExtensions.includes(path.extname(entry.name))) {
      const stat = fs.statSync(fullPath)
      results.push({ fullPath, rel, size: stat.size })
    }
  }

  return results
}

function catFile(fullPath, maxChars = CONFIG.maxFileChars) {
  try {
    const content = fs.readFileSync(fullPath, 'utf-8')
    if (content.length <= maxChars) return content
    const head = Math.floor(maxChars * 0.7)
    const tail = maxChars - head
    return (
      content.slice(0, head) +
      `\n...[${content.length - maxChars} chars truncated]...\n` +
      content.slice(-tail)
    )
  } catch (e) {
    return `(error reading: ${e.message})`
  }
}

function pickRelevantFiles(allFiles, errorText) {
  const mentioned = new Set()
  const fileRegex = /([a-zA-Z0-9_\-./\\]+\.(js|ts|json))/g
  let m
  while ((m = fileRegex.exec(errorText)) !== null) {
    mentioned.add(path.basename(m[1]))
  }

  const PRIORITY_FILES = new Set([
    'index.js', 'handler.js', 'plugins.js', 'config.js',
    'serialize.js', 'database.js', 'telegram-bot.js',
  ])

  const scored = allFiles.map(f => {
    const base = path.basename(f.rel)
    let score  = 0
    if (mentioned.has(base)) score += 10
    if (PRIORITY_FILES.has(base)) score += 3
    if (f.rel.startsWith('src/')) score += 1
    score -= f.size / 50000
    return { ...f, score }
  })

  scored.sort((a, b) => b.score - a.score)
  return scored.slice(0, CONFIG.maxFilesCtx)
}

function buildPrompt(errorLog, files) {
  const fileDumps = files.map(f =>
    `### ${f.rel}\n\`\`\`\n${catFile(f.fullPath)}\n\`\`\``
  ).join('\n\n')

  const raw =
    `## ERROR LOG\n\`\`\`\n${errorLog}\n\`\`\`\n\n` +
    `## PROJECT FILES\n\n${fileDumps}`

  if (raw.length > CONFIG.maxPromptChars) {
    logger.warn('FILE-MANAGER', `Prompt ${raw.length} chars > limit ${CONFIG.maxPromptChars}. Trimming files...`)
    return buildPromptTrimmed(errorLog, files)
  }

  return raw
}

function buildPromptTrimmed(errorLog, files) {
  const header  = `## ERROR LOG\n\`\`\`\n${errorLog}\n\`\`\`\n\n## PROJECT FILES\n\n`
  const budget  = CONFIG.maxPromptChars - header.length - 500
  const perFile = Math.floor(budget / Math.max(files.length, 1))

  const fileDumps = files.map(f =>
    `### ${f.rel}\n\`\`\`\n${catFile(f.fullPath, perFile)}\n\`\`\``
  ).join('\n\n')

  return header + fileDumps
}

function parseGroqResponse(raw) {
  try {
    const cleaned = raw.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim()
    return JSON.parse(cleaned)
  } catch {
    try {
      const match = raw.match(/\{[\s\S]*\}/)
      if (match) return JSON.parse(match[0])
    } catch {}
    return null
  }
}

function backupFile(filePath) {
  ensureDirs()
  try {
    const resolved = path.resolve(filePath)
    if (!fs.existsSync(resolved)) return null
    const rel     = path.relative(ROOT_DIR, resolved).replace(/[/\\]/g, '_')
    const bakPath = path.join(CONFIG.backupDir, `${rel}.${Date.now()}.bak`)
    fs.copyFileSync(resolved, bakPath)
    return bakPath
  } catch {
    return null
  }
}

function applyPatch(relPath, content) {
  if (!content || typeof content !== 'string') {
    return { success: false, message: 'Empty content — skipped' }
  }

  const fullPath = path.resolve(ROOT_DIR, relPath)
  backupFile(fullPath)

  const dir = path.dirname(fullPath)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

  try {
    fs.writeFileSync(fullPath, content, 'utf-8')
    return { success: true, message: `Patched: ${relPath}` }
  } catch (err) {
    return { success: false, message: `Write failed: ${err.message}` }
  }
}

function writeAnalysisReport(analysis, patchResults) {
  ensureDirs()
  const reportPath = path.join(CONFIG.logDir, 'analysis-report.log')
  const lines = [
    `\n${'═'.repeat(60)}`,
    `[${timestamp()}] GROQ ANALYSIS REPORT`,
    `${'═'.repeat(60)}`,
    `DIAGNOSIS : ${analysis.diagnosis ?? '-'}`,
    `SEVERITY  : ${analysis.severity ?? '-'}`,
    `SUMMARY   : ${analysis.summary ?? '-'}`,
    '',
    'FIXES:',
    ...(analysis.fixes ?? []).map((fix, i) => {
      const result = patchResults[i]
      return [
        `  [${i + 1}] ${fix.filePath}`,
        `      Action     : ${fix.action}`,
        `      Confidence : ${fix.confidence}`,
        `      Result     : ${result?.message ?? 'N/A'}`,
      ].join('\n')
    }),
    '',
    'KEY STATS:',
    ...keyRotator.getStats().map(s =>
      `  ${s.key} — available: ${s.available} | failures: ${s.failures} | rateLimit: ${s.rateLimited} | calls: ${s.calls}/${s.success}`
    ),
    `${'═'.repeat(60)}`,
  ]

  try {
    fs.appendFileSync(reportPath, lines.join('\n') + '\n', 'utf-8')
  } catch {}

  return reportPath
}

export async function analyzeAndFix(options = {}) {
  const {
    verbose = true,
    dryRun  = false,
  } = options

  if (verbose) logger.info('FILE-MANAGER', 'Memulai analisis...')

  const errorLog = readErrorLog()
  if (verbose) logger.info('FILE-MANAGER', `Error log: ${errorLog.length} chars`)

  const allFiles = scanFiles()
  if (verbose) logger.info('FILE-MANAGER', `${allFiles.length} file ditemukan`)

  const relevant = pickRelevantFiles(allFiles, errorLog)
  if (verbose) {
    logger.info('FILE-MANAGER', `${relevant.length} file dikirim ke Groq:`)
    for (const f of relevant) logger.debug('FILE-MANAGER', `  → ${f.rel}`)
  }

  const prompt = buildPrompt(errorLog, relevant)
  const promptTokenEst = estimateTokens(prompt)

  if (verbose) {
    logger.info('FILE-MANAGER', `Prompt size: ${prompt.length} chars (~${promptTokenEst} tokens)`)
  }

  if (promptTokenEst > 28000) {
    logger.warn('FILE-MANAGER', 'Prompt terlalu besar, memotong file lebih agresif...')
    CONFIG.maxFileChars = Math.floor(CONFIG.maxFileChars * 0.6)
    CONFIG.maxFilesCtx  = Math.max(3, CONFIG.maxFilesCtx - 2)
  }

  if (verbose) logger.info('FILE-MANAGER', 'Menghubungi Groq API...')

  let raw
  try {
    raw = await callGroq(prompt)
  } catch (err) {
    logger.error('FILE-MANAGER', `Groq gagal: ${err.message}`)

    if (err.message?.includes('413') || err.message?.includes('terlalu besar')) {
      logger.warn('FILE-MANAGER', 'Mencoba dengan prompt lebih kecil (hanya error log)...')
      try {
        const minimalPrompt = `## ERROR LOG\n\`\`\`\n${errorLog}\n\`\`\`\n\nAnalyze this error and suggest fixes.`
        raw = await callGroq(minimalPrompt)
      } catch (err2) {
        return { success: false, error: err2.message }
      }
    } else {
      return { success: false, error: err.message }
    }
  }

  const analysis = parseGroqResponse(raw)
  if (!analysis) {
    logger.error('FILE-MANAGER', 'Gagal parse respons Groq')
    return { success: false, error: 'Invalid Groq response', raw }
  }

  if (verbose) {
    logger.info('FILE-MANAGER', `Diagnosis : ${analysis.diagnosis}`)
    logger.info('FILE-MANAGER', `Severity  : ${analysis.severity}`)
    logger.info('FILE-MANAGER', `Fixes     : ${(analysis.fixes ?? []).length}`)
  }

  const patchResults = []
  for (const fix of (analysis.fixes ?? [])) {
    if (fix.action !== 'PATCH_FILE' || !fix.content || fix.confidence < 0.75) {
      if (verbose) logger.info('FILE-MANAGER', `LOG_ONLY: ${fix.filePath} (confidence: ${fix.confidence})`)
      patchResults.push({ success: false, message: 'LOG_ONLY — tidak di-patch' })
      continue
    }

    if (dryRun) {
      if (verbose) logger.info('FILE-MANAGER', `DRY-RUN: ${fix.filePath}`)
      patchResults.push({ success: false, message: 'DRY-RUN — tidak di-patch' })
      continue
    }

    const result = applyPatch(fix.filePath, fix.content)
    if (verbose) {
      logger.info('FILE-MANAGER', `${result.success ? '✓' : '✗'} ${result.message}`)
    }
    patchResults.push(result)
  }

  const reportPath = writeAnalysisReport(analysis, patchResults)
  if (verbose) logger.info('FILE-MANAGER', `Report: ${path.relative(ROOT_DIR, reportPath)}`)

  return { success: true, analysis, patchResults, reportPath }
}

export async function readFileAndAsk(relPath, question = 'Analyze this file for any issues.') {
  const fullPath = path.resolve(ROOT_DIR, relPath)
  const content  = catFile(fullPath, 4000)
  const prompt   = `File: ${relPath}\n\`\`\`\n${content}\n\`\`\`\n\nQuestion: ${question}`

  try {
    const raw      = await callGroq(prompt)
    const analysis = parseGroqResponse(raw)
    return analysis ?? { raw }
  } catch (err) {
    return { error: err.message }
  }
}

export function catAllFiles(targetDir = ROOT_DIR) {
  const files  = scanFiles(targetDir)
  const output = []

  for (const f of files) {
    output.push(`${'─'.repeat(60)}\n### ${f.rel}\n${'─'.repeat(60)}\n${catFile(f.fullPath)}\n`)
  }

  return { totalFiles: files.length, content: output.join('\n'), files: files.map(f => f.rel) }
}

export function getGroqKeyStats() {
  return keyRotator.getStats()
}

export default {
  writeErrorLog,
  readErrorLog,
  analyzeAndFix,
  readFileAndAsk,
  catAllFiles,
  scanFiles,
  getGroqKeyStats,
}