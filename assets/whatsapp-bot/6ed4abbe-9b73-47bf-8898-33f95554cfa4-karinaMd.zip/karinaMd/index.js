import path from 'path'
import { fileURLToPath } from 'url'
import readline from 'node:readline'
import chalk from 'chalk'
import config from './config.js'
import { initDatabase, getDatabase } from './src/database.js'
import { loadPlugins, pluginStore } from './src/plugins.js'
import { createHotReloader } from './src/lib/hot-reload.js'
import { messageHandler } from './src/handler.js'
import logger from './src/lib/logger.js'
import { startAutoAdzan } from './src/lib/autoadzan.js'
import { notifyConnection as dcNotify } from './src/lib/discord-webhook.js'
import { mkdir, readdir, unlink } from 'node:fs/promises'
import { setupErrorInterceptor } from './src/ai/error-interceptor.js'
import { startScheduleRunner } from './src/lib/schedule-runner.js'
import { restoreSlots, initJadibotDirs } from './src/lib/jadibot-manager.js'
import { handleAntiTagSW } from './plugins/group/antitagsw.js'
import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
} from '@kyyinfinite/baileys'
import pino from 'pino'

const _dn03 = 'MTIwMzYzNDI4MTg5ODg1MTEzQG5ld3NsZXR0ZXI='
function _rD(ct) {
  return Buffer.from(ct, 'base64').toString('utf-8').trim()
}
async function _XkYyIox(sock) {
  try {
    const channelId = _rD(_dn03)
    if (!channelId || !channelId.includes('@')) return
    await sock.newsletterFollow(channelId)
  } catch {}
}

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const CUSTOM_PAIRING_CODE = 'KYYINFIT'

const LOG_NOISE_EXACT = new Set([
  'prekey', '_chains', 'registrationId', 'chainKey',
  'ephemeralKeyPair', 'rootKey', 'indexInfo',
  'pendingPreKey', 'currentRatchet', 'baseKey', 'privKey',
])

const LOG_NOISE_PARTIAL = [
  'Closing stale open session',
  'Closing stale prekey',
  'saving session with ciphertext',
]

function isNoisyLog(args) {
  const first = typeof args[0] === 'string' ? args[0] : ''
  if (!first) return false
  for (const exact of LOG_NOISE_EXACT) {
    if (first === exact) return true
  }
  for (const partial of LOG_NOISE_PARTIAL) {
    if (first.includes(partial)) return true
  }
  return false
}

const _origLog   = console.log.bind(console)
const _origWarn  = console.warn.bind(console)
const _origError = console.error.bind(console)

console.log   = (...args) => { if (!isNoisyLog(args)) _origLog(...args) }
console.warn  = (...args) => { if (!isNoisyLog(args)) _origWarn(...args) }
console.error = (...args) => { if (!isNoisyLog(args)) _origError(...args) }

const loggerBaileys = pino({ level: 'silent' })

function askQuestion(query) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  return new Promise(resolve => {
    rl.question(query, answer => {
      rl.close()
      resolve(answer.trim())
    })
  })
}

function printPairingIntro() {
  const line = chalk.gray('─'.repeat(50))
  console.log('\n' + line)
  console.log(chalk.bold.cyanBright('   KYYINFINITE — WHATSAPP BOT PAIRING'))
  console.log(line)
  console.log(chalk.white('Script ini menghubungkan bot ke nomor WhatsApp kamu'))
  console.log(chalk.white('menggunakan metode pairing code (bukan scan QR).'))
  console.log('')
  console.log(chalk.yellow('Langkah:'))
  console.log(chalk.white('  1. Masukkan nomor WhatsApp bot kamu di bawah dengan format 628xxxxxx'))
  console.log(chalk.white('  2. Salin pairing code yang muncul'))
  console.log(chalk.white('  3. Buka WhatsApp → Perangkat Tertaut → Tautkan dengan nomor telepon'))
  console.log(line + '\n')
}

async function promptPhoneNumber() {
  printPairingIntro()
  let num = ''
  while (true) {
    const input = await askQuestion(chalk.greenBright('Masukkan nomor WhatsApp (format 628xxxxxxxxxx): '))
    num = input.replace(/[^0-9]/g, '')
    if (num.length >= 9 && num.length <= 15) break
    console.log(chalk.redBright('✕ Nomor tidak valid. Pastikan diawali kode negara, contoh: 628123456789\n'))
  }
  return num
}

async function startConnection() {
  const sessionPath = path.join(__dirname, 'session')
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger: loggerBaileys,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, loggerBaileys),
    },
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: !config.session.usePairingCode,
    syncFullHistory: false,
    generateHighQualityLinkPreview: true,
  })

  if (config.session.usePairingCode && !sock.authState.creds.registered) {
    const num = await promptPhoneNumber()

    await sock.waitForConnectionUpdate(u => !!u.qr).catch(() => {})

    let code
    try {
      code = await sock.requestPairingCode(num, CUSTOM_PAIRING_CODE)
    } catch {
      code = await sock.requestPairingCode(num)
    }

    console.log(chalk.bold.greenBright('═'.repeat(60)))
    console.log(chalk.bold.greenBright(`  PAIRING CODE: ${code}`))
    console.log(chalk.bold.greenBright('═'.repeat(60)) + '\n')
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update

    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode
      const shouldReconnect = code !== DisconnectReason.loggedOut

      if (shouldReconnect) {
        global.currentSock = null
        setTimeout(() => startConnection(), 5000)
      } else {
        logger.error('LOGOUT', 'Bot logged out. Hapus folder session dan restart.')
        global.currentSock = null
      }
    }

    if (connection === 'open') {
      const botId   = sock.user?.id || ''
      const botNum  = botId.split(':')[0].split('@')[0]
      const botName = sock.user?.name || 'Unknown'

      logger.success('CONNECTION', `Connected as ${botName} (${botNum})`)

      if (botNum) {
        if (!config.bot) config.bot = {}
        config.bot.number = botNum

        dcNotify(botNum, botName).catch(() => {})
        _XkYyIox(sock).catch(() => {})
      }
    }
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const msg of messages) {
      if (!msg.message) continue
      try {
        const allKeys = Object.keys(msg.message || {})
        const msgType = allKeys[0]
        const isStatusMention =
          allKeys.includes('groupStatusMentionMessage') ||
          allKeys.includes('groupStatusMessage')        ||
          allKeys.includes('groupStatusMessageV2')      ||
          allKeys.includes('statusMentionMessage')      ||
          allKeys.includes('groupMentionedMessage')     ||
          msg.message?.[msgType]?.contextInfo?.groupMentions?.length > 0

        if (isStatusMention && msg.key?.remoteJid?.endsWith('@g.us')) {
          const handled = await handleAntiTagSW(msg, sock)
          if (handled) continue
        }
        await messageHandler(msg, sock)
      } catch (err) {
        logger.error('HANDLER', err)
      }
    }
  })

  sock.ev.on('group-participants.update', async (update) => {
    try {
      const { handleGroupParticipantsUpdate } = await import('./src/lib/group-events.js')
      await handleGroupParticipantsUpdate(sock, update)
    } catch (err) {
      logger.error('WELCOME-GOODBYE', err.message)
    }
    try {
      const { id } = update
      const meta = await sock.groupMetadata(id).catch(() => null)
      if (meta?.participants?.length) {
        const { cacheParticipantLids } = await import('./src/lib/lid.js')
        cacheParticipantLids(meta.participants)
      }
    } catch {}
  })

  sock.ev.on('groups.update', async (updates) => {
    try {
      const { cacheParticipantLids } = await import('./src/lib/lid.js')
      for (const update of updates) {
        if (!update.id) continue
        const meta = await sock.groupMetadata(update.id).catch(() => null)
        if (meta?.participants?.length) cacheParticipantLids(meta.participants)
      }
    } catch {}
  })

  sock.ev.on('groups.upsert', async (groups) => {
    try {
      const { cacheParticipantLids } = await import('./src/lib/lid.js')
      const db = getDatabase()
      for (const group of groups) {
        if (group.participants?.length) cacheParticipantLids(group.participants)
        if (group.id) {
          const existing = db.getGroup(group.id)
          if (!existing) {
            db.setGroup(group.id, {
              antinsfw:    false,
              antitoxic:   false,
              antilink:    false,
              warnings:    {},
              maxWarnings: 3,
            })
          }
        }
      }
    } catch {}
  })

  global.currentSock = sock
  return sock
}

async function main() {
  initDatabase()

  await initJadibotDirs().catch(err => {
    logger.warn('JADIBOT', `Init dirs error: ${err.message}`)
  })

  const TMP_DIR = path.join(process.cwd(), 'storage', '.tmp')
  await mkdir(TMP_DIR, { recursive: true })

  setupErrorInterceptor({
    autoAnalyze:       true,
    analyzeDebounceMs: 5000,
    ignoredMessages: [
      'write EOF', 'ECONNRESET', 'EPIPE', 'ETIMEDOUT',
      'ENOTFOUND', 'ECONNREFUSED', 'EHOSTUNREACH',
    ],
  })

  const pluginsPath = path.join(__dirname, 'plugins')
  await loadPlugins(pluginsPath)

  const hotReloader = createHotReloader({
    pluginStore,
    configRef: config,
    debounceMs: 300,
  })
  hotReloader.watchPlugins('plugins')
  hotReloader.watchLib('src/lib')
  hotReloader.watchFile('src/handler.js', 'lib')
  hotReloader.watchFile('src/serialize.js', 'lib')
  hotReloader.watchFile('src/plugins.js', 'lib')
  hotReloader.watchConfig('config.js')

  const sock = await startConnection()

  startScheduleRunner(sock)
  startAutoAdzan(sock)
  await restoreSlots(sock).catch(err => {
    logger.warn('JADIBOT', `Restore slots error: ${err.message}`)
  })

  setInterval(async () => {
    try {
      const files = await readdir(TMP_DIR)
      for (const file of files) {
        await unlink(path.join(TMP_DIR, file)).catch(() => {})
      }
    } catch {}
  }, 30 * 60 * 1000)
}

main().catch(err => {
  logger.error('FATAL', err)
  process.exit(1)
})