// plugins/sticker/swm.js
import { downloadContentFromMessage } from '@kyyinfinite/baileys'
import { writeExifImg, writeExifVid } from '../../src/lib/exif.js'

export const config_ = {
  name: 'swm',
  alias: ['wm', 'stickerwm', 'stickermark', 'colong'],
  category: 'sticker',
  description: 'Ganti packname dan author pada stiker',
  usage: '.swm <packname> atau .swm <packname>|<author>',
  example: '.swm BotName\n.swm BotName|Owner',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const target = m.quoted || m
  const isSticker = target.type === 'stickerMessage' || target.isSticker

  if (!isSticker) {
    return m.reply(
      '❌ *Bukan Stiker!*\n\n' +
      'Reply ke stiker yang ingin diubah watermark-nya.\n' +
      'Contoh: `.swm NamaPack` atau `.swm NamaPack|Author`'
    )
  }

  const input = m.text?.trim()
  if (!input) {
    return m.reply(
      '❌ *Masukkan Packname!*\n\n' +
      'Format: `.swm <packname>` atau `.swm <packname>|<author>`\n' +
      'Contoh: `.swm BotKu` atau `.swm BotKu|KyyInfinite`'
    )
  }

  let packname, author
  if (input.includes('|')) {
    const parts = input.split('|')
    packname = parts[0]?.trim() || 'Sticker'
    author = parts[1]?.trim() || ''
  } else {
    packname = input
    author = ''
  }

  await m.react('⏳')

  try {
    const stream = await downloadContentFromMessage(target.message[target.type], target.type)
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }

    if (!buffer || buffer.length === 0) {
      await m.react('❌')
      return m.reply('❌ Gagal mengunduh stiker.')
    }

    // Cek apakah stiker video (animated) atau gambar
    const isVideo = target.isAnimated || target.type === 'videoMessage' || target.isVideo

    let stickerBuffer
    if (isVideo) {
      stickerBuffer = await writeExifVid(buffer, { packname, author })
    } else {
      stickerBuffer = await writeExifImg(buffer, { packname, author })
    }

    await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[SWM]', err)
    await m.react('❌')
    await m.reply(`❌ Gagal mengubah watermark: ${err.message}`)
  }
}