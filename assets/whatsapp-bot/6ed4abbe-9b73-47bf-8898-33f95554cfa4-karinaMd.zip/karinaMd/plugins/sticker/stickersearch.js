// plugins/search/stickersearch.js
import axios from 'axios'
import sharp from 'sharp'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'
import { sendCustomStickerPack } from '../../src/lib/stickerPack.js'

const sessions = new Map()
const SESSION_TTL = 5 * 60 * 1000
const MAX_STICKERS_PER_PACK = 20
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

export const config_ = {
  name: 'stickersearch',
  alias: ['stiker', 'caristiker', 'searchsticker'],
  category: 'sticker',
  description: 'Cari dan dapatkan stiker pack dari Combot (dikirim sebagai sticker pack)',
  usage: '.stickersearch <query> / .stickersearch <nomor>',
  example: '.stickersearch karina\n.stickersearch 1',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

async function downloadAndProcessSticker(url, retries = 2) {
  const methods = [
    async () => {
      const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 20000,
        headers: {
          'User-Agent': UA,
          Referer: 'https://combot.org/',
          Accept: 'image/webp,image/apng,image/*,*/*;q=0.8',
          'Accept-Encoding': 'gzip, deflate, br',
        },
        maxRedirects: 5,
      })
      const buffer = Buffer.from(res.data)
      if (!buffer || buffer.length < 1024) throw new Error('Buffer kosong')
      return buffer
    },
    async () => {
      const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(url)}`
      const res = await axios.get(proxyUrl, {
        responseType: 'arraybuffer',
        timeout: 25000,
        headers: { 'User-Agent': UA },
      })
      const buffer = Buffer.from(res.data)
      if (!buffer || buffer.length < 1024) throw new Error('Buffer kosong via corsproxy')
      return buffer
    },
    async () => {
      const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`
      const res = await axios.get(proxyUrl, {
        responseType: 'arraybuffer',
        timeout: 25000,
        headers: { 'User-Agent': UA },
      })
      const buffer = Buffer.from(res.data)
      if (!buffer || buffer.length < 1024) throw new Error('Buffer kosong via allorigins')
      return buffer
    },
  ]

  for (let attempt = 0; attempt <= retries; attempt++) {
    for (const method of methods) {
      try {
        const buffer = await method()
        // Proses seperti di stickerpack.js
        const webpBuffer = await sharp(buffer, { animated: false })
          .resize(512, 512, { fit: 'cover' })
          .webp()
          .toBuffer()
        return webpBuffer
      } catch {}
    }
    await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)))
  }
  throw new Error('Semua metode download gagal')
}

export async function handler(m, { sock }) {
  const text = m.text?.trim() || ''
  if (!text) {
    return m.reply(
      beautifulMessage(
        '❌ Masukkan kata kunci pencarian stiker.\nContoh: .stickersearch karina',
        { pushName: m.pushName }
      )
    )
  }

  // ─── Jika input angka → ambil dari sesi ───────────────────────────
  if (/^\d+$/.test(text)) {
    const index = parseInt(text) - 1
    const session = sessions.get(m.senderNumber)
    if (!session || Date.now() > session.expires) {
      sessions.delete(m.senderNumber)
      return m.reply('⌛ Sesi pencarian sudah habis. Cari lagi dengan .stickersearch <query>')
    }
    if (index < 0 || index >= session.packs.length) {
      return m.reply('❌ Nomor pack tidak valid.')
    }

    const pack = session.packs[index]
    await m.react('⏳')

    try {
      const stickerUrls = pack.sticker_urls || []
      if (stickerUrls.length === 0) {
        return m.reply('❌ Pack ini tidak memiliki stiker.')
      }

      const toSend = stickerUrls.slice(0, MAX_STICKERS_PER_PACK)
      await m.reply(`📦 Mengunduh ${toSend.length} stiker dari pack: *${pack.title || 'Untitled'}*`)

      const stickerPack = []
      let failed = 0
      for (const [i, url] of toSend.entries()) {
        try {
          const webpBuffer = await downloadAndProcessSticker(url)
          stickerPack.push({
            buffer: webpBuffer,
            ext: 'webp',
            mimetype: 'image/webp',
            isAnimated: false,
            isLottie: false,
          })
        } catch (err) {
          failed++
          console.warn(`[STICKERSEARCH] Gagal download stiker ${i+1}:`, err.message)
        }
      }

      if (stickerPack.length === 0) {
        return m.reply('❌ Gagal mengunduh semua stiker. Coba lagi nanti.')
      }

      await m.reply(`✅ ${stickerPack.length} stiker berhasil diunduh. Mengirim sebagai pack...`)
      await sendCustomStickerPack(sock, m, stickerPack)

      if (failed > 0) {
        await m.reply(`⚠️ ${failed} stiker gagal diunduh dan dilewati.`)
      }

      await m.react('✅')
    } catch (err) {
      console.error('[STICKERSEARCH]', err)
      await m.react('❌')
      await m.reply(`❌ Gagal mengirim pack: ${err.message}`)
    }
    return
  }

  // ─── Pencarian baru ──────────────────────────────────────────────
  await m.react('🔍')

  try {
    const res = await axios.get('https://api.siputzx.my.id/api/sticker/combot-search', {
      params: {
        q: text,
        page: 1,
      },
      timeout: 15000,
      headers: { 'User-Agent': UA },
    })

    const result = res.data
    if (!result.status || !result.data?.results || result.data.results.length === 0) {
      await m.react('😔')
      return m.reply(`❌ Tidak ada pack stiker untuk "${text}"`)
    }

    const packs = result.data.results.slice(0, 10)

    sessions.set(m.senderNumber, {
      packs,
      expires: Date.now() + SESSION_TTL,
    })

    const products = packs.map((p, i) => ({
      title: `${i + 1}. ${p.title || 'Untitled'}`,
      brand: p.sticker_type || 'regular',
      price: `${p.total_stickers || 0} stiker`,
      image_url: p.sticker_urls?.[0] || '',
      product_url: p.add_sticker_url || '',
      sale_price: new Date(p.created_date).toLocaleDateString('id-ID'),
    }))

    await new AIRich(sock)
      .setTitle(`🔍 Sticker Search: "${text}"`)
      .addText(`Balas dengan *.stickersearch <nomor>* (1-${packs.length}) untuk mendapatkan pack stiker.`)
      .addProduct(products)
      .addSuggest(packs.slice(0, 5).map((_, i) => `stickersearch ${i + 1}`))
      .send(m.chat, { quoted: m.raw })

    await m.react('✅')
  } catch (err) {
    console.error('[STICKERSEARCH]', err)
    await m.react('❌')
    await m.reply(beautifulMessage(`❌ Terjadi kesalahan: ${err.message}`, { pushName: m.pushName }))
  }
}