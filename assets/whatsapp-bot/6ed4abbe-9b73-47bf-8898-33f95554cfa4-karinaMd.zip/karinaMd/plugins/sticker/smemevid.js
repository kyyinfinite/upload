// plugins/sticker/smemevid.js
import { downloadContentFromMessage } from '@kyyinfinite/baileys'
import { createCanvas } from '@napi-rs/canvas'
import fs from 'fs'
import path from 'path'
import os from 'os'
import ffmpeg from 'fluent-ffmpeg'
import { writeExifVid } from '../../src/lib/exif.js'

export const config_ = {
  name: 'smemevid',
  alias: ['smemevideo', 'memevid'],
  category: 'sticker',
  description: 'Buat stiker meme dari video dengan teks atas/bawah',
  usage: '.smemevid <atas>|<bawah> (reply video)',
  example: '.smemevid WIDTH OR HEIGHT|WHY NOT BOTH?',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 15,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const target = m.quoted || m
  const isVideo = target.type === 'videoMessage' || target.isVideo

  if (!isVideo) {
    return m.reply(
      '🎬 *Sticker Meme Video*\n\n' +
      'Reply video dengan caption:\n' +
      '`.smemevid Teks Atas|Teks Bawah`\n\n' +
      'Contoh: `.smemevid WIDTH OR HEIGHT|WHY NOT BOTH?`'
    )
  }

  const text = m.text?.trim() || ''
  if (!text || !text.includes('|')) {
    return m.reply(
      '🎬 *Sticker Meme Video*\n\n' +
      'Format: `.smemevid Teks Atas|Teks Bawah`\n' +
      'Contoh: `.smemevid WIDTH OR HEIGHT|WHY NOT BOTH?`'
    )
  }

  const [top, bottom] = text.split('|').map(s => s.trim().toUpperCase())
  if (!top && !bottom) {
    return m.reply('❌ Masukkan minimal satu teks.')
  }

  await m.react('⏳')

  try {
    const stream = await downloadContentFromMessage(target.message[target.type], 'video')
    let chunks = []
    for await (const chunk of stream) {
      chunks.push(chunk)
    }
    const videoBuffer = Buffer.concat(chunks)

    if (!videoBuffer || videoBuffer.length === 0) {
      await m.react('❌')
      return m.reply('❌ Gagal download video.')
    }

    const tmpDir = path.join(process.cwd(), 'storage', '.tmp')
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

    const id = Date.now()
    const inputPath = path.join(tmpDir, `vid-${id}.mp4`)
    const outputPath = path.join(tmpDir, `vid-out-${id}.webp`)
    const overlayPath = path.join(tmpDir, `overlay-${id}.png`)

    fs.writeFileSync(inputPath, videoBuffer)

    const size = 512
    const canvas = createCanvas(size, size)
    const ctx = canvas.getContext('2d')

    const drawText = (text, y, isBottom) => {
      if (!text) return
      ctx.textAlign = 'center'
      ctx.textBaseline = isBottom ? 'bottom' : 'top'
      ctx.lineJoin = 'round'
      let fontSize = Math.floor(size / 8)
      ctx.font = `bold ${fontSize}px Impact, Arial`
      while (ctx.measureText(text).width > size - 20) {
        fontSize -= 2
        ctx.font = `bold ${fontSize}px Impact, Arial`
        if (fontSize < 10) break
      }
      ctx.lineWidth = Math.floor(fontSize / 6)
      ctx.strokeStyle = 'black'
      ctx.strokeText(text, size / 2, y)
      ctx.fillStyle = 'white'
      ctx.fillText(text, size / 2, y)
    }

    drawText(top, 10, false)
    drawText(bottom, size - 10, true)

    const overlayBuffer = canvas.toBuffer('image/png')
    fs.writeFileSync(overlayPath, overlayBuffer)

    await new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .input(overlayPath)
        .complexFilter([
          `[0:v]crop='min(iw,ih)':'min(iw,ih)',scale=${size}:${size},fps=8[vid]`,
          `[vid][1:v]overlay=0:0[out]`
        ])
        .outputOptions([
          '-map [out]',
          '-an',
          '-c:v libx264',
          '-preset fast',
          '-crf 26',
          '-t 4'
        ])
        .save(outputPath)
        .on('end', () => resolve())
        .on('error', (err) => reject(err))
    })

    const webpBuffer = fs.readFileSync(outputPath)
    const stickerBuffer = await writeExifVid(webpBuffer)

    await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m.raw })

    try {
      fs.unlinkSync(inputPath)
      fs.unlinkSync(outputPath)
      fs.unlinkSync(overlayPath)
    } catch {}

    await m.react('✅')
  } catch (err) {
    console.error('[SMEMEVID]', err)
    await m.react('❌')
    await m.reply(`❌ Gagal membuat meme video: ${err.message}`)
  }
}