// plugins/downloader/soundcloudplay.js
import axios from 'axios';
import { AIRich } from '../../src/lib/_build-m.js';
import { beautifulMessage } from '../../src/lib/text-formater.js';
import { createFakeQuoted, _mCtx } from '../../src/lib/ctx.js';

const sessions = new Map();
const SESSION_TTL = 5 * 60 * 1000;

export const config_ = {
  name: 'soundcloudplay',
  alias: ['scplay', 'scdl'],
  category: 'downloader',
  description: 'Cari & download lagu dari SoundCloud (AI Rich + audio)',
  usage: '.scplay <query> / .scplay <nomor>',
  example: '.scplay duka\n.scplay 1',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 15,
  isEnabled: true,
};
export { config_ as config };

export async function handler(m, { sock }) {
  const text = m.text?.trim() || '';
  if (!text) {
    return m.reply(
      beautifulMessage('❌ Masukkan query pencarian.\nContoh: .scplay duka', {
        pushName: m.pushName,
      })
    );
  }

  // Jika input adalah angka (1-10), download dari sesi
  if (/^\d+$/.test(text)) {
    const index = parseInt(text) - 1;
    const session = sessions.get(m.senderNumber);
    if (!session || Date.now() > session.expires) {
      sessions.delete(m.senderNumber);
      return m.reply(
        '⌛ Sesi pencarian sudah habis. Silakan cari lagi dengan .scplay <judul>'
      );
    }
    if (index < 0 || index >= session.tracks.length) {
      return m.reply('❌ Nomor tidak valid.');
    }

    const track = session.tracks[index];
    await m.react('⏳');

    try {
      // Download via API
      const dlRes = await axios.get(
        'https://api.siputzx.my.id/api/d/soundcloud',
        {
          params: { url: track.permalink_url },
          timeout: 30000,
        }
      );

      const dlData = dlRes.data;
      if (!dlData.status || !dlData.data?.url) {
        throw new Error(dlData.message || 'Gagal mendapatkan link download');
      }

      const audioUrl = dlData.data.url;
      const title = dlData.data.title || track.title || 'SoundCloud Track';
      const user = dlData.data.user || track.user || 'Unknown';
      const thumbnail = dlData.data.thumbnail || track.artwork_url || '';

      // Kirim AI Rich info
      const infoText =
        `## 🎵 ${title}\n` +
        `**Artist:** ${user}\n` +
        (track.duration
          ? `**Duration:** ${Math.floor(track.duration / 60000)}:${Math.floor(
              (track.duration % 60000) / 1000
            )
              .toString()
              .padStart(2, '0')}\n`
          : '') +
        (track.playback_count
          ? `**Views:** ${track.playback_count.toLocaleString()}\n`
          : '') +
        (track.comment_count
          ? `**Comments:** ${track.comment_count.toLocaleString()}\n`
          : '');

      const builder = new AIRich(sock)
        .setTitle('🎧 SoundCloud')
        .addText(infoText);

      if (thumbnail) {
        builder.addImage(thumbnail);
      }

      builder.addSuggest(['Download Lagi', 'Cari Lagu Lain']);
      const fakeQuoted = createFakeQuoted();
      await builder.send(m.chat, { quoted: fakeQuoted });

      // Download audio buffer
      const audioRes = await axios.get(audioUrl, {
        responseType: 'arraybuffer',
        timeout: 60000,
      });
      const audioBuffer = Buffer.from(audioRes.data);

      if (!audioBuffer || audioBuffer.length === 0) {
        return m.reply(beautifulMessage('❌ Gagal mengunduh audio.', { pushName: m.pushName }));
      }

      // Kirim audio
      await sock.sendMessage(
        m.chat,
        {
          audio: audioBuffer,
          mimetype: 'audio/mpeg',
          fileName: `${title}.mp3`,
          contextInfo: _mCtx(m.sender),
        },
        { quoted: fakeQuoted }
      );

      await m.react('✅');
    } catch (err) {
      console.error('[SCPLAY DOWNLOAD]', err);
      await m.react('❌');
      await m.reply(beautifulMessage(`❌ Gagal mengunduh: ${err.message}`, { pushName: m.pushName }));
    }
    return;
  }

  // Pencarian baru
  await m.react('🔍');

  try {
    const searchRes = await axios.get(
      'https://api.siputzx.my.id/api/s/soundcloud',
      {
        params: { query: text },
        timeout: 15000,
      }
    );

    const result = searchRes.data;

    if (!result.status || !result.data || result.data.length === 0) {
      await m.react('😔');
      return m.reply(`❌ Tidak ada hasil untuk "${text}"`);
    }

    // Filter track yang punya permalink_url (bisa di-download)
    const tracks = result.data
      .filter((t) => t.permalink_url)
      .slice(0, 10);

    if (tracks.length === 0) {
      await m.react('😔');
      return m.reply('❌ Tidak ada track yang bisa di-download.');
    }

    // Simpan sesi
    sessions.set(m.senderNumber, {
      tracks,
      expires: Date.now() + SESSION_TTL,
    });

    // Format produk untuk AIRich
    const products = tracks.map((t, i) => ({
      title: `${i + 1}. ${t.permalink || t.title || 'Untitled'}`,
      brand: t.user?.username || t.user || 'SoundCloud',
      price: t.duration
        ? `${Math.floor(t.duration / 60000)}:${Math.floor(
            (t.duration % 60000) / 1000
          )
            .toString()
            .padStart(2, '0')}`
        : '-',
      image_url: t.artwork_url || '',
      product_url: t.permalink_url || '',
      sale_price: t.playback_count
        ? `${t.playback_count.toLocaleString()} plays`
        : '',
    }));

    await new AIRich(sock)
      .setTitle(`🎵 SoundCloud: "${text}"`)
      .addText(
        `Balas dengan *.scplay <nomor>* (1-${tracks.length}) untuk mendownload.`
      )
      .addProduct(products)
      .addSuggest(tracks.slice(0, 5).map((_, i) => `scplay ${i + 1}`))
      .send(m.chat, { quoted: m.raw });

    await m.react('✅');
  } catch (err) {
    console.error('[SCPLAY]', err);
    await m.react('❌');
    await m.reply(beautifulMessage(`❌ Terjadi kesalahan: ${err.message}`, { pushName: m.pushName }));
  }
}