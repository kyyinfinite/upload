// plugins/downloader/capcut.js
import axios from 'axios';
import { beautifulMessage } from '../../src/lib/text-formater.js';
import { AIRich } from '../../src/lib/_build-m.js';

export const config_ = {
  name: 'capcut',
  alias: ['capcutdl', 'ccdl'],
  category: 'downloader',
  description: 'Download video CapCut tanpa watermark (AI Rich)',
  usage: '.capcut <url>',
  example: '.capcut https://www.capcut.com/tv2/ZSCKrYaWd/',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
};
export { config_ as config };

export async function handler(m, { sock }) {
  let url = m.args[0];

  // Cek apakah ada URL di pesan yang di-quote
  if (!url && m.quoted?.body) {
    const quotedText = m.quoted.body;
    const urlMatch = quotedText.match(/(https?:\/\/(?:www\.)?capcut\.com\/[^\s]+)/);
    if (urlMatch) url = urlMatch[1];
  }

  if (!url) {
    return m.reply(beautifulMessage(
      '❌ Masukkan URL CapCut. Contoh: .capcut https://www.capcut.com/tv2/ZSCKrYaWd/',
      { pushName: m.pushName }
    ));
  }

  if (!/https?:\/\/(?:www\.)?capcut\.com\//i.test(url)) {
    return m.reply(beautifulMessage('❌ URL harus dari CapCut (capcut.com)', { pushName: m.pushName }));
  }

  await m.react('⏳');

  try {
    // Panggil API Nextray
    const response = await axios.get('https://api.nexray.eu.cc/downloader/capcut', {
      params: { url },
      timeout: 30000,
    });

    const result = response.data;

    if (!result || !result.status) {
      return m.reply(beautifulMessage(
        `❌ Gagal mendownload: ${result?.msg || 'Tidak diketahui'}`,
        { pushName: m.pushName }
      ));
    }

    const data = result.data || {};
    const videoUrl = data.url || data.video || data.download || data.download_url;

    if (!videoUrl) {
      return m.reply(beautifulMessage('❌ URL video tidak ditemukan.', { pushName: m.pushName }));
    }

    // Bangun pesan AI Rich
    const builder = new AIRich(sock)
      .setTitle('🎬 CapCut Downloader')
      .addText(`## ${data.title || 'CapCut Template'}\n\n` +
        `👤 **Author:** ${data.author || data.username || 'Unknown'}\n` +
        (data.duration ? `⏱️ **Duration:** ${data.duration}\n` : '') +
        (data.views ? `👁️ **Views:** ${data.views}\n` : '') +
        (data.likes ? `❤️ **Likes:** ${data.likes}\n` : '')
      )
      .addVideo(videoUrl)
      .addSuggest([
        'Download Lagi',
        'Cari Template Lain',
      ]);

    if (data.thumbnail || data.cover) {
      builder.addImage(data.thumbnail || data.cover);
    }

    await builder.send(m.chat, { quoted: m.raw });
    await m.react('✅');

  } catch (err) {
    console.error('[CAPCUT]', err);
    await m.react('❌');
    await m.reply(beautifulMessage(`❌ Error: ${err.message}`, { pushName: m.pushName }));
  }
}