// plugins/downloader/videy.js
import axios from 'axios'
import { beautifulMessage } from '../../src/lib/text-formater.js'
import { AIRich } from '../../src/lib/_build-m.js'

export const config_ = {
  name: 'videy',
  alias: ['videydl', 'vidl'],
  category: 'downloader',
  description: 'Download video dari Videy.co (via Nextray)',
  usage: '.videy <url>',
  example: '.videy https://videy.co/v/xxxxx',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  let url = m.args[0]

  if (!url && m.quoted?.body) {
    const quotedText = m.quoted.body
    const urlMatch = quotedText.match(/(https?:\/\/(?:www\.)?videy\.co\/[^\s]+)/)
    if (urlMatch) url = urlMatch[1]
  }

  if (!url) {
    return m.reply(beautifulMessage(
      '❌ Masukkan URL Videy. Contoh: .videy https://videy.co/v/xxxxx',
      { pushName: m.pushName }
    ))
  }

  if (!/https?:\/\/(?:www\.)?videy\.co\//i.test(url)) {
    return m.reply(beautifulMessage('❌ URL harus dari Videy (videy.co)', { pushName: m.pushName }))
  }

  await m.react('⏳')

  try {
    const res = await axios.get('https://api.nexray.eu.cc/downloader/videy', {
      params: { url },
      timeout: 30000,
    })

    const result = res.data

    if (!result || !result.status) {
      return m.reply(beautifulMessage(
        `❌ Gagal mendownload: ${result?.msg || 'Tidak diketahui'}`,
        { pushName: m.pushName }
      ))
    }

    const data = result.data || {}
    const videoUrl = data.url || data.video || data.download || data.download_url

    if (!videoUrl) {
      return m.reply(beautifulMessage('❌ URL video tidak ditemukan.', { pushName: m.pushName }))
    }

    const builder = new AIRich(sock)
      .setTitle('🎬 Videy Downloader')
      .addText(`## ${data.title || 'Videy Video'}\n` +
        (data.author ? `👤 **Author:** ${data.author}\n` : '') +
        (data.views ? `👁️ **Views:** ${data.views}\n` : '') +
        (data.likes ? `❤️ **Likes:** ${data.likes}\n` : '')
      )
      .addVideo(videoUrl)
      .addSuggest([
        'Download Lagi',
        'Cari Videy Lain',
      ])

    if (data.thumbnail || data.cover) {
      builder.addImage(data.thumbnail || data.cover)
    }

    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[VIDEY]', err)
    await m.react('❌')
    await m.reply(beautifulMessage(`❌ Error: ${err.message}`, { pushName: m.pushName }))
  }
}