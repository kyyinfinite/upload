// plugins/maker/fakeff.js
import axios from 'axios'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'fakeff',
  alias: ['fakelobbyff', 'fflobby', 'fakefflobby'],
  category: 'maker',
  description: 'Buat gambar fake lobby Free Fire dengan nickname',
  usage: '.fakeff <nickname>',
  example: '.fakeff kyydiw',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const nickname = m.text?.trim()
  if (!nickname) {
    return m.reply(
      beautifulMessage(
        '❌ Masukkan nickname Free Fire.\nContoh: .fakeff kyydiw',
        { pushName: m.pushName }
      )
    )
  }

  await m.react('⏳')

  try {
    const apiUrl = 'https://api.nexray.eu.cc/maker/fakelobyff'
    const response = await axios.get(apiUrl, {
      params: { nickname },
      responseType: 'arraybuffer',
      timeout: 30000,
    })

    const imageBuffer = response.data

    if (!imageBuffer || imageBuffer.length === 0) {
      throw new Error('Gambar kosong')
    }

    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: `🎮 *Fake Lobby FF*\n👤 Nickname: ${nickname}`,
        mimetype: 'image/jpeg',
      },
      { quoted: m.raw }
    )

    await m.react('✅')
  } catch (err) {
    console.error('[FAKEFF]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal membuat fake lobby: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}