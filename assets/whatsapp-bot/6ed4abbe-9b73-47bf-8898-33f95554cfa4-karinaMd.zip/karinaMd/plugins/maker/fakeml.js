// plugins/maker/fakeml.js
import axios from 'axios'
import { downloadContentFromMessage } from '@kyyinfinite/baileys'
import { Toolkit } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'fakeml',
  alias: ['fakelobbyml', 'mlfake', 'fakemllobby'],
  category: 'maker',
  description: 'Buat gambar fake lobby Mobile Legends dengan avatar kustom',
  usage: '.fakeml <nickname> (reply gambar)',
  example: '.fakeml kyydiw (reply ke gambar)',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  // 1. Ambil nickname dari argumen
  const nickname = m.text?.trim()
  if (!nickname) {
    return m.reply(
      beautifulMessage(
        '❌ Masukkan nickname Mobile Legends.\nContoh: .fakeml kyydiw',
        { pushName: m.pushName }
      )
    )
  }

  // 2. Cek apakah ada gambar yang di-reply
  const target = m.quoted || m
  const isImage = target.type === 'imageMessage'

  if (!isImage) {
    return m.reply(
      beautifulMessage(
        '❌ Reply gambar yang akan dijadikan avatar.\nContoh: .fakeml kyydiw (reply ke gambar)',
        { pushName: m.pushName }
      )
    )
  }

  await m.react('⏳')

  try {
    // 3. Download gambar dari reply
    const stream = await downloadContentFromMessage(target.message[target.type], 'image')
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }

    if (!buffer || buffer.length === 0) {
      throw new Error('Gagal mendownload gambar')
    }

    // 4. Upload gambar ke CDN WhatsApp menggunakan Toolkit.toUrl
    const avatarUrl = await Toolkit.toUrl(sock, buffer, 'image')

    // 5. Panggil API fakelobbyml dengan avatar URL dan nickname
    const apiUrl = 'https://api.nexray.eu.cc/maker/fakelobyml'
    const response = await axios.get(apiUrl, {
      params: {
        avatar: avatarUrl,
        nickname: nickname,
      },
      responseType: 'arraybuffer',
      timeout: 30000,
    })

    const imageBuffer = response.data

    if (!imageBuffer || imageBuffer.length === 0) {
      throw new Error('Gambar hasil generate kosong')
    }

    // 6. Kirim hasil gambar ke user
    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: `🎮 *Fake Lobby ML*\n👤 Nickname: ${nickname}`,
        mimetype: 'image/jpeg',
      },
      { quoted: m.raw }
    )

    await m.react('✅')
  } catch (err) {
    console.error('[FAKEML]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal membuat fake lobby: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}