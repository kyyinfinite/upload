// plugins/maker/fakedana.js
import axios from 'axios'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'fakedana',
  alias: ['fakedanadana', 'danafake', 'fake dana'],
  category: 'maker',
  description: 'Buat gambar fake saldo DANA dengan nominal',
  usage: '.fakedana <nominal>',
  example: '.fakedana 10000',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const nominal = m.text?.trim()
  if (!nominal) {
    return m.reply(
      beautifulMessage(
        '❌ Masukkan nominal saldo DANA.\nContoh: .fakedana 10000',
        { pushName: m.pushName }
      )
    )
  }

  if (isNaN(nominal) || parseInt(nominal) <= 0) {
    return m.reply(
      beautifulMessage('❌ Masukkan nominal yang valid (angka positif).', {
        pushName: m.pushName,
      })
    )
  }

  await m.react('⏳')

  try {
    const apiUrl = 'https://api.nexray.eu.cc/maker/fakedana'
    const response = await axios.get(apiUrl, {
      params: { nominal: parseInt(nominal) },
      responseType: 'arraybuffer',
      timeout: 30000,
    })

    const imageBuffer = response.data

    if (!imageBuffer || imageBuffer.length === 0) {
      throw new Error('Gambar kosong')
    }

    await sock.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: `💰 *Fake DANA*\n💵 Nominal: Rp ${parseInt(nominal).toLocaleString('id-ID')}`,
        mimetype: 'image/jpeg',
      },
      { quoted: m.raw }
    )

    await m.react('✅')
  } catch (err) {
    console.error('[FAKEDANA]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal membuat fake DANA: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}