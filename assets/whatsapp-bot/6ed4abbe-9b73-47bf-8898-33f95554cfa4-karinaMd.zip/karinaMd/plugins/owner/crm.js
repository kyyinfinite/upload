// plugins/owner/crm.js
import { writeFile, unlink, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import { join } from 'path'
import { AIRich } from '../../src/lib/_build-m.js'

export const config_ = {
  name: 'crm',
  alias: ['rm', 'relay', 'reversemsg', 'convrelay'],
  category: 'owner',
  description: 'CRM — relay pesan apapun, tampilkan kode relay, atau konversi raw JSON ke relay',
  usage: '.crm (reply) | .crm snip | .crm show | .crm json | .crm payload | .crm raw <json>',
  example: '.crm\n.crm snip\n.crm raw {"extendedTextMessage":{"text":"Halo"}}',
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  isEnabled: true,
}
export { config_ as config }

const AIRICH_PAYLOAD_LIMIT = 3500

function getRawFromQuoted(quoted) {
  if (!quoted) return null
  if (quoted.raw && quoted.raw.message) return quoted.raw.message
  if (quoted.message) return quoted.message
  if (quoted.raw && !quoted.raw.message) {
    if (quoted.raw.key && quoted.raw.message) return quoted.raw.message
  }
  if (quoted.key && quoted.message) return quoted.message
  return null
}
function detectType(rawMsg) {
  if (!rawMsg) return 'unknown'
  const msg = rawMsg
  if (msg.botForwardedMessage) return 'botForwardedMessage'
  if (msg.interactiveMessage) return 'interactiveMessage'
  if (msg.viewOnceMessage) return 'viewOnceMessage'
  if (msg.ephemeralMessage) return 'ephemeralMessage'
  if (msg.documentWithCaptionMessage) return 'documentWithCaptionMessage'
  if (msg.protocolMessage) return 'protocolMessage'
  if (msg.reactionMessage) return 'reactionMessage'
  if (msg.buttonsResponseMessage) return 'buttonsResponseMessage'
  if (msg.listResponseMessage) return 'listResponseMessage'
  if (msg.templateButtonReplyMessage) return 'templateButtonReplyMessage'
  const keys = Object.keys(msg)
  const mediaTypes = ['audioMessage', 'videoMessage', 'imageMessage', 'documentMessage', 'stickerMessage', 'locationMessage', 'contactMessage', 'liveLocationMessage']
  for (const k of keys) {
    if (mediaTypes.includes(k)) return k
  }
  if (msg.extendedTextMessage) return 'extendedTextMessage'
  if (msg.conversation) return 'conversation'
  if (msg.pollCreationMessage) return 'pollCreationMessage'
  if (msg.pollUpdateMessage) return 'pollUpdateMessage'
  if (msg.interactiveResponseMessage) return 'interactiveResponseMessage'
  if (msg.requestPaymentMessage) return 'requestPaymentMessage'
  if (msg.senderKeyDistributionMessage) return 'senderKeyDistributionMessage'
  if (msg.messageContextInfo) return 'messageContextInfo'
  const firstKey = keys.find(k => !['senderKeyDistributionMessage', 'messageContextInfo'].includes(k))
  return firstKey || 'unknown'
}

function buildRelayCode(rawMsg) {
  const json = JSON.stringify(rawMsg, null, 2)
  const lines = json.split('\n')
  const indented = lines.map((l, i) => i === 0 ? l : '  ' + l).join('\n')
  return `=> conn.relayMessage(\n  m.chat,\n  ${indented},\n  {}\n)`
}
function buildPayload(rawMsg) {
  const clean = { ...rawMsg }
  delete clean.senderKeyDistributionMessage
  delete clean.messageContextInfo
  if (clean.extendedTextMessage?.contextInfo) {
    const ctx = clean.extendedTextMessage.contextInfo
    if (ctx.quotedMessage && Object.keys(ctx.quotedMessage).length === 0) delete ctx.quotedMessage
    if (ctx.participant && !ctx.quotedMessage) delete ctx.participant
  }
  return clean
}

function getIcon(type) {
  const ICONS = {
    conversation: '💬',
    extendedTextMessage: '💬',
    imageMessage: '🖼️',
    videoMessage: '🎬',
    audioMessage: '🎵',
    documentMessage: '📄',
    stickerMessage: '🎭',
    interactiveMessage: '🔘',
    buttonsResponseMessage: '🔘',
    listResponseMessage: '📋',
    pollCreationMessage: '📊',
    pollUpdateMessage: '📊',
    contactMessage: '👤',
    locationMessage: '📍',
    liveLocationMessage: '📍',
    reactionMessage: '👍',
    requestPaymentMessage: '💳',
    templateButtonReplyMessage: '📝',
    viewOnceMessage: '⏱️',
    ephemeralMessage: '⏱️',
    documentWithCaptionMessage: '📄',
    botForwardedMessage: '🤖',
    interactiveResponseMessage: '🔘',
    protocolMessage: '⚙️',
    senderKeyDistributionMessage: '🔑',
    messageContextInfo: '📋',
    unknown: '📦',
  }
  return ICONS[type] || ICONS.unknown
}

function getSummary(rawMsg, type) {
  let summary = ''
  if (type === 'conversation' || type === 'extendedTextMessage') {
    const text = rawMsg.extendedTextMessage?.text || rawMsg.conversation || ''
    summary = text.slice(0, 50) + (text.length > 50 ? '…' : '')
  } else if (type === 'imageMessage' || type === 'videoMessage' || type === 'audioMessage' || type === 'stickerMessage') {
    const cap = rawMsg[type]?.caption || ''
    summary = cap.slice(0, 40) + (cap.length > 40 ? '…' : '')
  } else if (type === 'documentMessage') {
    const fn = rawMsg.documentMessage?.fileName || ''
    summary = fn.slice(0, 40) + (fn.length > 40 ? '…' : '')
  } else if (type === 'interactiveMessage') {
    const body = rawMsg.interactiveMessage?.body?.text || ''
    summary = body.slice(0, 40) + (body.length > 40 ? '…' : '')
  } else if (type === 'botForwardedMessage') {
    const body = rawMsg.botForwardedMessage?.message?.richResponseMessage?.submessages?.[0]?.messageText || ''
    summary = body.slice(0, 40) + (body.length > 40 ? '…' : '')
  } else if (type === 'buttonsResponseMessage') {
    const txt = rawMsg.buttonsResponseMessage?.selectedDisplayText || rawMsg.buttonsResponseMessage?.selectedButtonId || ''
    summary = txt.slice(0, 40) + (txt.length > 40 ? '…' : '')
  } else if (type === 'listResponseMessage') {
    const txt = rawMsg.listResponseMessage?.singleSelectReply?.selectedRowId || ''
    summary = txt.slice(0, 40) + (txt.length > 40 ? '…' : '')
  } else if (type === 'pollCreationMessage') {
    const q = rawMsg.pollCreationMessage?.name || ''
    summary = q.slice(0, 40) + (q.length > 40 ? '…' : '')
  } else {
    summary = '📦 ' + type
  }
  return summary
}

export async function handler(m, { sock }) {
  const args = m.args || []
  const mode = args[0]?.toLowerCase().replace(/^-/, '').trim() || ''
  const tmpDir = join(process.cwd(), 'storage', '.tmp')
  if (!existsSync(tmpDir)) await mkdir(tmpDir, { recursive: true })
  if (mode === 'raw') {
    const rawText = m.text?.trim() || ''
    if (!rawText) return m.reply('❌ Masukkan JSON mentah setelah .crm raw')
    let rawMsg
    try { rawMsg = JSON.parse(rawText) } catch { return m.reply('❌ Format JSON tidak valid.') }
    try {
      await sock.relayMessage(m.chat, rawMsg, {})
      await m.react('✅')
    } catch (err) {
      await m.react('❌')
      await m.reply(`❌ Relay gagal: \`${err.message}\``)
    }
    return
  }
  if (mode === 'list') {
    if (!m.quoted) return m.reply('❌ Reply pesan yang ingin dilihat strukturnya.')
    const rawMsg = getRawFromQuoted(m.quoted)
    if (!rawMsg) return m.reply('❌ Tidak dapat mengambil raw message.')
    const keys = Object.keys(rawMsg)
    const type = detectType(rawMsg)
    const icon = getIcon(type)
    const text = `${icon} *Struktur Raw Message — ${keys.length} kunci*\n\n` +
      keys.map(k => `• \`${k}\``).join('\n') +
      `\n\nTipe: \`${type}\``
    await sock.sendMessage(m.chat, { text }, { quoted: m.raw })
    await m.react('✅')
    return
  }
  if (mode === 'save') {
    if (!m.quoted) return m.reply('❌ Reply pesan yang ingin disimpan.')
    const rawMsg = getRawFromQuoted(m.quoted)
    if (!rawMsg) return m.reply('❌ Tidak dapat mengambil raw message.')
    const type = detectType(rawMsg)
    const fname = `crm_${Date.now()}_${type}.json`
    const fp = join(tmpDir, fname)
    const jsonStr = JSON.stringify(rawMsg, null, 2)
    await writeFile(fp, jsonStr, 'utf-8')
    await sock.sendMessage(m.chat, {
      document: Buffer.from(jsonStr),
      fileName: fname,
      mimetype: 'application/json',
      caption: `📦 Raw JSON — \`${type}\` (disimpan di storage/.tmp/${fname})`,
    }, { quoted: m.raw })
    setTimeout(() => unlink(fp).catch(() => {}), 30000)
    await m.react('✅')
    return
  }
  if (!m.quoted) {
    return m.reply(
      `❌ *Reply pesan* yang ingin di-relay dengan *.crm*\n\n` +
      `Mode:\n` +
      `• *.crm*         — relay pesan langsung\n` +
      `• *.crm snip*    — tampilkan kode relay + relay\n` +
      `• *.crm show*    — tampilkan kode relay saja (codeblock)\n` +
      `• *.crm json*    — kirim struktur JSON mentah sebagai file\n` +
      `• *.crm payload* — tampilkan payload mentah relay\n` +
      `• *.crm raw <json> — relay dari JSON teks\n` +
      `• *.crm list*    — tampilkan daftar kunci raw message\n` +
      `• *.crm save*    — simpan raw message ke file JSON`
    )
  }
  const rawMsg = getRawFromQuoted(m.quoted)
  if (!rawMsg) return m.reply('❌ Pesan tidak memiliki struktur yang bisa di-relay.')
  if (rawMsg.senderKeyDistributionMessage && !Object.keys(rawMsg).some(k => k !== 'senderKeyDistributionMessage' && k !== 'messageContextInfo')) {
    if (m.quoted.raw?.message) {
      const altRaw = m.quoted.raw.message
      if (!altRaw.senderKeyDistributionMessage) {
        return handler.call(this, { ...m, quoted: { ...m.quoted, message: altRaw } }, { sock })
      }
    }
    return m.reply('❌ Pesan hanya berisi senderKeyDistributionMessage, tidak bisa di-relay.')
  }

  await m.react('⏳')

  const type = detectType(rawMsg)
  const icon = getIcon(type)
  const code = buildRelayCode(rawMsg)
  const payload = buildPayload(rawMsg)
  const summary = getSummary(rawMsg, type)
  if (mode === 'json') {
    const jsonStr = JSON.stringify(rawMsg, null, 2)
    const fname = `crm_${Date.now()}_${type}.json`
    const fp = join(tmpDir, fname)
    await writeFile(fp, jsonStr, 'utf-8')
    await sock.sendMessage(m.chat, {
      document: Buffer.from(jsonStr),
      fileName: fname,
      mimetype: 'application/json',
      caption: `📦 Raw JSON — \`${type}\`\n📝 ${summary}`,
    }, { quoted: m.raw })
    setTimeout(() => unlink(fp).catch(() => {}), 15000)
    await m.react('✅')
    return
  }

  if (mode === 'payload') {
    const payloadStr = JSON.stringify(payload, null, 2)
    if (payloadStr.length > AIRICH_PAYLOAD_LIMIT) {
      const fname = `crm_payload_${Date.now()}.json`
      const fp = join(tmpDir, fname)
      await writeFile(fp, payloadStr, 'utf-8')
      await sock.sendMessage(m.chat, {
        document: Buffer.from(payloadStr),
        fileName: fname,
        mimetype: 'application/json',
        caption: `🧩 Payload — \`${type}\` (terlalu besar, dikirim sebagai file)`,
      }, { quoted: m.raw })
      setTimeout(() => unlink(fp).catch(() => {}), 15000)
    } else {
      try {
        await new AIRich(sock)
          .setTitle(`${icon} CRM Payload`)
          .addCode('json', payloadStr)
          .addText(`Type: \`${type}\`\n📝 ${summary}`)
          .send(m.chat, { quoted: m.raw })
      } catch {
        await sock.sendMessage(m.chat, {
          text: `${icon} *CRM Payload — \`${type}\`*\n\n📝 ${summary}\n\n\`\`\`json\n${payloadStr.slice(0, 3000)}\n\`\`\``,
        }, { quoted: m.raw })
      }
    }
    await m.react('✅')
    return
  }
  if (mode === 'show') {
    if (code.length > AIRICH_PAYLOAD_LIMIT) {
      const fname = `crm_code_${Date.now()}.txt`
      const fp = join(tmpDir, fname)
      await writeFile(fp, code, 'utf-8')
      await sock.sendMessage(m.chat, {
        document: Buffer.from(code),
        fileName: fname,
        mimetype: 'text/javascript',
        caption: `${icon} CRM Code — \`${type}\` (terlalu besar)`,
      }, { quoted: m.raw })
      setTimeout(() => unlink(fp).catch(() => {}), 15000)
    } else {
      try {
        await new AIRich(sock)
          .setTitle(`${icon} CRM Relay Code (Show)`)
          .addCode('javascript', code)
          .addText(`Type: \`${type}\`\n📝 ${summary}`)
          .addSuggest(['.crm', '.crm snip', '.crm json'])
          .send(m.chat, { quoted: m.raw })
      } catch {
        await sock.sendMessage(m.chat, {
          text: `${icon} *CRM — \`${type}\`*\n\n📝 ${summary}\n\n\`\`\`\n${code.slice(0, 3000)}\n\`\`\``,
        }, { quoted: m.raw })
      }
    }
    await m.react('✅')
    return
  }
  if (mode === 'snip') {
    if (code.length > AIRICH_PAYLOAD_LIMIT) {
      const fname = `crm_code_${Date.now()}.txt`
      const fp = join(tmpDir, fname)
      await writeFile(fp, code, 'utf-8')
      await sock.sendMessage(m.chat, {
        document: Buffer.from(code),
        fileName: fname,
        mimetype: 'text/javascript',
        caption: `${icon} CRM Code — \`${type}\` (terlalu besar, relay akan tetap dijalankan)`,
      }, { quoted: m.raw })
      setTimeout(() => unlink(fp).catch(() => {}), 15000)
    } else {
      try {
        await new AIRich(sock)
          .setTitle(`${icon} CRM Relay Code (Snip)`)
          .addCode('javascript', code)
          .addText(`Type: \`${type}\` — relay akan dikirim setelah ini.\n📝 ${summary}`)
          .addSuggest(['.crm show', '.crm json'])
          .send(m.chat, { quoted: m.raw })
      } catch {
        await sock.sendMessage(m.chat, {
          text: `${icon} *CRM Relay — \`${type}\`*\n\n📝 ${summary}\n\n\`\`\`\n${code.slice(0, 3000)}\n\`\`\``,
        }, { quoted: m.raw })
      }
    }
  }

  try {
    await sock.relayMessage(m.chat, rawMsg, {})
    await m.react('✅')
  } catch (err) {
    await m.react('❌')
    await m.reply(`❌ Relay gagal: \`${err.message}\`\n\nGunakan *.crm json* untuk lihat struktur raw-nya.`)
  }
}