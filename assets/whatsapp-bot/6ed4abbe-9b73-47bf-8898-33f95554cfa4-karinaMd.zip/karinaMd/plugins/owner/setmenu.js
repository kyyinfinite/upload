// plugins/owner/setmenu.js
import { getDatabase } from '../../src/database.js'
import { Toolkit } from '../../src/lib/_build-m.js'
import { downloadContentFromMessage } from '@kyyinfinite/baileys'

export const config_ = {
  name: 'setmenu',
  alias: ['setmenutext', 'menuconfig'],
  category: 'owner',
  description: 'Atur tampilan menu (teks, thumbnail, reset)',
  usage: '.setmenu text <teks>\n.setmenu footer <teks>\n.setmenu thumbnail (reply gambar)\n.setmenu reset\n.setmenu show',
  example: '.setmenu text Selamat datang @user!\n.setmenu thumbnail',
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  prefix: false,
  cooldown: 3,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const db = getDatabase()
  const args = m.args || []
  const text = m.text?.trim() || ''

  if (!args.length) {
    return m.reply(
      '📋 *Cara Pakai Setmenu*\n\n' +
      '• *.setmenu text <teks>* — atur teks menu (gunakan @user, @prefix, @bot, @owner, @mode, @time, @date, @categories)\n' +
      '• *.setmenu footer <teks>* — atur footer menu\n' +
      '• *.setmenu thumbnail* (reply gambar) — atur thumbnail\n' +
      '• *.setmenu reset* — kembalikan ke default\n' +
      '• *.setmenu show* — lihat konfigurasi saat ini'
    )
  }

  const sub = args[0].toLowerCase()

  if (sub === 'text') {
    const customText = args.slice(1).join(' ')
    if (!customText) return m.reply('❌ Masukkan teks menu. Contoh: .setmenu text Selamat datang @user!')
    // Simpan teks dengan newline literal dari input
    const savedText = customText.replace(/\\n/g, '\n')
    db.setting('menuText', savedText)
    return m.reply('✅ Teks menu berhasil diatur.\nGunakan `@user`, `@prefix`, `@bot`, `@owner`, `@mode`, `@time`, `@date`, `@categories` sebagai variabel.\nGunakan `\\n` untuk baris baru.')
  }

  if (sub === 'footer') {
    const footerText = args.slice(1).join(' ')
    if (!footerText) return m.reply('❌ Masukkan teks footer. Contoh: .setmenu footer © 2026 Karina MD')
    db.setting('menuFooter', footerText)
    return m.reply('✅ Footer menu berhasil diatur.')
  }

  if (sub === 'thumbnail') {
    const target = m.quoted || m
    const isImage = target.type === 'imageMessage'
    if (!isImage) return m.reply('❌ Reply gambar untuk dijadikan thumbnail menu.')
    try {
      const stream = await downloadContentFromMessage(target.message[target.type], 'image')
      let buffer = Buffer.from([])
      for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
      if (!buffer || !buffer.length) return m.reply('❌ Gagal download gambar.')

      const url = await Toolkit.toUrl(sock, buffer, 'image')
      db.setting('menuThumb', url)
      return m.reply(`✅ Thumbnail menu berhasil diatur.\nURL: ${url}`)
    } catch (err) {
      console.error('[SETMENU]', err)
      return m.reply(`❌ Gagal upload thumbnail: ${err.message}`)
    }
  }

  if (sub === 'reset') {
    db.setting('menuText', null)
    db.setting('menuFooter', null)
    db.setting('menuThumb', null)
    return m.reply('✅ Menu berhasil direset ke default.')
  }

  if (sub === 'show') {
    const currentText = db.setting('menuText') || '(default)'
    const currentFooter = db.setting('menuFooter') || '(default)'
    const currentThumb = db.setting('menuThumb') || '(default)'
    return m.reply(
      '📋 *Konfigurasi Menu Saat Ini*\n\n' +
      `📝 Teks: ${currentText}\n` +
      `📌 Footer: ${currentFooter}\n` +
      `🖼️ Thumbnail: ${currentThumb}`
    )
  }

  // Fallback: jika tidak ada sub command, anggap semua argumen sebagai teks menu
  const customText = args.join(' ').replace(/\\n/g, '\n')
  db.setting('menuText', customText)
  return m.reply('✅ Teks menu berhasil diatur.\nGunakan `@user`, `@prefix`, `@bot`, `@owner`, `@mode`, `@time`, `@date`, `@categories` sebagai variabel.\nGunakan `\\n` untuk baris baru.')
}