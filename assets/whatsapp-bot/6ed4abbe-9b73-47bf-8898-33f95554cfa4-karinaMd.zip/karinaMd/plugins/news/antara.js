// plugins/news/antaranews.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'antaranews',
  alias: ['antara', 'berita', 'news'],
  category: 'news',
  description: 'Berita terkini dari ANTARA News',
  usage: '.antaranews',
  example: '.antaranews',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  await m.react('⏳')

  try {
    const res = await axios.get('https://api.nexray.eu.cc/berita/antara', {
      timeout: 15000,
    })

    const data = res.data
    if (!data.status || !data.result || data.result.length === 0) {
      await m.react('❌')
      return m.reply('❌ Gagal mengambil berita. Coba lagi nanti.')
    }

    const articles = data.result.slice(0, 10)

    const products = articles.map((article, i) => ({
      title: `${i + 1}. ${article.title}`,
      brand: article.category || 'ANTARA',
      price: 'Berita',
      image_url: article.image || '',
      product_url: article.link || '',
      sale_price: article.type || 'article',
    }))

    const builder = new AIRich(sock)
      .setTitle('📰 ANTARA News')
      .addText(`## Berita Terkini\nDitemukan ${articles.length} berita terbaru`)

    if (products.length > 0) {
      builder.addProduct(products)
    }

    const listText = articles
      .map(
        (a, i) =>
          `${i + 1}. [${a.title}](${a.link})\n` +
          `   📂 ${a.category || 'Umum'}`
      )
      .join('\n\n')

    builder.addText(`## 📋 Daftar Berita\n${listText}`)

    builder.addSuggest([
      'antaranews',
      'berita',
    ])

    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[ANTARANEWS]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal mengambil berita: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}