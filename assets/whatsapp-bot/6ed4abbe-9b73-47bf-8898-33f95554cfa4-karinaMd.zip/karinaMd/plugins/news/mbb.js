// plugins/news/mlbb.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'mlbb',
  alias: ['mobilelegends', 'mlnews'],
  category: 'news',
  description: 'Berita terbaru Mobile Legends: Bang Bang',
  usage: '.mlbb',
  example: '.mlbb',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  await m.react('⏳')

  try {
    const res = await axios.get('https://api.nexray.eu.cc/berita/mlbb', {
      timeout: 15000,
    })

    const data = res.data
    if (!data.status || !data.result || !data.result.data || data.result.data.length === 0) {
      await m.react('❌')
      return m.reply('❌ Gagal mengambil berita MLBB. Coba lagi nanti.')
    }

    const articles = data.result.data.slice(0, 10)

    const products = articles.map((article, i) => ({
      title: `${i + 1}. ${article.title}`,
      brand: article.author || 'MLBB',
      price: article.date ? new Date(article.date).toLocaleDateString('id-ID') : '',
      image_url: article.thumbnail || '',
      product_url: article.link || '',
      sale_price: 'Mobile Legends',
    }))

    const builder = new AIRich(sock)
      .setTitle('⚔️ Mobile Legends News')
      .addText(`## Berita Mobile Legends\nDitemukan ${articles.length} berita terbaru`)

    if (products.length > 0) {
      builder.addProduct(products)
    }

    const listText = articles
      .map(
        (a, i) =>
          `${i + 1}. [${a.title}](${a.link})\n` +
          `   👤 ${a.author || 'MLBB'} • 📅 ${a.date ? new Date(a.date).toLocaleDateString('id-ID') : '-'}`
      )
      .join('\n\n')

    builder.addText(`## 📋 Daftar Berita\n${listText}`)

    builder.addSuggest([
      'mlbb',
      'berita',
      'mobilelegends',
    ])

    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[MLBB]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal mengambil berita MLBB: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}