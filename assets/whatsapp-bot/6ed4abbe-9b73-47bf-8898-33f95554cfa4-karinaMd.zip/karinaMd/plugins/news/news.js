// plugins/search/news.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'news',
  alias: ['berita', 'headline', 'newstoday'],
  category: 'news',
  description: 'Cari berita terbaru dari seluruh dunia (NewsAPI)',
  usage: '.news <query>',
  example: '.news apple',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

const API_KEY = 'd771be90e0014fc786418d966c025f0a'
const BASE_URL = 'https://newsapi.org/v2/everything'

export async function handler(m, { sock }) {
  const query = m.text?.trim()
  if (!query) {
    return m.reply(
      beautifulMessage(
        '❌ Masukkan kata kunci berita.\nContoh: .news apple',
        { pushName: m.pushName }
      )
    )
  }

  await m.react('⏳')

  try {
    const today = new Date().toISOString().slice(0, 10)

    const res = await axios.get(BASE_URL, {
      params: {
        q: query,
        from: today,
        to: today,
        sortBy: 'popularity',
        apiKey: API_KEY,
        pageSize: 10,
        language: 'id',
      },
      timeout: 15000,
    })

    const data = res.data

    if (data.status === 'error') {
      await m.react('❌')
      return m.reply(`❌ Error: ${data.message || 'Terjadi kesalahan'}`)
    }

    if (!data.articles || data.articles.length === 0) {
      await m.react('😔')
      return m.reply(`❌ Tidak ada berita untuk "${query}" hari ini.`)
    }

    const articles = data.articles.slice(0, 10)

    const products = articles.map((article, i) => ({
      title: `${i + 1}. ${article.title || 'Tanpa Judul'}`,
      brand: article.source?.name || 'Unknown',
      price: article.publishedAt
        ? new Date(article.publishedAt).toLocaleDateString('id-ID')
        : '-',
      image_url: article.urlToImage || '',
      product_url: article.url || '',
      sale_price: article.author ? `✍️ ${article.author}` : '',
    }))

    const builder = new AIRich(sock)
      .setTitle(`📰 Berita: "${query}"`)
      .addText(`Ditemukan ${data.totalResults || articles.length} artikel`)

    if (products.length > 0) {
      builder.addProduct(products)
    }

    const listText = articles
      .map(
        (a, i) =>
          `${i + 1}. [${a.title || 'Tanpa Judul'}](${a.url || '#'})\n` +
          `   📰 ${a.source?.name || 'Unknown'}` +
          (a.author ? ` • ✍️ ${a.author}` : '') +
          (a.publishedAt
            ? ` • 📅 ${new Date(a.publishedAt).toLocaleDateString('id-ID')}`
            : '') +
          (a.description ? `\n   📝 ${a.description.slice(0, 100)}...` : '')
      )
      .join('\n\n')

    builder.addText(`## 📋 Daftar Berita\n${listText}`)

    builder.addSuggest([
      `news ${query}`,
      'news teknologi',
      'news ekonomi',
      'news politik',
    ])

    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[NEWS]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal mengambil berita: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}