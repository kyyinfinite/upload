// plugins/news/cnnindonesia.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'cnnindonesia',
  alias: ['cnn', 'cnnnews'],
  category: 'news',
  description: 'Berita terkini dari CNN Indonesia',
  usage: '.cnnindonesia',
  example: '.cnnindonesia',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  await m.react('⏳')

  try {
    const res = await axios.get('https://api.nexray.eu.cc/berita/cnn', {
      timeout: 15000,
    })

    const data = res.data
    if (!data.status || !data.result || data.result.length === 0) {
      await m.react('❌')
      return m.reply('❌ Gagal mengambil berita CNN Indonesia. Coba lagi nanti.')
    }

    const articles = data.result.slice(0, 10)

    const products = articles.map((article, i) => ({
      title: `${i + 1}. ${article.title}`,
      brand: 'CNN Indonesia',
      price: 'Berita',
      image_url: article.image_thumbnail || '',
      product_url: article.link || '',
      sale_price: article.time || '',
    }))

    const builder = new AIRich(sock)
      .setTitle('📰 CNN Indonesia')
      .addText(`## Berita Terkini\nDitemukan ${articles.length} berita terbaru`)

    if (products.length > 0) {
      builder.addProduct(products)
    }

    const listText = articles
      .map(
        (a, i) =>
          `${i + 1}. [${a.title}](${a.link})\n` +
          `   📅 ${a.time || '-'}`
      )
      .join('\n\n')

    builder.addText(`## 📋 Daftar Berita\n${listText}`)

    builder.addSuggest([
      'cnnindonesia',
      'berita',
      'cnn',
    ])

    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[CNNINDONESIA]', err)
    await m.react('❌')
    await m.reply(
      beautifulMessage(`❌ Gagal mengambil berita: ${err.message}`, {
        pushName: m.pushName,
      })
    )
  }
}