// plugins/main/ping.js
import { createCanvas } from '@napi-rs/canvas';
import GIFEncoder from 'gifencoder';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import config from '../../config.js';

const execAsync = promisify(exec);

export const config_ = {
  name: 'ping',
  alias: ['speed', 'p', 'latency'],
  category: 'main',
  description: 'Cek performa dan status sistem bot (animated GIF)',
  usage: '.ping',
  example: '.ping',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  prefix: false,
  isEnabled: true,
}
export { config_ as config }

function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (days > 0) return `${days}d ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

async function generateServerStatsGIF() {
  const WIDTH = 600;
  const HEIGHT = 350;
  const FRAMES = 15;
  const FRAME_DELAY = 150;

  const COLORS = {
    background: '#D4E9F7',
    cardBg: 'rgba(255, 255, 255, 0.95)',
    cardBorder: 'rgba(59, 130, 246, 0.2)',
    primary: '#0F172A',
    secondary: '#475569',
    accent: '#3B82F6',
    accentLight: '#60A5FA',
    success: '#10B981',
    cyan: '#06B6D4',
    graphStroke: '#FFFFFF',
    graphFillTop: 'rgba(59, 130, 246, 0.5)',
    graphFillBottom: 'rgba(59, 130, 246, 0.05)',
    grid: 'rgba(148, 163, 184, 0.15)',
    gridDark: 'rgba(100, 116, 139, 0.25)',
    shadow: 'rgba(0, 0, 0, 0.08)'
  };

  const getMetrics = () => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePercent = ((usedMem / totalMem) * 100).toFixed(1);
    
    const cpus = os.cpus();
    const cpuUsage = cpus.reduce((acc, cpu) => {
      const total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
      const idle = cpu.times.idle;
      return acc + ((total - idle) / total) * 100;
    }, 0) / cpus.length;

    const uptime = process.uptime();
    const uptimeFormatted = formatUptime(uptime);
    const latencyData = Array.from({ length: 50 }, (_, i) => {
      return 30 + Math.sin(i * 0.3) * 15 + Math.random() * 10;
    });

    return {
      nodeVersion: process.version,
      platform: os.platform(),
      arch: os.arch(),
      cpuUsage: cpuUsage.toFixed(1),
      memUsagePercent,
      usedMemGB: (usedMem / (1024 ** 3)).toFixed(2),
      totalMemGB: (totalMem / (1024 ** 3)).toFixed(2),
      uptime: uptimeFormatted,
      latencyData,
      currentLatency: Math.round(30 + Math.random() * 20),
      cralinMs: 65,
      exalictsMs: 65
    };
  };

  const encoder = new GIFEncoder(WIDTH, HEIGHT);
  encoder.start();
  encoder.setRepeat(0);
  encoder.setDelay(FRAME_DELAY);
  encoder.setQuality(10);

  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext('2d');

  const metrics = getMetrics();
  const latencyHistory = [...metrics.latencyData];

  const drawCard = (ctx, x, y, w, h) => {
    ctx.save();
    ctx.shadowColor = COLORS.shadow;
    ctx.shadowBlur = 8;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 2;
    ctx.fillStyle = COLORS.cardBg;
    ctx.fillRect(x, y, w, h);
    ctx.shadowBlur = 0;
    ctx.strokeStyle = COLORS.cardBorder;
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, w, h);
    ctx.restore();
  };

  const drawNodeIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.fillStyle = COLORS.success;
    ctx.strokeStyle = COLORS.success;
    ctx.lineWidth = 2;
    
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, size/2.5, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = COLORS.cardBg;
    ctx.font = `bold ${size/1.8}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('N', x + size/2, y + size/2);
    ctx.restore();
  };

  const drawClockIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, size/2.2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + size/2, y + size/2);
    ctx.lineTo(x + size/2, y + size*0.25);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + size/2, y + size/2);
    ctx.lineTo(x + size*0.7, y + size/2);
    ctx.stroke();
    ctx.restore();
  };

  const drawCPUIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + size*0.25, y + size*0.25, size*0.5, size*0.5);
    for (let i = 0; i < 2; i++) {
      const offset = size*0.35 + i*size*0.3;
      ctx.beginPath();
      ctx.moveTo(x, y + offset);
      ctx.lineTo(x + size*0.25, y + offset);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x + size*0.75, y + offset);
      ctx.lineTo(x + size, y + offset);
      ctx.stroke();
    }
    ctx.restore();
  };

  const drawMemoryIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.cyan;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x + size*0.1, y + size*0.2, size*0.8, size*0.6);
    ctx.fillStyle = COLORS.background;
    ctx.fillRect(x + size*0.45, y + size*0.2, size*0.1, size*0.12);
    ctx.fillStyle = COLORS.cyan;
    for (let i = 0; i < 4; i++) {
      ctx.fillRect(x + size*0.2 + i*size*0.18, y + size*0.72, size*0.08, size*0.12);
    }
    ctx.restore();
  };

  const drawSignalIcon = (ctx, x, y, size, frame) => {
    ctx.save();
    const pulsePhase = (frame % 15) / 15;
    for (let i = 0; i < 3; i++) {
      const phase = (pulsePhase + i * 0.33) % 1;
      const radius = size*0.25 + size*0.6*phase;
      const opacity = 0.5 * (1 - phase);
      ctx.strokeStyle = `rgba(59, 130, 246, ${opacity})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x + size/2, y + size/2, radius, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.fillStyle = COLORS.accent;
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  const drawProgressBar = (ctx, x, y, width, height, percentage, color) => {
    ctx.save();
    ctx.fillStyle = COLORS.grid;
    ctx.fillRect(x, y, width, height);
    const fillWidth = Math.min((width * percentage) / 100, width);
    const gradient = ctx.createLinearGradient(x, 0, x + fillWidth, 0);
    gradient.addColorStop(0, color);
    gradient.addColorStop(1, color);
    ctx.fillStyle = gradient;
    ctx.fillRect(x, y, fillWidth, height);
    ctx.strokeStyle = COLORS.cardBorder;
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, width, height);
    ctx.restore();
  };

  const drawVerticalBar = (ctx, x, y, width, height, percentage, color) => {
    ctx.save();
    ctx.fillStyle = COLORS.grid;
    ctx.fillRect(x, y, width, height);
    const fillHeight = (height * percentage) / 100;
    ctx.fillStyle = color;
    ctx.fillRect(x, y + height - fillHeight, width, fillHeight);
    ctx.strokeStyle = COLORS.cardBorder;
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, width, height);
    ctx.restore();
  };

  const drawLatencyGraph = (ctx, x, y, width, height, data, frame) => {
    ctx.save();
    
    ctx.fillStyle = COLORS.cardBg;
    ctx.fillRect(x, y, width, height);
    
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 0.5;
    ctx.setLineDash([2, 3]);
    for (let i = 0; i <= 5; i++) {
      const yPos = y + (height / 5) * i;
      ctx.beginPath();
      ctx.moveTo(x, yPos);
      ctx.lineTo(x + width, yPos);
      ctx.stroke();
    }
    for (let i = 0; i <= 10; i++) {
      const xPos = x + (width / 10) * i;
      ctx.beginPath();
      ctx.moveTo(xPos, y);
      ctx.lineTo(xPos, y + height);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    
    const offset = frame * 2;
    const shiftedData = [];
    for (let i = 0; i < data.length; i++) {
      shiftedData.push(data[(i + offset) % data.length]);
    }
    
    const maxLatency = Math.max(...data);
    const minLatency = Math.min(...data);
    const range = maxLatency - minLatency || 1;
    const padding = height * 0.1;
    
    ctx.beginPath();
    shiftedData.forEach((value, i) => {
      const xPos = x + (width / (shiftedData.length - 1)) * i;
      const normalizedValue = (value - minLatency) / range;
      const yPos = y + height - (normalizedValue * (height - padding * 2)) - padding;
      
      if (i === 0) {
        ctx.moveTo(xPos, yPos);
      } else {
        const prevXPos = x + (width / (shiftedData.length - 1)) * (i - 1);
        const prevValue = shiftedData[i - 1];
        const prevNormalized = (prevValue - minLatency) / range;
        const prevYPos = y + height - (prevNormalized * (height - padding * 2)) - padding;
        
        const cpX = (prevXPos + xPos) / 2;
        ctx.quadraticCurveTo(cpX, prevYPos, xPos, yPos);
      }
    });
    
    const lastX = x + width;
    const lastY = y + height - ((shiftedData[shiftedData.length - 1] - minLatency) / range * (height - padding * 2)) - padding;
    
    ctx.lineTo(lastX, y + height);
    ctx.lineTo(x, y + height);
    ctx.closePath();
    
    const gradient = ctx.createLinearGradient(0, y, 0, y + height);
    gradient.addColorStop(0, COLORS.graphFillTop);
    gradient.addColorStop(0.5, 'rgba(59, 130, 246, 0.25)');
    gradient.addColorStop(1, COLORS.graphFillBottom);
    ctx.fillStyle = gradient;
    ctx.fill();
    
    ctx.beginPath();
    shiftedData.forEach((value, i) => {
      const xPos = x + (width / (shiftedData.length - 1)) * i;
      const normalizedValue = (value - minLatency) / range;
      const yPos = y + height - (normalizedValue * (height - padding * 2)) - padding;
      
      if (i === 0) {
        ctx.moveTo(xPos, yPos);
      } else {
        const prevXPos = x + (width / (shiftedData.length - 1)) * (i - 1);
        const prevValue = shiftedData[i - 1];
        const prevNormalized = (prevValue - minLatency) / range;
        const prevYPos = y + height - (prevNormalized * (height - padding * 2)) - padding;
        
        const cpX = (prevXPos + xPos) / 2;
        ctx.quadraticCurveTo(cpX, prevYPos, xPos, yPos);
      }
    });
    
    ctx.strokeStyle = COLORS.graphStroke;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = 'rgba(59, 130, 246, 0.5)';
    ctx.shadowBlur = 6;
    ctx.stroke();
    ctx.shadowBlur = 0;
    
    ctx.restore();
  };

  for (let frame = 0; frame < FRAMES; frame++) {
    ctx.save();

    ctx.fillStyle = COLORS.background;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 20px Arial';
    ctx.fillText('Server Statistics Dashboard', 20, 30);

    const row1Y = 45;
    const row2Y = 125;
    const row3Y = 205;
    const graphY = 245;
    
    drawCard(ctx, 15, row1Y, 180, 70);
    drawNodeIcon(ctx, 25, row1Y + 12, 22);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Node.js', 53, row1Y + 20);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '11px Arial';
    ctx.fillText(metrics.nodeVersion, 53, row1Y + 35);
    ctx.fillText(`${metrics.platform} (${metrics.arch})`, 53, row1Y + 50);

    drawCard(ctx, 205, row1Y, 180, 70);
    drawClockIcon(ctx, 215, row1Y + 12, 22);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Uptime', 243, row1Y + 20);
    ctx.fillStyle = COLORS.success;
    ctx.font = 'bold 16px Arial';
    ctx.fillText(metrics.uptime, 243, row1Y + 45);

    drawCard(ctx, 395, row1Y, 190, 70);
    drawSignalIcon(ctx, 405, row1Y + 12, 22, frame);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Response Time', 433, row1Y + 20);
    ctx.fillStyle = COLORS.accent;
    ctx.font = 'bold 18px Arial';
    ctx.fillText(`${metrics.currentLatency} ms`, 433, row1Y + 45);

    drawCard(ctx, 15, row2Y, 180, 70);
    drawCPUIcon(ctx, 25, row2Y + 12, 22);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('CPU Usage', 53, row2Y + 20);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '11px Arial';
    ctx.fillText(`${metrics.cpuUsage}%`, 53, row2Y + 35);
    drawProgressBar(ctx, 25, row2Y + 50, 160, 8, parseFloat(metrics.cpuUsage), COLORS.accent);

    drawCard(ctx, 205, row2Y, 180, 70);
    drawMemoryIcon(ctx, 215, row2Y + 12, 22);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Memory', 243, row2Y + 20);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '11px Arial';
    ctx.fillText(`${metrics.usedMemGB} / ${metrics.totalMemGB} GB`, 243, row2Y + 35);
    drawProgressBar(ctx, 215, row2Y + 50, 160, 8, parseFloat(metrics.memUsagePercent), COLORS.cyan);

    drawCard(ctx, 395, row2Y, 90, 70);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 11px Arial';
    ctx.fillText('Cralin', 405, row2Y + 18);
    ctx.fillStyle = COLORS.accent;
    ctx.font = 'bold 16px Arial';
    ctx.fillText(`${metrics.cralinMs}`, 405, row2Y + 38);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '10px Arial';
    ctx.fillText('ms', 445, row2Y + 38);
    drawVerticalBar(ctx, 455, row2Y + 15, 20, 45, 75, COLORS.accent);

    drawCard(ctx, 495, row2Y, 90, 70);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 11px Arial';
    ctx.fillText('Exalicts', 505, row2Y + 18);
    ctx.fillStyle = COLORS.cyan;
    ctx.font = 'bold 16px Arial';
    ctx.fillText(`${metrics.exalictsMs}`, 505, row2Y + 38);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '10px Arial';
    ctx.fillText('ms', 545, row2Y + 38);
    drawVerticalBar(ctx, 555, row2Y + 15, 20, 45, 75, COLORS.cyan);

    drawCard(ctx, 15, graphY, 570, 90);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 12px Arial';
    ctx.fillText('Network Latency', 25, graphY + 15);
    drawLatencyGraph(ctx, 25, graphY + 25, 550, 55, latencyHistory, frame);

    ctx.restore();
    encoder.addFrame(ctx);
  }

  encoder.finish();
  return encoder.out.getData();
}

// ─── Konversi GIF ke MP4 ─────────────────────────────────────────────
async function convertGifToMp4(gifBuffer) {
  const tmpDir = path.join(process.cwd(), 'storage', '.tmp');
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

  const id = Date.now().toString(36);
  const gifPath = path.join(tmpDir, `ping_${id}.gif`);
  const mp4Path = path.join(tmpDir, `ping_${id}.mp4`);

  try {
    // Tulis GIF ke file sementara
    fs.writeFileSync(gifPath, gifBuffer);

    // Konversi ke MP4 dengan ffmpeg
    await execAsync(
      `ffmpeg -y -i "${gifPath}" -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" -c:v libx264 -crf 23 -preset veryfast "${mp4Path}"`,
      { timeout: 30000 }
    );

    // Baca MP4
    const mp4Buffer = fs.readFileSync(mp4Path);
    if (!mp4Buffer || mp4Buffer.length === 0) {
      throw new Error('MP4 buffer kosong');
    }

    return mp4Buffer;
  } finally {
    // Bersihkan file
    try { fs.unlinkSync(gifPath); } catch {}
    try { fs.unlinkSync(mp4Path); } catch {}
  }
}

export async function handler(m, { sock }) {
  await m.react('⏳');

  try {
    const gifBuffer = await generateServerStatsGIF();
    if (!gifBuffer || gifBuffer.length === 0) {
      throw new Error('Buffer GIF kosong');
    }
    const mp4Buffer = await convertGifToMp4(gifBuffer);
    await sock.sendMessage(m.chat, {
      video: mp4Buffer,
      mimetype: 'video/mp4',
      gifPlayback: true,
      caption: `📊 *${config.bot?.name || 'Bot'} Server Status*\nUptime: ${formatUptime(process.uptime())}`,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363208449943317@newsletter',
          newsletterName: 'Karina MD',
          serverMessageId: Date.now()
        }
      }
    }, { quoted: m.raw });

    await m.react('✅');
  } catch (err) {
    console.error('[PING] Error:', err);
    await m.react('❌');
    // Fallback ke teks
    const fallbackText = 
`📊 *${config.bot?.name || 'Bot'} Server Status*
Uptime: ${formatUptime(process.uptime())}
Node: ${process.version}
CPU: ${os.cpus().length} cores
Memory: ${(os.totalmem() / 1024 ** 3).toFixed(1)} GB total
Load: ${os.loadavg().map(v => v.toFixed(2)).join(', ')}`;
    await m.reply(`❌ Gagal membuat GIF: ${err.message}\n\n${fallbackText}`);
  }
}
