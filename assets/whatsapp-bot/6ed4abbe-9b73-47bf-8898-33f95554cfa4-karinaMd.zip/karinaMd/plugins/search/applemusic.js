// plugins/search/applemusic.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'

const sessions = new Map()
const SESSION_TTL = 5 * 60 * 1000

export const config_ = {
  name: 'applemusic',
  alias: ['am', 'apple', 'applem'],
  category: 'search',
  description: 'Cari dan download lagu dari Apple Music',
  usage: '.applemusic <query> / .applemusic <nomor>',
  example: '.applemusic duka\n.applemusic 1',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  prefix: false,
  isPrivate: false,
  cooldown: 8,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const text = m.text?.trim() || ''
  if (!text) {
    return m.reply('❌ Masukkan query pencarian.\nContoh: .applemusic duka')
  }
  if (/^\d+$/.test(text)) {
    const index = parseInt(text) - 1
    const session = sessions.get(m.senderNumber)
    if (!session || Date.now() > session.expires) {
      sessions.delete(m.senderNumber)
      return m.reply('⌛ Sesi pencarian sudah habis. Silakan cari lagi dengan .applemusic <judul>')
    }
    if (index < 0 || index >= session.tracks.length) {
      return m.reply('❌ Nomor tidak valid.')
    }

    const track = session.tracks[index]
    await m.react('⏳')

    try {
      const dlRes = await axios.get('https://api.nexray.eu.cc/downloader/applemusic', {
        params: { url: track.link },
        timeout: 30000,
      })

      const dlData = dlRes.data
      if (!dlData?.status || !dlData?.data?.url) {
        throw new Error(dlData?.msg || 'Gagal mendapatkan link download')
      }

      const audioUrl = dlData.data.url
      const title = dlData.data.title || track.title || 'Apple Music Track'
      const artist = dlData.data.artist || track.artist || 'Unknown'

      const audioRes = await axios.get(audioUrl, {
        responseType: 'arraybuffer',
        timeout: 60000,
      })
      const audioBuffer = Buffer.from(audioRes.data)

      if (!audioBuffer || audioBuffer.length === 0) {
        return m.reply('❌ Gagal mengunduh audio.')
      }

      await sock.sendMessage(m.chat, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`,
        caption: `🎵 *${title}*\n👤 ${artist}\n🔗 [Apple Music](${track.link})`,
      }, { quoted: m.raw })

      if (track.image) {
        await sock.sendMessage(m.chat, {
          image: { url: track.image },
          caption: `🎵 *${title}*\n👤 ${artist}`,
        }, { quoted: m.raw })
      }

      await m.react('✅')
    } catch (e) {
      console.error('[APPLEMUSIC DOWNLOAD]', e)
      await m.react('❌')
      await m.reply(`❌ Gagal mengunduh: ${e.message}`)
    }
    return
  }

  await m.react('🔍')

  try {
    const res = await axios.get('https://api.siputzx.my.id/api/s/applemusic', {
      params: {
        query: text,
        region: 'id',
      },
      timeout: 15000,
    })

    const result = res.data

    if (!result.status || !result.data || result.data.length === 0) {
      await m.react('😔')
      return m.reply(`❌ Tidak ada hasil untuk "${text}"`)
    }

    const tracks = result.data.slice(0, 10)

    sessions.set(m.senderNumber, {
      tracks,
      expires: Date.now() + SESSION_TTL,
    })

    const products = tracks.map((t, i) => ({
      title: `${i + 1}. ${t.title}`,
      brand: t.artist || 'Unknown',
      price: 'Apple Music',
      image_url: t.image || '',
      product_url: t.link || '',
      sale_price: '🎵',
    }))

    await new AIRich(sock)
      .setTitle(`🍎 Apple Music: "${text}"`)
      .addText(`Balas dengan *.applemusic <nomor>* (1-${tracks.length}) untuk mendownload.`)
      .addProduct(products)
      .addSuggest(tracks.slice(0, 5).map((_, i) => `applemusic ${i + 1}`))
      .send(m.chat, { quoted: m.raw })

    await m.react('✅')
  } catch (e) {
    console.error('[APPLEMUSIC]', e)
    await m.react('❌')
    await m.reply(`❌ Terjadi kesalahan: ${e.message}`)
  }
}