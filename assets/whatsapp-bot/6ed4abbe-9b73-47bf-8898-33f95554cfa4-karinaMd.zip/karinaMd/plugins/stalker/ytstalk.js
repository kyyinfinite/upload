// plugins/stalk/stalkyoutube.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'

export const config_ = {
  name: 'stalkyoutube',
  alias: ['ytstalk', 'youtubestalk'],
  category: 'stalk',
  description: 'Cek statistik channel YouTube',
  usage: '.stalkyoutube <channelID atau username>',
  example: '.stalkyoutube mrbeast',
  isOwner: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

async function fetchYouTube(query) {
  try {
    const res = await axios.get('https://api.nexray.eu.cc/stalker/youtube', {
      params: { username: query },
      timeout: 15000,
    })

    const data = res.data
    if (!data.status || !data.result?.channel) {
      throw new Error(data.message || 'Channel tidak ditemukan')
    }

    const channel = data.result.channel

    const cleanSubs = channel.subscriberCount?.replace(/[^0-9.]/g, '') || '0'
    const cleanVideos = channel.videoCount?.replace(/[^0-9]/g, '') || '0'

    return {
      channelId: channel.channelUrl?.split('/').pop() || query,
      title: channel.username?.replace('@', '') || channel.name || 'Unknown',
      description: channel.description || 'Tidak ada deskripsi',
      thumbnail: channel.avatarUrl || null,
      subscribers: parseFloat(cleanSubs) || 0,
      views: 0,
      videos: parseInt(cleanVideos) || 0,
      joined: 'Tidak diketahui',
      channelUrl: channel.channelUrl,
    }
  } catch (err) {
    console.error('[YTSTALK]', err.message)
    throw new Error(`Gagal mengambil data YouTube: ${err.message}`)
  }
}

export async function handler(m, { sock }) {
  const query = m.text?.trim()
  if (!query) {
    return m.reply('❌ Masukkan username atau Channel ID. Contoh: .stalkyoutube mrbeast')
  }

  await m.react('⏳')

  try {
    const data = await fetchYouTube(query)

    const text =
      `## 📺 Profil YouTube Channel\n` +
      `**Nama:** ${data.title}\n` +
      `**Channel ID:** ${data.channelId}\n` +
      `**Bergabung:** ${data.joined}\n` +
      `**Subscribers:** ${data.subscribers.toLocaleString()}\n` +
      `**Total Videos:** ${data.videos.toLocaleString()}\n` +
      `**Deskripsi:** ${data.description.slice(0, 300)}${data.description.length > 300 ? '...' : ''}\n` +
      (data.channelUrl ? `**🔗:** ${data.channelUrl}` : '')

    const builder = new AIRich(sock).setTitle('🎬 YouTube Stalker')
    if (data.thumbnail) {
      builder.addImage(data.thumbnail)
    }
    builder.addText(text)
    builder.addSuggest(['stalkyoutube', 'stalktwitter', 'stalkroblox'])
    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    await m.react('❌')
    await m.reply(`❌ Gagal: ${err.message}`)
  }
}