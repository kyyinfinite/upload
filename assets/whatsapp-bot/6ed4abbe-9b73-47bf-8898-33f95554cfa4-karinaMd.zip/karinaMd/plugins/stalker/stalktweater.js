// plugins/stalk/stalktwitter.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'

export const config_ = {
  name: 'stalktwitter',
  alias: ['twitterstalk', 'xstalk'],
  category: 'stalk',
  description: 'Cek profil pengguna Twitter/X',
  usage: '.stalktwitter <username>',
  example: '.stalktwitter elonmusk',
  isOwner: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const username = m.text?.trim()
  if (!username) return m.reply('❌ Masukkan username Twitter. Contoh: .stalktwitter elonmusk')

  await m.react('⏳')
  try {
    const res = await axios.get(`https://api.nexray.eu.cc/stalker/twitter?username=${encodeURIComponent(username)}`, { timeout: 15000 })
    const data = res.data

    if (!data?.status || !data?.result) {
      throw new Error(data?.message || 'User tidak ditemukan')
    }

    const user = data.result

    const text = `## 🐦 Profil Twitter\n**Username:** @${user.username || user.screen_name || '-'}\n**Name:** ${user.name || user.display_name || '-'}\n**Bio:** ${user.description || user.bio || '-'}\n**Followers:** ${user.followers || user.followers_count || 0}\n**Following:** ${user.following || user.friends_count || 0}\n**Tweets:** ${user.tweets || user.statuses_count || 0}\n**Joined:** ${user.joined || user.created_at || '-'}`

    const builder = new AIRich(sock).setTitle('🐦 Twitter Stalk')
    if (user.avatar || user.profile_image_url) {
      builder.addImage(user.avatar || user.profile_image_url)
    }
    builder.addText(text)
    builder.addSuggest(['stalktwitter', 'stalkig', 'stalkgithub'])
    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    await m.react('❌')
    await m.reply(`❌ Gagal: ${err.message}`)
  }
}