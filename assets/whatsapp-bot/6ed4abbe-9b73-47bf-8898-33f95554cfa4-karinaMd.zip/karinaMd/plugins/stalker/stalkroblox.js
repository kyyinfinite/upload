// plugins/stalk/stalkroblox.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'stalkroblox',
  alias: ['robloxstalk', 'rblxstalk', 'rbxstalk', 'stalkrbx'],
  category: 'stalk',
  description: 'Cek profil pengguna Roblox (lengkap)',
  usage: '.stalkroblox <username>',
  example: '.stalkroblox Builderman',
  isOwner: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

const presenceType = {
  0: 'Offline',
  1: 'Online',
  2: 'In Game',
  3: 'In Studio',
}

async function Roblox(username) {
  try {
    const res = await axios.get(
      `https://api.nexray.eu.cc/stalker/roblox?username=${encodeURIComponent(username)}`,
      { timeout: 15000 }
    )

    if (!res.data?.status || !res.data?.result) {
      return { error: res.data?.message || 'User tidak ditemukan' }
    }

    const d = res.data.result

    const basic = d.basic || {}
    const social = d.social || {}
    const avatar = d.avatar || {}
    const presence = d.presence || {}
    const achievements = d.achievements || {}
    const catalog = d.catalog || {}

    let avatarUrl = null
    if (avatar.fullBody?.data?.length > 0) {
      avatarUrl = avatar.fullBody.data[0].imageUrl
    } else if (avatar.headshot?.data?.length > 0) {
      avatarUrl = avatar.headshot.data[0].imageUrl
    }


    const badges = achievements.robloxBadges || []


    const bundles = catalog.bundles?.data || []


    const groups = d.groups?.list?.data || []


    const games = []

    return {
      id: basic.id || d.userId,
      username: basic.name || username,
      displayName: basic.displayName || basic.name || username,
      description: basic.description || '-',
      created: basic.created,
      verified: basic.hasVerifiedBadge || false,
      isBanned: basic.isBanned || false,
      avatar: avatarUrl,
      social: {
        followers: social.followers?.count || 0,
        following: social.following?.count || 0,
        friends: social.friends?.count || 0,
      },
      groups: groups,
      games: games,
      badges: badges,
      inventory: bundles.length > 0 ? bundles : 'tidak tersedia',
      presence: presence.userPresences?.[0] || null,
      raw: d,
    }
  } catch (err) {
    console.error('[ROBLOX-STALK]', err)
    return { error: err.message || 'Gagal mengambil data' }
  }
}

export async function handler(m, { sock }) {
  const username = m.args?.[0] || m.text?.trim()
  if (!username) {
    return m.reply(
      `🎮 *Roblox Stalk*\n\n` +
        `Masukkan username Roblox.\n` +
        `Contoh: *.stalkroblox Builderman*`
    )
  }

  await m.react('⏳')

  try {
    const res = await Roblox(username)

    if (res.error) {
      await m.react('❌')
      return m.reply(`❌ ${res.error}`)
    }

    // ─── Format info ──────────────────────────────────────────────
    const topGroups =
      res.groups
        .slice(0, 5)
        .map(
          g =>
            `  ◦ ${g.group?.name || 'Unknown'} (${g.group?.memberCount?.toLocaleString() || 0} members) — ${g.role?.name || 'Member'}`
        )
        .join('\n') || '  ◦ Tidak ada'

    const topBadges =
      res.badges
        .slice(0, 5)
        .map(b =>
          `  ◦ ${b.name} — ${b.description?.slice(0, 50) || '-'}`
        )
        .join('\n') || '  ◦ Tidak ada'

    const topInventory = Array.isArray(res.inventory)
      ? res.inventory
          .slice(0, 5)
          .map(
            item =>
              `  ◦ ${item.name} (${item.bundleType || 'Item'})`
          )
          .join('\n')
      : `  ◦ ${res.inventory}`

    const presInfo = res.presence
      ? `Status: ${presenceType[res.presence.userPresenceType] || res.presence.userPresenceType}\n  Last Location: ${res.presence.lastLocation || '-'}`
      : 'tidak tersedia'

    const text =
      `## 🎮 Profil Roblox\n` +
      `**ID:** ${res.id}\n` +
      `**Username:** ${res.username}\n` +
      `**Display Name:** ${res.displayName || '-'}\n` +
      `**Verified:** ${res.verified ? '✅ Ya' : '❌ Tidak'}\n` +
      `**Banned:** ${res.isBanned ? '⚠️ Ya' : '✅ Tidak'}\n` +
      `**Bergabung:** ${res.created ? new Date(res.created).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '-'}\n\n` +
      `👥 **Friends:** ${res.social.friends.toLocaleString()}\n` +
      `👤 **Followers:** ${res.social.followers.toLocaleString()}\n` +
      `➕ **Following:** ${res.social.following.toLocaleString()}\n\n` +
      `*📍 Presence*\n${presInfo}\n\n` +
      `📝 *Bio:*\n${res.description?.substring(0, 300) || '-'}\n\n` +
      `👥 *Groups* (${res.groups.length}):\n${topGroups}\n\n` +
      `🏆 *Badges* (${res.badges.length}):\n${topBadges}\n\n` +
      `🎒 *Inventory*:\n${topInventory}`

    const builder = new AIRich(sock).setTitle('🎮 Roblox Stalker')

    if (res.avatar) {
      builder.addImage(res.avatar)
    }

    builder.addText(text)
    builder.addSuggest(['stalkroblox', 'stalkff', 'stalkml'])

    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[ROBLOX-STALK]', err)
    await m.react('❌')
    await m.reply(beautifulMessage(`❌ Gagal: ${err.message}`, { pushName: m.pushName }))
  }
}