// plugins/stalk/stalkff.js
import axios from 'axios'
import { AIRich } from '../../src/lib/_build-m.js'
import { beautifulMessage } from '../../src/lib/text-formater.js'

export const config_ = {
  name: 'stalkff',
  alias: ['ffstalk', 'freefire'],
  category: 'stalk',
  description: 'Cek profil pemain Free Fire (ID)',
  usage: '.stalkff <userID>',
  example: '.stalkff 10074747571',
  isOwner: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

function formatNumber(num) {
  if (!num) return '0'
  num = parseInt(num)
  if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B'
  if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M'
  if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K'
  return num.toString()
}

export async function handler(m, { sock }) {
  const uid = m.text?.trim()
  if (!uid) return m.reply('❌ Masukkan ID Free Fire. Contoh: .stalkff 10074747571')

  await m.react('⏳')

  try {
    const res = await axios.get(`https://api.nexray.eu.cc/stalker/freefire?uid=${encodeURIComponent(uid)}`, {
      timeout: 15000,
    })

    const data = res.data
    if (!data.status || !data.result) {
      throw new Error(data.message || 'Data tidak ditemukan')
    }

    const r = data.result
    const guild = r.guild_name || null

    const text = `## 🔥 Profil Free Fire\n` +
      `**UID:** ${uid}\n` +
      `**Nama:** ${r.name || 'Unknown'}\n` +
      `**Level:** ${r.level || 0}\n` +
      `**XP:** ${formatNumber(r.exp) || 0}\n` +
      `**Region:** ${r.region || '-'}\n` +
      `**Likes:** ${formatNumber(r.likes) || 0}\n` +
      `**Title:** ${r.title || '-'}\n` +
      `**BR Max Rank:** ${r.br_max_rank || '-'}\n` +
      `**CS Max Rank:** ${r.cs_max_rank || '-'}\n` +
      (guild ? `**Guild:** ${guild}\n` : '') +
      (r.pet_name ? `**Pet:** ${r.pet_name} (Lv.${r.pet_level || 0})\n` : '') +
      `**Bergabung:** ${r.created_at ? new Date(r.created_at).toLocaleDateString('id-ID') : '-'}\n` +
      `**Login Terakhir:** ${r.last_login ? new Date(r.last_login).toLocaleDateString('id-ID') : '-'}\n` +
      `**Signature:** ${r.signature || '-'}`

    const builder = new AIRich(sock).setTitle('🎯 Free Fire Stalker')
    builder.addText(text)
    builder.addSuggest(['stalkff', 'stalkml', 'stalkroblox'])
    await builder.send(m.chat, { quoted: m.raw })
    await m.react('✅')
  } catch (err) {
    console.error('[STALKFF]', err)
    await m.react('❌')
    await m.reply(beautifulMessage(`❌ Gagal: ${err.message}`, { pushName: m.pushName }))
  }
}