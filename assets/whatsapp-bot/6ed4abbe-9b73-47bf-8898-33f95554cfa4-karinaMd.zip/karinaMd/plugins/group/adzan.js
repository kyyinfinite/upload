// plugins/group/adzan.js
import { getDatabase } from '../../src/database.js'

export const config_ = {
  name: 'adzan',
  alias: ['setadzan', 'autoadzan'],
  category: 'group',
  description: 'Atur auto adzan di grup (admin only)',
  usage: '.setadzan <kota>\n.adzan on/off/status',
  example: '.setadzan garut\n.adzan on',
  isOwner: false,
  isPremium: false,
  isGroup: true,
  isPrivate: false,
  prefix: false,
  cooldown: 5,
  isEnabled: true,
}
export { config_ as config }

export async function handler(m, { sock }) {
  const db = getDatabase()
  const group = db.getGroup(m.chat) || {}
  const cmd = m.command?.toLowerCase() || ''
  const args = m.args || []

  if (cmd === 'setadzan') {
    const city = args[0]
    if (!city) {
      return m.reply('❌ Masukkan nama kota. Contoh: .setadzan garut')
    }
    const updated = db.setGroup(m.chat, { ...group, adzanCity: city })
    if (updated) {
      return m.reply(`✅ Kota adzan diatur ke *${city}*`)
    } else {
      return m.reply('❌ Gagal menyimpan pengaturan.')
    }
  }

  if (cmd === 'adzan') {
    const sub = args[0]?.toLowerCase() || ''
    if (sub === 'on') {
      const updated = db.setGroup(m.chat, { ...group, autoAdzan: true })
      if (updated) {
        return m.reply('✅ Auto adzan *AKTIF* di grup ini.')
      } else {
        return m.reply('❌ Gagal mengaktifkan auto adzan.')
      }
    } else if (sub === 'off') {
      const updated = db.setGroup(m.chat, { ...group, autoAdzan: false })
      if (updated) {
        return m.reply('❌ Auto adzan *NONAKTIF* di grup ini.')
      } else {
        return m.reply('❌ Gagal menonaktifkan auto adzan.')
      }
    } else if (sub === 'status') {
      const status = group.autoAdzan ? 'AKTIF ✅' : 'NONAKTIF ❌'
      const city = group.adzanCity || 'jakarta'
      return m.reply(
        `🕌 *Status Auto Adzan*\n\n` +
        `Status: ${status}\n` +
        `Kota: ${city}\n\n` +
        `Gunakan:\n` +
        `• .setadzan <kota>\n` +
        `• .adzan on/off`
      )
    } else {
      return m.reply(
        `🕌 *Auto Adzan*\n\n` +
        `• .setadzan <kota> — atur kota\n` +
        `• .adzan on — aktifkan\n` +
        `• .adzan off — nonaktifkan\n` +
        `• .adzan status — lihat status`
      )
    }
  }
}