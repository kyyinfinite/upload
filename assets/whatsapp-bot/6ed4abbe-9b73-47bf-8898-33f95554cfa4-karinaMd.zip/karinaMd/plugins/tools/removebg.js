// plugins/tools/removebg.js
import { downloadContentFromMessage } from '@kyyinfinite/baileys';
import { beautifulMessage } from '../../src/lib/text-formater.js';
import axios from 'axios';
import FormData from 'form-data';
import { Toolkit } from '../../src/lib/_build-m.js';

export const config_ = {
  name: 'removebg',
  alias: ['nobg', 'hapusbg', 'rmbg'],
  category: 'tools',
  description: 'Hapus background gambar menjadi transparan (HD)',
  usage: '.removebg (reply gambar)',
  example: '.removebg',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
};
export { config_ as config };

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

async function uploadToCatbox(buffer) {
  const form = new FormData()
  form.append('reqtype', 'fileupload')
  form.append('fileToUpload', buffer, { filename: 'image.jpg' })
  const res = await axios.post('https://catbox.moe/user/api.php', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 30000,
  })
  const url = String(res.data).trim()
  if (!url.startsWith('https://files.catbox.moe/')) throw new Error('Catbox gagal')
  return url
}

async function uploadToTelegraph(buffer) {
  const form = new FormData()
  form.append('file', buffer, { filename: 'image.jpg' })
  const res = await axios.post('https://telegra.ph/upload', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 15000,
  })
  if (!Array.isArray(res.data) || !res.data[0]?.src) throw new Error('Telegra.ph gagal')
  return `https://telegra.ph${res.data[0].src}`
}

async function uploadToImgbb(buffer) {
  const form = new FormData()
  form.append('image', buffer.toString('base64'))
  form.append('key', 'e5b2e8f4b3c9d1a7f6e4d3c2b1a9f8e7')
  const res = await axios.post('https://api.imgbb.com/1/upload', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 30000,
  })
  if (res.data?.data?.url) return res.data.data.url
  throw new Error('Imgbb gagal')
}

async function uploadWithFallback(buffer, sock) {
  try {
    const url = await Toolkit.toUrl(sock, buffer, 'image')
    if (url && url.startsWith('http')) {
      console.log('[REMOVEBG] Upload ke CDN WA berhasil:', url)
      return url
    }
  } catch (err) {
    console.warn('[REMOVEBG] Toolkit.toUrl gagal:', err.message)
  }

  try {
    return await uploadToCatbox(buffer)
  } catch {}
  try {
    return await uploadToTelegraph(buffer)
  } catch {}
  try {
    return await uploadToImgbb(buffer)
  } catch {}
  throw new Error('Semua uploader gagal')
}

export async function handler(m, { sock }) {
  const target = m.quoted || m;
  const type = target.type || '';

  const isImage = type === 'imageMessage';

  if (!isImage) {
    return m.reply(beautifulMessage('❌ Reply atau kirim gambar dengan caption .removebg', { pushName: m.pushName }));
  }

  await m.react('⏳');

  try {
    const messageType = type.replace('Message', '');
    const stream = await downloadContentFromMessage(target.message[type], messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }

    if (!buffer || buffer.length === 0) {
      return m.reply(beautifulMessage('❌ Gagal mendownload gambar.', { pushName: m.pushName }));
    }

    const imageUrl = await uploadWithFallback(buffer, sock);

    const apiUrl = 'https://api.nexray.eu.cc/tools/removebg';
    const response = await axios.get(apiUrl, {
      params: { url: imageUrl },
      responseType: 'arraybuffer',
      timeout: 30000,
    });

    const resultBuffer = Buffer.from(response.data);
    if (!resultBuffer || resultBuffer.length === 0) {
      return m.reply(beautifulMessage('❌ Gagal menghapus background. Coba gambar lain.', { pushName: m.pushName }));
    }

    await sock.sendMessage(
      m.chat,
      {
        image: resultBuffer,
        caption: '✅ *Background berhasil dihapus!*\n\n🖼️ Kualitas HD',
        mimetype: 'image/png',
      },
      { quoted: m.raw }
    );

    await m.react('✅');
  } catch (err) {
    console.error('[REMOVEBG]', err);
    await m.react('❌');
    await m.reply(beautifulMessage(`❌ Gagal memproses gambar: ${err.message}`, { pushName: m.pushName }));
  }
}