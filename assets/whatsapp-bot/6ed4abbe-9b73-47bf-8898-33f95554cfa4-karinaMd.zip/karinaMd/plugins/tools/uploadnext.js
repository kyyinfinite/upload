// plugins/tools/uploadnext.js
import axios from 'axios'
import FormData from 'form-data'
import { downloadContentFromMessage } from '@kyyinfinite/baileys'
import { Button } from '../../src/lib/_build-m.js'

export const config_ = {
  name: 'uploadnext',
  alias: ['upnext', 'cdnnext'],
  category: 'tools',
  description: 'Upload media ke CDN Nextray (fallback Catbox)',
  usage: '.uploadnext (reply media)',
  example: '.uploadnext',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  isEnabled: true,
}
export { config_ as config }

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

async function uploadToNextray(buffer, filename) {
  const form = new FormData()
  form.append('file', buffer, { filename })
  form.append('ttl', '')

  const res = await axios.post('https://api.nexray.eu.cc/upload', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 30000,
  })

  if (res.data?.url) return res.data.url
  if (res.data?.data?.url) return res.data.data.url
  if (typeof res.data === 'string' && res.data.startsWith('http')) return res.data.trim()
  throw new Error('Nextray tidak mengembalikan URL')
}

async function uploadToCatbox(buffer, filename) {
  const form = new FormData()
  form.append('reqtype', 'fileupload')
  form.append('fileToUpload', buffer, { filename })
  const res = await axios.post('https://catbox.moe/user/api.php', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 30000,
  })
  const url = String(res.data).trim()
  if (url.startsWith('https://files.catbox.moe/')) return url
  throw new Error('Catbox gagal')
}

async function uploadWithFallback(buffer, filename) {
  try {
    return await uploadToNextray(buffer, filename)
  } catch (err) {
    console.warn('[UPLOADNEXT] Nextray error, fallback Catbox:', err.message)
    return await uploadToCatbox(buffer, filename)
  }
}

export async function handler(m, { sock }) {
  const target = m.quoted || m
  const type = target.type || ''

  const isMedia = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'].includes(type)
  if (!isMedia) {
    return m.reply('❌ Reply atau kirim media yang ingin diupload.')
  }

  await m.react('⏳')

  try {
    const stream = await downloadContentFromMessage(target.message[type], type)
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }
    if (!buffer.length) {
      await m.react('❌')
      return m.reply('❌ Gagal download media.')
    }

    let filename = target.fileName || `file_${Date.now()}`
    if (!filename.includes('.')) {
      const extMap = {
        imageMessage: 'jpg',
        videoMessage: 'mp4',
        audioMessage: 'mp3',
        documentMessage: 'bin',
        stickerMessage: 'webp'
      }
      const ext = extMap[type] || 'bin'
      filename += `.${ext}`
    }

    const url = await uploadWithFallback(buffer, filename)

    const msg = await new Button(sock)
      .setTitle('✅ Upload Berhasil')
      .setSubtitle('CDN')
      .setBody(`📁 *File:* ${filename}\n🔗 *URL:* ${url}`)
      .addCopy('📋 Copy URL', url)
      .addUrl('🌐 Buka URL', url, false)
      .addReply('📤 Upload Lagi', '.uploadnext')
      .build(m.chat)

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    await m.react('✅')
  } catch (err) {
    console.error('[UPLOADNEXT]', err)
    await m.react('❌')
    await m.reply(`❌ Gagal upload: ${err.message}`)
  }
}