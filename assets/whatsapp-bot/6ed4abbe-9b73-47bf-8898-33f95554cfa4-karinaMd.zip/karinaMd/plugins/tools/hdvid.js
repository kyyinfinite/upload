// plugins/tools/hdvideo.js
import { downloadContentFromMessage } from '@kyyinfinite/baileys'
import { beautifulMessage } from '../../src/lib/text-formater.js'
import { Toolkit } from '../../src/lib/_build-m.js'
import { AIRich } from '../../src/lib/_build-m.js'
import axios from 'axios'

export const config_ = {
  name: 'hdvideo',
  alias: ['enhancevideo', 'videohd', 'upscalevideo'],
  category: 'tools',
  description: 'Tingkatkan kualitas video menjadi HD/2K (via Nextray)',
  usage: '.hdvideo [resolusi] (reply video)',
  example: '.hdvideo hd\n.hdvideo 2k',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 60,
  isEnabled: true,
}
export { config_ as config }

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

async function uploadToCatbox(buffer, filename = 'video.mp4') {
  const FormData = (await import('form-data')).default
  const form = new FormData()
  form.append('reqtype', 'fileupload')
  form.append('fileToUpload', buffer, { filename })
  const res = await axios.post('https://catbox.moe/user/api.php', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 60000,
  })
  const url = String(res.data).trim()
  if (!url.startsWith('https://files.catbox.moe/')) throw new Error('Catbox gagal')
  return url
}

async function uploadToTelegraph(buffer) {
  const FormData = (await import('form-data')).default
  const form = new FormData()
  form.append('file', buffer, { filename: 'video.mp4' })
  const res = await axios.post('https://telegra.ph/upload', form, {
    headers: { ...form.getHeaders(), 'User-Agent': UA },
    timeout: 30000,
  })
  if (!Array.isArray(res.data) || !res.data[0]?.src) throw new Error('Telegra.ph gagal')
  return `https://telegra.ph${res.data[0].src}`
}

async function uploadWithFallback(buffer, sock, filename = 'video.mp4') {
  try {
    const url = await Toolkit.toUrl(sock, buffer, 'video')
    if (url && url.startsWith('http')) return url
  } catch (err) {
    console.warn('[HDVIDEO] Toolkit.toUrl gagal:', err.message)
  }
  try {
    return await uploadToCatbox(buffer, filename)
  } catch {}
  try {
    return await uploadToTelegraph(buffer)
  } catch {}
  throw new Error('Semua uploader gagal')
}

export async function handler(m, { sock }) {
  const target = m.quoted || m
  const type = target.type || ''
  const isVideo = type === 'videoMessage'

  if (!isVideo) {
    return m.reply(beautifulMessage('❌ Reply atau kirim video dengan caption .hdvideo', { pushName: m.pushName }))
  }

  const args = m.args || []
  const resolusi = args[0]?.toLowerCase() || 'hd'
  const validResolutions = ['hd', '2k', '4k']
  if (!validResolutions.includes(resolusi)) {
    return m.reply(`❌ Resolusi tidak valid. Gunakan: ${validResolutions.join(', ')}`)
  }

  await m.react('⏳')
  await m.reply(beautifulMessage('⏳ Video sedang diproses, tunggu beberapa menit...', { pushName: m.pushName }))

  try {
    const messageType = type.replace('Message', '')
    const stream = await downloadContentFromMessage(target.message[type], messageType)
    let buffer = Buffer.from([])
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk])
    }

    if (!buffer || buffer.length === 0) {
      return m.reply(beautifulMessage('❌ Gagal mendownload video.', { pushName: m.pushName }))
    }

    const videoUrl = await uploadWithFallback(buffer, sock, 'video.mp4')

    const apiUrl = 'https://api.nexray.eu.cc/tools/v1/hdvideo'
    const response = await axios.get(apiUrl, {
      params: { url: videoUrl, resolusi },
      timeout: 120000,
    })

    const result = response.data
    if (!result.status || !result.result?.url) {
      throw new Error(result.message || 'Gagal meningkatkan kualitas video')
    }

    const outputUrl = result.result.url
    const outputSize = result.result.size || 0

    const caption = `✅ *Video berhasil ditingkatkan!*\n\n` +
      `📐 Resolusi: ${resolusi.toUpperCase()}\n` +
      (outputSize ? `📦 Ukuran: ${(outputSize / 1024 / 1024).toFixed(2)} MB\n` : '') +
      `⏳ Proses selesai!`

    await new AIRich(sock)
      .setTitle('🎬 HD Video Upscale')
      .addText(caption)
      .addVideo(outputUrl)
      .addSuggest(['hdvideo hd', 'hdvideo 2k', 'hdvideo 4k'])
      .send(m.chat, { quoted: m.raw })

    await m.react('✅')
  } catch (err) {
    console.error('[HDVIDEO]', err)
    await m.react('❌')
    await m.reply(beautifulMessage(`❌ Gagal memproses video: ${err.message}`, { pushName: m.pushName }))
  }
}