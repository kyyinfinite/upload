/**
 * @file DungeonMap.js
 * @description Dungeon interior / minimap renderer. Procedurally generates
 *   a grid of rooms connected by corridors, with fog-of-war masking for
 *   unexplored areas.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT, TERRAIN } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect } from '../core/Helpers.js';
import { createRandom } from '../core/Random.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle, drawStatRow, drawBadge } from '../components/Labels.js';
import { drawVignette } from '../components/Effects.js';

/**
 * @typedef {Object} DungeonData
 * @property {string} [name]
 * @property {number} [floor=1]
 * @property {number} [cols=8]
 * @property {number} [rows=6]
 * @property {number} [seed]
 * @property {{x:number,y:number,explored?:boolean,type?:'start'|'boss'|'treasure'|'combat'|'rest'}[]} [rooms]
 * @property {[number,number]} [playerPos]  [col,row]
 * @property {{label:string,value:string}[]} [stats]
 */

export class DungeonMapRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.DUNGEON });
  }

  async initialize() {
    this.cols = this.data.cols ?? 8;
    this.rows = this.data.rows ?? 6;
    this.rng = createRandom(this.data.seed ?? 'dungeon');
  }

  async drawBackground() {
    const { ctx } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawPaper(ctx, w, h, { seed: 'dungeon' });

    // Stone floor gradient.
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, shade(TERRAIN.mountain.dark, -0.2));
    grad.addColorStop(1, shade(PAPER.ink, -0.2));
    ctx.fillStyle = grad;
    ctx.fillRect(SAFE_PADDING, SAFE_PADDING + HEADER_HEIGHT + 30, w - SAFE_PADDING * 2, h - (SAFE_PADDING + HEADER_HEIGHT + 30) * 2 + SAFE_PADDING);
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, {
      title: data.name ?? 'Dungeon',
      subtitle: `Floor ${data.floor ?? 1}`,
    });

    // Layout: grid on the left, stats panel on the right.
    const gridArea = { x: pad, y: top + 20, w: w * 0.6, h: h - top - 100 };
    const statsArea = { x: pad + gridArea.w + 30, y: top + 20, w: w - pad - (pad + gridArea.w + 30), h: gridArea.h };

    this.drawGrid(gridArea);
    this.drawStatsPanel(statsArea);
  }

  drawGrid(area) {
    const { ctx, data } = this;
    const cellW = area.w / this.cols;
    const cellH = area.h / this.rows;

    // Backing.
    ctx.fillStyle = withAlpha('#000000', 0.6);
    roundRect(ctx, area.x - 8, area.y - 8, area.w + 16, area.h + 16, 10);
    ctx.fill();

    const rooms = data.rooms ?? generateRooms(this.rng, this.cols, this.rows);
    const [pcx, pcy] = data.playerPos ?? [0, 0];

    // Draw corridors first.
    ctx.strokeStyle = withAlpha(TERRAIN.road.dark, 0.6);
    ctx.lineWidth = Math.min(cellW, cellH) * 0.18;
    ctx.lineCap = 'round';
    for (let i = 0; i < rooms.length; i++) {
      const a = rooms[i];
      if (!a.explored) continue;
      for (let j = i + 1; j < rooms.length; j++) {
        const b = rooms[j];
        if (!b.explored) continue;
        if (Math.abs(a.x - b.x) + Math.abs(a.y - b.y) === 1) {
          ctx.beginPath();
          ctx.moveTo(area.x + (a.x + 0.5) * cellW, area.y + (a.y + 0.5) * cellH);
          ctx.lineTo(area.x + (b.x + 0.5) * cellW, area.y + (b.y + 0.5) * cellH);
          ctx.stroke();
        }
      }
    }

    // Draw rooms.
    for (const r of rooms) {
      const rx = area.x + r.x * cellW + cellW * 0.15;
      const ry = area.y + r.y * cellH + cellH * 0.15;
      const rw = cellW * 0.7;
      const rh = cellH * 0.7;

      if (!r.explored) {
        // Fog-of-war: dark blob with question mark.
        ctx.fillStyle = '#000000';
        roundRect(ctx, rx, ry, rw, rh, 6);
        ctx.fill();
        ctx.fillStyle = withAlpha('#888888', 0.5);
        ctx.font = `${Math.round(Math.min(rw, rh) * 0.6)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('?', rx + rw / 2, ry + rh / 2);
        continue;
      }

      // Room floor.
      const colors = {
        start:    UI.emerald,
        boss:     UI.blood,
        treasure: UI.gold,
        combat:   shade(UI.iron, -0.1),
        rest:     UI.sapphire,
      };
      const c = colors[r.type] ?? TERRAIN.road.base;
      ctx.fillStyle = c;
      roundRect(ctx, rx, ry, rw, rh, 6);
      ctx.fill();
      ctx.strokeStyle = withAlpha('#000000', 0.5);
      ctx.lineWidth = 2;
      roundRect(ctx, rx, ry, rw, rh, 6);
      ctx.stroke();

      // Glyph.
      const glyphs = { start: '⚔', boss: '☠', treasure: '✦', combat: '⚔', rest: '♥' };
      if (glyphs[r.type]) {
        ctx.fillStyle = TEXT.light;
        ctx.font = `${Math.round(Math.min(rw, rh) * 0.5)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(glyphs[r.type], rx + rw / 2, ry + rh / 2);
      }
    }

    // Player marker.
    const pmx = area.x + (pcx + 0.5) * cellW;
    const pmy = area.y + (pcy + 0.5) * cellH;
    ctx.fillStyle = UI.goldLight;
    ctx.beginPath();
    ctx.arc(pmx, pmy, Math.min(cellW, cellH) * 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  drawStatsPanel(area) {
    const { ctx, data } = this;
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.3);
    roundRect(ctx, area.x, area.y, area.w, area.h, 10);
    ctx.fill();

    drawSectionTitle(ctx, area.x + 16, area.y + 16, area.w - 32, 'Dungeon Stats');
    let y = area.y + 70;
    const stats = data.stats ?? [
      { label: 'Floor', value: String(data.floor ?? 1) },
      { label: 'Rooms', value: String((data.rooms ?? []).length) },
      { label: 'Explored', value: `${(data.rooms ?? []).filter((r) => r.explored).length}` },
    ];
    for (const s of stats) {
      drawStatRow(ctx, area.x + 16, y, area.w - 32, 36, s.label, s.value, { accent: UI.gold });
      y += 44;
    }

    // Legend.
    y += 16;
    drawSectionTitle(ctx, area.x + 16, y, area.w - 32, 'Legend');
    y += 50;
    const legend = [
      ['start',    'Entrance'],
      ['combat',   'Combat'],
      ['treasure', 'Treasure'],
      ['rest',     'Rest'],
      ['boss',     'Boss'],
    ];
    for (const [type, label] of legend) {
      const colors = { start: UI.emerald, combat: UI.iron, treasure: UI.gold, rest: UI.sapphire, boss: UI.blood };
      ctx.fillStyle = colors[type];
      roundRect(ctx, area.x + 16, y, 18, 18, 4);
      ctx.fill();
      ctx.fillStyle = TEXT.primary;
      ctx.font = fontCss('bodySmall');
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, area.x + 42, y + 9);
      y += 26;
    }
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.6 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: data.name ?? 'Dungeon',
      right: `Floor ${data.floor ?? 1}`,
      center: '🗝 Dungeon',
    });
  }
}

/** Procedurally generate a sparse dungeon room layout. */
function generateRooms(rng, cols, rows) {
  const rooms = [];
  const total = Math.floor(cols * rows * 0.5);
  const used = new Set();
  let x = 0, y = Math.floor(rows / 2);
  for (let i = 0; i < total; i++) {
    rooms.push({ x, y, explored: rng.next() > 0.4, type: i === 0 ? 'start' : rng.pick(['combat', 'rest', 'treasure', 'combat']) });
    used.add(`${x},${y}`);
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([dx, dy]) => {
      const nx = x + dx, ny = y + dy;
      return nx >= 0 && nx < cols && ny >= 0 && ny < rows && !used.has(`${nx},${ny}`);
    });
    if (!dirs.length) break;
    const [dx, dy] = rng.pick(dirs);
    x += dx; y += dy;
  }
  // Mark last explored room as boss.
  for (let i = rooms.length - 1; i >= 0; i--) {
    if (rooms[i].explored) {
      rooms[i].type = 'boss';
      break;
    }
  }
  return rooms;
}

/**
 * @param {DungeonData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new DungeonMapRenderer().render(data);
}

export default { render, DungeonMapRenderer };
