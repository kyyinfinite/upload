/**
 * @file AdventureMap.js
 * @description Adventure / world map renderer. Procedurally lays out terrain
 *   (ocean, grass, forest, mountain), roads, rivers, villages, castles,
 *   dungeons, and area nodes. Uses a seeded RNG so the same `seed` always
 *   yields the same map — perfect for persistent player worlds.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES } from '../constants/dimensions.js';
import { TERRAIN, PAPER } from '../constants/palette.js';
import { createRandom } from '../core/Random.js';
import { createNoise2D } from '../core/Noise.js';
import { withAlpha, shade } from '../core/Colors.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawCompass } from '../components/Compass.js';
import { drawClouds } from '../components/Clouds.js';
import { drawOcean } from '../components/Ocean.js';
import { drawForest } from '../components/Forest.js';
import { drawRiver } from '../components/River.js';
import { drawRoad } from '../components/Roads.js';
import { drawVillage } from '../components/Village.js';
import { drawCastle } from '../components/Castle.js';
import { drawDungeon } from '../components/Dungeon.js';
import { drawAreaNode } from '../components/AreaNode.js';
import { drawVignette } from '../components/Effects.js';

/**
 * @typedef {Object} AdventureMapData
 * @property {number|string} [seed]
 * @property {string} [title]      Map title.
 * @property {string} [subtitle]
 * @property {Array<{x:number,y:number,type:string,label?:string,level?:number,icon?:string,rarity?:string}>} [nodes]
 * @property {Array<{x1:number,y1:number,x2:number,y2:number}>} [roads]
 * @property {Array<{x1:number,y1:number,x2:number,y2:number}>} [rivers]
 * @property {Array<{x:number,y:number,w:number,kind:'forest'|'village'|'castle'|'dungeon'}>} [features]
 * @property {boolean} [clouds=true]
 * @property {boolean} [compass=true]
 * @property {string} [footerText]
 */

export class AdventureMapRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.MAP });
    /** @type {ReturnType<typeof createRandom>} */
    this.rng = null;
    /** @type {ReturnType<typeof createNoise2D>} */
    this.noise = null;
  }

  async initialize() {
    const seed = this.data.seed ?? 'adventure';
    this.rng = createRandom(seed);
    this.noise = createNoise2D(`${seed}:noise`, 48);
  }

  async drawBackground() {
    const { ctx, data, rng } = this;
    const { width: w, height: h } = this.size;

    // Base parchment.
    drawPaper(ctx, w, h, { seed: data.seed ?? 'paper', vignette: 0.3 });

    // Procedural terrain overlay using fBm noise.
    const cell = 24;
    const cols = Math.ceil(w / cell);
    const rows = Math.ceil(h / cell);
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const n = this.noise.fractal(x, y, 4, 0.5, 0.05);
        let color = null;
        if (n < 0.32) color = TERRAIN.ocean.base;
        else if (n < 0.38) color = TERRAIN.ocean.light;
        else if (n < 0.55) color = TERRAIN.grass.base;
        else if (n < 0.68) color = TERRAIN.forest.base;
        else color = TERRAIN.mountain.base;

        ctx.fillStyle = withAlpha(color, 0.55);
        ctx.fillRect(x * cell, y * cell, cell + 1, cell + 1);
      }
    }

    void rng;
  }

  async drawObjects() {
    const { ctx, data } = this;
    const { width: w, height: h } = this.size;

    // Coast outline (subtle).
    ctx.strokeStyle = withAlpha(TERRAIN.ocean.dark, 0.3);
    ctx.lineWidth = 2;

    // Rivers.
    const rivers = data.rivers ?? defaultRivers(this.rng, w, h);
    for (const r of rivers) {
      drawRiver(ctx, r.x1, r.y1, r.x2, r.y2, { width: 18, seed: `${r.x1}:${r.y1}` });
    }

    // Roads.
    const roads = data.roads ?? defaultRoads(this.rng, w, h);
    for (const r of roads) {
      drawRoad(ctx, r.x1, r.y1, r.x2, r.y2, { width: 10, seed: `${r.x1}:${r.y1}` });
    }

    // Terrain features.
    const features = data.features ?? defaultFeatures(this.rng, w, h);
    for (const f of features) {
      if (f.kind === 'forest') drawForest(ctx, f.x, f.y, f.w, { seed: `${f.x}:${f.y}` });
      else if (f.kind === 'village') drawVillage(ctx, f.x, f.y, f.w, { seed: `${f.x}:${f.y}` });
      else if (f.kind === 'castle') drawCastle(ctx, f.x, f.y, f.w, { seed: `${f.x}:${f.y}` });
      else if (f.kind === 'dungeon') drawDungeon(ctx, f.x, f.y, f.w, { seed: `${f.x}:${f.y}` });
    }
  }

  async drawDecorations() {
    const { ctx, data } = this;
    if (data.clouds !== false) {
      drawClouds(ctx, this.size.width, this.size.height, { count: 6, seed: `${data.seed ?? 'a'}:clouds` });
    }
  }

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.5 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const { width: w, height: h } = this.size;

    drawBorder(ctx, w, h);

    drawHeader(ctx, w, {
      title: data.title ?? 'Adventure Map',
      subtitle: data.subtitle ?? `Seed: ${data.seed ?? 'random'}`,
    });

    if (data.compass !== false) {
      drawCompass(ctx, w - 110, h - 130, 70, { seed: `${data.seed}:compass` });
    }

    // Area nodes (player-relevant pins).
    const nodes = data.nodes ?? [];
    for (const n of nodes) {
      drawAreaNode(ctx, n.x, n.y, {
        type: n.type,
        label: n.label,
        level: n.level,
        icon: n.icon,
        rarity: n.rarity,
        seed: `${n.x}:${n.y}`,
      });
    }

    drawFooter(ctx, w, h, {
      left: data.footerText ?? 'World Map',
      right: new Date().toLocaleDateString(),
      center: '⚔ RPG ⚔',
    });
  }
}

/** Default river layout if the caller doesn't provide one. */
function defaultRivers(rng, w, h) {
  const out = [];
  const n = 2;
  for (let i = 0; i < n; i++) {
    out.push({
      x1: rng.range(0, w * 0.3),
      y1: rng.range(h * 0.2, h * 0.5),
      x2: rng.range(w * 0.6, w),
      y2: rng.range(h * 0.5, h * 0.85),
    });
  }
  return out;
}

/** Default road layout. */
function defaultRoads(rng, w, h) {
  const out = [];
  const n = 3;
  for (let i = 0; i < n; i++) {
    out.push({
      x1: rng.range(w * 0.1, w * 0.4),
      y1: rng.range(h * 0.3, h * 0.7),
      x2: rng.range(w * 0.5, w * 0.9),
      y2: rng.range(h * 0.3, h * 0.7),
    });
  }
  return out;
}

/** Default features layout. */
function defaultFeatures(rng, w, h) {
  const out = [];
  const count = 8;
  const kinds = ['forest', 'forest', 'village', 'castle', 'dungeon', 'forest'];
  for (let i = 0; i < count; i++) {
    out.push({
      x: rng.range(w * 0.1, w * 0.9),
      y: rng.range(h * 0.2, h * 0.85),
      w: rng.range(80, 160),
      kind: rng.pick(kinds),
    });
  }
  return out;
}

/**
 * Public renderer entrypoint.
 * @param {AdventureMapData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new AdventureMapRenderer().render(data);
}

export default { render, AdventureMapRenderer };
