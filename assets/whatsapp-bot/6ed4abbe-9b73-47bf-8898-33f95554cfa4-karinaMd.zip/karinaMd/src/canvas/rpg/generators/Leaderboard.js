/**
 * @file Leaderboard.js
 * @description Leaderboard renderer. Ranked list of players with rank,
 *   name, level, score, and optional crown for top-3.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle } from '../components/Labels.js';
import { drawVignette, drawSparkles } from '../components/Effects.js';

/**
 * @typedef {Object} LeaderboardEntry
 * @property {string} name
 * @property {number} score
 * @property {number} [level]
 * @property {string} [class]
 *
 * @typedef {Object} LeaderboardData
 * @property {string} [title]
 * @property {string} [metric]   e.g. "Gold", "Power"
 * @property {LeaderboardEntry[]} entries
 * @property {string} [currentUser]   Highlights the matching row.
 */

const RANK_COLORS = Object.freeze({
  1: UI.gold,
  2: UI.silver,
  3: '#cd7f32', // bronze
});

export class LeaderboardRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.LEADERBOARD });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'leaderboard' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, {
      title: data.title ?? 'Leaderboard',
      subtitle: `Top by ${data.metric ?? 'Score'}`,
    });

    const entries = data.entries ?? [];
    const rowH = 64;
    const listY = top + 20;
    const listW = w - pad * 2;

    // Column headers.
    ctx.fillStyle = withAlpha(PAPER.ink, 0.7);
    roundRect(ctx, pad, listY, listW, 32, 8);
    ctx.fill();
    ctx.fillStyle = TEXT.light;
    ctx.font = fontCss('badge');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText('#', pad + 16, listY + 16);
    ctx.fillText('NAME', pad + 90, listY + 16);
    ctx.textAlign = 'right';
    ctx.fillText('LVL', pad + listW - 220, listY + 16);
    ctx.fillText((data.metric ?? 'SCORE').toUpperCase(), pad + listW - 24, listY + 16);

    // Rows.
    for (let i = 0; i < entries.length; i++) {
      const y = listY + 40 + i * (rowH + 8);
      if (y > this.size.height - SAFE_PADDING - 80) break;
      this.drawRow(pad, y, listW, rowH, i + 1, entries[i], data.currentUser);
    }
  }

  drawRow(x, y, w, h, rank, entry, currentUser) {
    const { ctx } = this;
    const isYou = currentUser && entry.name === currentUser;
    const rankColor = RANK_COLORS[rank] ?? PAPER.edge;

    // Backing.
    ctx.fillStyle = isYou ? withAlpha(UI.gold, 0.3) : withAlpha(PAPER.shadow, 0.25);
    roundRect(ctx, x, y, w, h, 10);
    ctx.fill();

    // Left rank stripe.
    ctx.fillStyle = rankColor;
    roundRect(ctx, x, y, 6, h, 3);
    ctx.fill();

    // Rank number / medal.
    ctx.fillStyle = rankColor;
    ctx.font = `700 ${rank <= 3 ? 36 : 28}px Cinzel, serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    if (rank === 1) ctx.fillText('👑', x + 50, y + h / 2);
    else if (rank <= 3) ctx.fillText(['🥇','🥈','🥉'][rank - 1], x + 50, y + h / 2);
    else ctx.fillText(String(rank), x + 50, y + h / 2);

    // Name + class.
    ctx.fillStyle = TEXT.primary;
    ctx.font = fontCss('body');
    ctx.textAlign = 'left';
    ctx.fillText(entry.name + (isYou ? '  (You)' : ''), x + 100, y + h / 2 - 8);
    ctx.fillStyle = TEXT.muted;
    ctx.font = fontCss('bodySmall');
    ctx.fillText(`${entry.class ?? ''} • Lvl ${entry.level ?? '?'}`, x + 100, y + h / 2 + 12);

    // Level.
    ctx.fillStyle = UI.royal;
    ctx.font = fontCss('stat');
    ctx.textAlign = 'right';
    ctx.fillText(String(entry.level ?? '?'), x + w - 220, y + h / 2);

    // Score.
    ctx.fillStyle = UI.gold;
    ctx.font = fontCss('statLarge');
    ctx.fillText(formatNumber(entry.score), x + w - 24, y + h / 2);
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
    drawSparkles(ctx, SAFE_PADDING, SAFE_PADDING + HEADER_HEIGHT, this.size.width - SAFE_PADDING * 2, 100, {
      count: 12, color: UI.goldLight, seed: 'leaderboard-sparkles',
    });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: data.title ?? 'Leaderboard',
      right: `${(data.entries ?? []).length} entries`,
      center: '🏆 Leaderboard',
    });
  }
}

/**
 * @param {LeaderboardData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new LeaderboardRenderer().render(data);
}

export default { render, LeaderboardRenderer };
