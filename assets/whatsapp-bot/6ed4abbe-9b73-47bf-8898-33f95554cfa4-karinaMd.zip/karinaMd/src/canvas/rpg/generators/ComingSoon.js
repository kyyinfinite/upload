/**
 * @file ComingSoon.js
 * @description Placeholder renderer used for generators that haven't been
 *   implemented yet. Renders a themed "Coming Soon" card so the public API
 *   always returns a real PNG even for stubs.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect } from '../core/Helpers.js';
import { createRandom } from '../core/Random.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawVignette, drawSparkles, drawGlow } from '../components/Effects.js';

/**
 * @typedef {Object} ComingSoonData
 * @property {string} [feature]    Name of the upcoming feature.
 * @property {string} [description]
 * @property {string} [icon]
 * @property {string} [eta]
 */

export class ComingSoonRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.DEFAULT });
  }

  async initialize() {
    this.rng = createRandom(this.data.feature ?? 'soon');
  }

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'soon' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;

    drawHeader(ctx, w, {
      title: data.feature ?? 'Coming Soon',
      subtitle: 'Under Construction',
    });

    // Central card.
    const cardW = 600;
    const cardH = 360;
    const cx = (w - cardW) / 2;
    const cy = (h - cardH) / 2;

    // Glow.
    drawGlow(ctx, w / 2, h / 2, 400, UI.goldLight, 0.4);

    // Card.
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.5);
    roundRect(ctx, cx, cy, cardW, cardH, 18);
    ctx.fill();
    ctx.strokeStyle = UI.gold;
    ctx.lineWidth = 4;
    roundRect(ctx, cx, cy, cardW, cardH, 18);
    ctx.stroke();

    // Big icon.
    if (data.icon) {
      ctx.font = '120px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(data.icon, w / 2, cy + 110);
    }

    // Title.
    ctx.fillStyle = TEXT.primary;
    ctx.font = fontCss('section');
    ctx.fillText(data.feature ?? 'Coming Soon', w / 2, cy + 200);

    // Description.
    if (data.description) {
      ctx.fillStyle = TEXT.secondary;
      ctx.font = fontCss('body');
      const lines = wrap(ctx, data.description, cardW - 60);
      for (let i = 0; i < Math.min(3, lines.length); i++) {
        ctx.fillText(lines[i], w / 2, cy + 240 + i * 26);
      }
    }

    // ETA badge.
    if (data.eta) {
      ctx.fillStyle = UI.goldDark;
      roundRect(ctx, w / 2 - 80, cy + cardH - 50, 160, 32, 16);
      ctx.fill();
      ctx.fillStyle = TEXT.light;
      ctx.font = fontCss('badge');
      ctx.fillText(`ETA: ${data.eta}`, w / 2, cy + cardH - 33);
    }
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.5 });
    drawSparkles(ctx, 0, 0, this.size.width, this.size.height, {
      count: 30, color: UI.goldLight, seed: 'soon-sparkles',
    });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: 'Preview',
      right: new Date().toLocaleDateString(),
      center: `🔨 ${data.feature ?? 'Coming Soon'}`,
    });
  }
}

function wrap(ctx, text, maxW) {
  const out = [];
  for (const paragraph of String(text).split('\n')) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxW && line) {
        out.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    out.push(line);
  }
  return out;
}

/**
 * @param {ComingSoonData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new ComingSoonRenderer().render(data);
}

export default { render, ComingSoonRenderer };
