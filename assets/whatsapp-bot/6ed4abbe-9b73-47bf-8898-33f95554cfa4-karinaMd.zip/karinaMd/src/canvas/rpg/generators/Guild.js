/**
 * @file Guild.js
 * @description Guild panel renderer. Header, banner, member list, guild
 *   stats, and treasury summary.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawBanner } from '../components/Decorations.js';
import { drawSectionTitle, drawStatRow, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette } from '../components/Effects.js';

/**
 * @typedef {Object} GuildMember
 * @property {string} name
 * @property {string} [role]     leader | officer | member
 * @property {number} [level]
 * @property {number} [contribution]
 * @property {string} [class]
 * @property {boolean} [online]
 *
 * @typedef {Object} GuildData
 * @property {string} name
 * @property {string} [tag]
 * @property {string} [motto]
 * @property {number} [level]
 * @property {number} [exp]
 * @property {number} [expNext]
 * @property {number} [members]
 * @property {number} [memberCap]
 * @property {number} [treasury]
 * @property {string} [bannerColor]
 * @property {string} [emblem]
 * @property {GuildMember[]} [roster]
 */

const ROLE_COLORS = Object.freeze({
  leader:  UI.gold,
  officer: UI.royal,
  member:  UI.emerald,
});

export class GuildRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.GUILD });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'guild' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, {
      title: data.name ?? 'Guild',
      subtitle: data.motto ?? `[${data.tag ?? '???'})]`,
    });

    // Banner.
    drawBanner(ctx, pad, top, 80, 200, { color: data.bannerColor ?? UI.blood, emblem: data.emblem ?? '⚔' });

    // Guild info column.
    const infoX = pad + 110;
    const infoW = w - pad - infoX;
    drawSectionTitle(ctx, infoX, top, infoW, 'Guild Info');
    let y = top + 50;
    drawStatRow(ctx, infoX, y, infoW, 36, 'Level',  String(data.level ?? 1), { accent: UI.gold }); y += 44;
    drawStatRow(ctx, infoX, y, infoW, 36, 'Members', `${data.members ?? 0} / ${data.memberCap ?? 50}`, { accent: UI.emerald }); y += 44;
    drawStatRow(ctx, infoX, y, infoW, 36, 'Treasury', `${formatNumber(data.treasury ?? 0)} G`, { accent: UI.gold }); y += 44;
    drawStatRow(ctx, infoX, y, infoW, 36, 'Tag', `[${data.tag ?? ''}]`, { accent: UI.royal }); y += 56;

    // XP bar.
    drawSectionTitle(ctx, infoX, y, infoW, 'Guild XP'); y += 50;
    const xpRatio = data.expNext ? Math.min(1, (data.exp ?? 0) / data.expNext) : 0;
    drawProgressBar(ctx, infoX, y, infoW, 24, xpRatio, {
      color: UI.gold,
      label: `${formatNumber(data.exp ?? 0)} / ${formatNumber(data.expNext ?? 0)}`,
    });
    y += 50;

    // Roster.
    drawSectionTitle(ctx, pad, y, w - pad * 2, 'Roster');
    y += 50;
    const roster = data.roster ?? [];
    const cols = 2;
    const colW = (w - pad * 2 - 20) / cols;
    for (let i = 0; i < roster.length; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const mx = pad + col * (colW + 20);
      const my = y + row * 56;
      if (my > this.size.height - SAFE_PADDING - 100) break;
      this.drawMemberRow(mx, my, colW, roster[i]);
    }
  }

  drawMemberRow(x, y, w, m) {
    const { ctx } = this;
    const role = m.role ?? 'member';
    const color = ROLE_COLORS[role] ?? UI.emerald;

    // Backing.
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.25);
    roundRect(ctx, x, y, w, 48, 8);
    ctx.fill();

    // Online dot.
    ctx.fillStyle = m.online ? UI.emerald : '#666';
    ctx.beginPath();
    ctx.arc(x + 14, y + 24, 5, 0, Math.PI * 2);
    ctx.fill();

    // Name + class.
    ctx.fillStyle = TEXT.primary;
    ctx.font = fontCss('body');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(m.name, x + 30, y + 18);
    ctx.fillStyle = TEXT.muted;
    ctx.font = fontCss('bodySmall');
    ctx.fillText(`${m.class ?? ''} • Lvl ${m.level ?? '?'}`, x + 30, y + 34);

    // Role badge.
    drawBadge(ctx, x + w - 110, y + 14, role.toUpperCase(), { color });

    // Contribution.
    ctx.fillStyle = UI.gold;
    ctx.font = fontCss('stat');
    ctx.textAlign = 'right';
    ctx.fillText(`${formatNumber(m.contribution ?? 0)}`, x + w - 14, y + 24);
    ctx.fillStyle = TEXT.muted;
    ctx.font = fontCss('bodyTiny');
    ctx.fillText('contrib', x + w - 14, y + 38);
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: `[${data.tag ?? ''}] ${data.name ?? 'Guild'}`,
      right: `${data.members ?? 0} members`,
      center: '🏰 Guild',
    });
  }
}

/**
 * @param {GuildData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new GuildRenderer().render(data);
}

export default { render, GuildRenderer };
