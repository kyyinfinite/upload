/**
 * @file Profile.js
 * @description Player profile renderer. Big portrait area, stats block,
 *   equipment summary, XP bar, and achievement chips.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber, formatDuration } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawPlayer } from '../components/Player.js';
import { drawSectionTitle, drawStatRow, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette, drawSparkles } from '../components/Effects.js';

/**
 * @typedef {Object} ProfileData
 * @property {string} player
 * @property {string} [class]   warrior | mage | rogue | ranger | cleric
 * @property {number} [level=1]
 * @property {number} [xp]
 * @property {number} [xpNext]
 * @property {number} [hp]
 * @property {number} [maxHp]
 * @property {number} [mp]
 * @property {number} [maxMp]
 * @property {number} [gold]
 * @property {number} [gems]
 * @property {string} [guild]
 * @property {string} [title]
 * @property {{name:string,value:string}[]} [stats]
 * @property {{name:string,icon?:string}[]} [achievements]
 * @property {number} [playtimeMs]
 */

export class ProfileRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.PROFILE });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'profile' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;

    drawHeader(ctx, w, { title: 'Character Profile', subtitle: data.player ?? 'Adventurer' });

    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    // Portrait panel.
    const portraitW = 360;
    const portraitH = 460;
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.3);
    roundRect(ctx, pad, top, portraitW, portraitH, 12);
    ctx.fill();
    ctx.strokeStyle = UI.gold;
    ctx.lineWidth = 3;
    roundRect(ctx, pad, top, portraitW, portraitH, 12);
    ctx.stroke();

    // Portrait background.
    const pg = ctx.createLinearGradient(0, top, 0, top + portraitH);
    pg.addColorStop(0, shade(UI.royal, -0.4));
    pg.addColorStop(1, shade(PAPER.ink, -0.2));
    ctx.fillStyle = pg;
    roundRect(ctx, pad + 6, top + 6, portraitW - 12, portraitH - 12, 8);
    ctx.fill();

    // Player token.
    drawPlayer(ctx, pad + portraitW / 2, top + portraitH / 2 + 30, 120, {
      cls: data.class ?? 'warrior',
      name: data.player,
      shadow: true,
      seed: data.player ?? 'p',
    });

    // Class + level badges.
    drawBadge(ctx, pad + 16, top + 16, `LVL ${data.level ?? 1}`, { color: UI.gold });
    drawBadge(ctx, pad + portraitW - 110, top + 16, (data.class ?? 'warrior').toUpperCase(), { color: UI.blood });

    // Right column: identity + stats.
    const rx = pad + portraitW + 30;
    const rw = w - pad - rx;

    // Identity.
    drawSectionTitle(ctx, rx, top, rw, 'Identity');
    let y = top + 56;
    drawStatRow(ctx, rx, y, rw, 38, 'Name',     data.player ?? '—', { accent: UI.gold }); y += 46;
    drawStatRow(ctx, rx, y, rw, 38, 'Title',    data.title ?? 'Novice', { accent: UI.gold }); y += 46;
    drawStatRow(ctx, rx, y, rw, 38, 'Guild',    data.guild ?? 'None', { accent: UI.royal }); y += 46;
    drawStatRow(ctx, rx, y, rw, 38, 'Playtime', formatDuration(data.playtimeMs ?? 0), { accent: UI.emerald }); y += 46;

    // Resources.
    drawSectionTitle(ctx, rx, y, rw, 'Resources'); y += 56;
    drawStatRow(ctx, rx, y, rw, 38, 'Gold', formatNumber(data.gold ?? 0), { accent: UI.gold }); y += 46;
    drawStatRow(ctx, rx, y, rw, 38, 'Gems', formatNumber(data.gems ?? 0), { accent: UI.sapphire }); y += 46;

    // XP bar.
    y += 12;
    drawSectionTitle(ctx, rx, y, rw, 'Experience'); y += 50;
    const xpRatio = data.xpNext ? Math.min(1, (data.xp ?? 0) / data.xpNext) : 0;
    drawProgressBar(ctx, rx, y, rw, 28, xpRatio, {
      color: UI.gold,
      label: `${formatNumber(data.xp ?? 0)} / ${formatNumber(data.xpNext ?? 0)} XP`,
    });
    y += 50;

    // HP / MP bars.
    const hpRatio = data.maxHp ? Math.min(1, (data.hp ?? 0) / data.maxHp) : 1;
    drawProgressBar(ctx, rx, y, rw, 24, hpRatio, {
      color: UI.blood,
      label: `HP ${(data.hp ?? 0)} / ${(data.maxHp ?? 0)}`,
    });
    y += 36;
    const mpRatio = data.maxMp ? Math.min(1, (data.mp ?? 0) / data.maxMp) : 1;
    drawProgressBar(ctx, rx, y, rw, 24, mpRatio, {
      color: UI.sapphire,
      label: `MP ${(data.mp ?? 0)} / ${(data.maxMp ?? 0)}`,
    });
    y += 50;

    // Achievements row.
    drawSectionTitle(ctx, rx, y, rw, 'Achievements'); y += 50;
    const ach = data.achievements ?? [];
    const chipW = (rw - 5 * 8) / 6;
    for (let i = 0; i < Math.min(ach.length, 6); i++) {
      const ax = rx + i * (chipW + 8);
      ctx.fillStyle = withAlpha(UI.gold, 0.25);
      roundRect(ctx, ax, y, chipW, chipW, 8);
      ctx.fill();
      ctx.strokeStyle = UI.gold;
      ctx.lineWidth = 2;
      roundRect(ctx, ax, y, chipW, chipW, 8);
      ctx.stroke();
      if (ach[i].icon) {
        ctx.font = `${Math.round(chipW * 0.55)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(ach[i].icon, ax + chipW / 2, y + chipW / 2);
      }
    }

    void h;
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
    drawSparkles(ctx, SAFE_PADDING + 20, SAFE_PADDING + HEADER_HEIGHT + 30, 360, 460, {
      count: 12, color: UI.goldLight, seed: 'profile-sparkles',
    });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: `${data.player ?? 'Adventurer'} • Lvl ${data.level ?? 1}`,
      right: new Date().toLocaleDateString(),
      center: '🛡 Profile',
    });
  }
}

/**
 * @param {ProfileData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new ProfileRenderer().render(data);
}

export default { render, ProfileRenderer };
