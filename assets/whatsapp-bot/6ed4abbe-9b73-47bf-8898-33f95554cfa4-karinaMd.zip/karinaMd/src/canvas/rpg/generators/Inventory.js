/**
 * @file Inventory.js
 * @description Player inventory renderer. Draws an N×M grid of item slots
 *   with rarity frames, item icons (emoji / glyph), count badges, and a
 *   right-side detail panel for the currently selected item.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, RARITY, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';
import { createRandom } from '../core/Random.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle, drawStatRow, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette } from '../components/Effects.js';

/**
 * @typedef {Object} InventoryItem
 * @property {string}   id
 * @property {string}   name
 * @property {string}   [icon]      Emoji or short glyph.
 * @property {number}   [count=1]
 * @property {string}   [rarity='common']
 * @property {string}   [type]
 * @property {string}   [description]
 * @property {{name:string,value:number}[]} [stats]
 */

/**
 * @typedef {Object} InventoryData
 * @property {string} player
 * @property {number} [gold]
 * @property {number} [gems]
 * @property {number} [capacity]
 * @property {InventoryItem[]} items
 * @property {number} [selected]
 * @property {number} [cols=6]
 * @property {number} [rows=6]
 */

export class InventoryRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.INVENTORY });
  }

  async initialize() {
    this.cols = this.data.cols ?? 6;
    this.rows = this.data.rows ?? 6;
    this.slotSize = 110;
    this.gap = 10;
    this.selected = this.data.selected ?? 0;
  }

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'inventory' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;

    drawHeader(ctx, w, { title: `${data.player ?? 'Adventurer'}'s Inventory`, subtitle: 'Backpack' });

    // Left: grid.
    const gridX = SAFE_PADDING + 20;
    const gridY = SAFE_PADDING + HEADER_HEIGHT + 30;
    const gridW = this.cols * (this.slotSize + this.gap) - this.gap;
    const items = data.items ?? [];

    // Capacity backdrop.
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.25);
    roundRect(ctx, gridX - 16, gridY - 16, gridW + 32, this.rows * (this.slotSize + this.gap) - this.gap + 32, 12);
    ctx.fill();

    for (let i = 0; i < this.cols * this.rows; i++) {
      const col = i % this.cols;
      const row = Math.floor(i / this.cols);
      const x = gridX + col * (this.slotSize + this.gap);
      const y = gridY + row * (this.slotSize + this.gap);
      const item = items[i];
      const isSel = i === this.selected;
      this.drawSlot(x, y, this.slotSize, item, isSel);
    }

    // Right: details panel.
    const panelX = gridX + gridW + 40;
    const panelY = gridY;
    const panelW = w - SAFE_PADDING - 20 - panelX;
    const panelH = this.rows * (this.slotSize + this.gap) - this.gap;
    this.drawDetailPanel(panelX, panelY, panelW, panelH, items[this.selected]);
  }

  drawSlot(x, y, size, item, selected) {
    const { ctx } = this;
    const rarity = item?.rarity ? RARITY[item.rarity] : PAPER.edge;

    // Slot backing.
    ctx.fillStyle = withAlpha(PAPER.dark, 0.5);
    roundRect(ctx, x, y, size, size, 10);
    ctx.fill();

    // Rarity frame.
    if (item) {
      ctx.strokeStyle = rarity;
      ctx.lineWidth = 3;
      roundRect(ctx, x + 2, y + 2, size - 4, size - 4, 8);
      ctx.stroke();

      // Inner gradient.
      const grad = ctx.createLinearGradient(x, y, x, y + size);
      grad.addColorStop(0, withAlpha(rarity, 0.25));
      grad.addColorStop(1, withAlpha(rarity, 0.05));
      ctx.fillStyle = grad;
      roundRect(ctx, x + 4, y + 4, size - 8, size - 8, 6);
      ctx.fill();
    } else {
      ctx.strokeStyle = withAlpha(PAPER.edge, 0.5);
      ctx.lineWidth = 1;
      roundRect(ctx, x + 2, y + 2, size - 4, size - 4, 8);
      ctx.stroke();
    }

    // Selection highlight.
    if (selected) {
      ctx.strokeStyle = UI.goldLight;
      ctx.lineWidth = 4;
      roundRect(ctx, x - 2, y - 2, size + 4, size + 4, 12);
      ctx.stroke();
    }

    if (item) {
      // Icon.
      if (item.icon) {
        ctx.font = `${Math.round(size * 0.55)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = TEXT.primary;
        ctx.fillText(item.icon, x + size / 2, y + size / 2);
      }

      // Count badge.
      if (item.count && item.count > 1) {
        const cw = 28;
        ctx.fillStyle = UI.goldDark;
        roundRect(ctx, x + size - cw - 4, y + size - 28, cw, 22, 6);
        ctx.fill();
        ctx.fillStyle = TEXT.light;
        ctx.font = fontCss('badge');
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(formatNumber(item.count), x + size - cw / 2 - 4, y + size - 17);
      }
    }
  }

  drawDetailPanel(x, y, w, h, item) {
    const { ctx, data } = this;
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.3);
    roundRect(ctx, x, y, w, h, 12);
    ctx.fill();

    if (!item) {
      ctx.fillStyle = withAlpha(TEXT.muted, 0.7);
      ctx.font = fontCss('body');
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Select an item to inspect', x + w / 2, y + h / 2);
      return;
    }

    const rarity = RARITY[item.rarity] ?? RARITY.common;
    const pad = 16;

    // Icon block.
    ctx.fillStyle = withAlpha(rarity, 0.25);
    roundRect(ctx, x + pad, y + pad, 80, 80, 10);
    ctx.fill();
    ctx.strokeStyle = rarity;
    ctx.lineWidth = 3;
    roundRect(ctx, x + pad, y + pad, 80, 80, 10);
    ctx.stroke();
    if (item.icon) {
      ctx.font = '48px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(item.icon, x + pad + 40, y + pad + 40);
    }

    // Name + rarity.
    ctx.fillStyle = TEXT.primary;
    ctx.font = fontCss('section');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(item.name ?? 'Unknown', x + pad + 96, y + pad + 6);

    drawBadge(ctx, x + pad + 96, y + pad + 48, (item.rarity ?? 'common').toUpperCase(), { color: rarity });

    // Description.
    let cursorY = y + pad + 110;
    drawSectionTitle(ctx, x + pad, cursorY, w - pad * 2, 'Description');
    cursorY += 50;
    ctx.fillStyle = TEXT.secondary;
    ctx.font = fontCss('bodySmall');
    const lines = wrapLines(ctx, item.description ?? '—', w - pad * 2);
    for (const line of lines.slice(0, 4)) {
      ctx.fillText(line, x + pad, cursorY);
      cursorY += 24;
    }

    // Stats.
    if (item.stats?.length) {
      cursorY += 16;
      drawSectionTitle(ctx, x + pad, cursorY, w - pad * 2, 'Stats');
      cursorY += 50;
      for (const s of item.stats.slice(0, 6)) {
        drawStatRow(ctx, x + pad, cursorY, w - pad * 2, 34, s.name, String(s.value), { accent: rarity });
        cursorY += 40;
      }
    }

    // Capacity bar.
    const total = (data.items ?? []).filter((i) => i).length;
    const cap = data.capacity ?? this.cols * this.rows;
    drawProgressBar(ctx, x + pad, y + h - 40, w - pad * 2, 24, total / cap, {
      color: UI.emerald,
      label: `${total} / ${cap}`,
    });
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: `Gold: ${formatNumber(data.gold ?? 0)}`,
      right: `Gems: ${formatNumber(data.gems ?? 0)}`,
      center: '🎒 Inventory',
    });
  }
}

/** Local word-wrap helper. */
function wrapLines(ctx, text, maxW) {
  const out = [];
  for (const paragraph of String(text).split('\n')) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxW && line) {
        out.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    out.push(line);
  }
  return out;
}

/**
 * @param {InventoryData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new InventoryRenderer().render(data);
}

export default { render, InventoryRenderer };
