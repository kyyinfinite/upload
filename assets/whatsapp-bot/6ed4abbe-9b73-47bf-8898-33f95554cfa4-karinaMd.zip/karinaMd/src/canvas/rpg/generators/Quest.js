/**
 * @file Quest.js
 * @description Quest card renderer. Banner header, quest giver portrait,
 *   objectives list, rewards panel, and an accept/decline-style footer.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT, RARITY } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle, drawStatRow, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette, drawSparkles } from '../components/Effects.js';

/**
 * @typedef {Object} Objective
 * @property {string} text
 * @property {number} [current]
 * @property {number} [target]
 * @property {boolean} [done]
 *
 * @typedef {Object} QuestData
 * @property {string} title
 * @property {string} [giver]
 * @property {string} [description]
 * @property {string} [rarity]
 * @property {string} [difficulty]
 * @property {number} [recommendedLevel]
 * @property {Objective[]} [objectives]
 * @property {{name:string,icon?:string,count?:number}[]} [rewards]
 * @property {number} [timeLeftMs]
 */

export class QuestRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.QUEST });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'quest' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, { title: data.title ?? 'Quest', subtitle: data.giver ? `From ${data.giver}` : 'Quest Card' });

    // Rarity ribbon.
    const rarity = RARITY[data.rarity ?? 'common'] ?? RARITY.common;
    ctx.fillStyle = rarity;
    ctx.fillRect(pad, top, w - pad * 2, 6);

    // Description block.
    let y = top + 24;
    drawSectionTitle(ctx, pad, y, w - pad * 2, 'Description', { accent: rarity });
    y += 50;
    ctx.fillStyle = TEXT.secondary;
    ctx.font = fontCss('body');
    const desc = data.description ?? 'No description available.';
    const lines = wrapLines(ctx, desc, w - pad * 2);
    for (const line of lines.slice(0, 5)) {
      ctx.fillText(line, pad, y);
      y += 28;
    }
    y += 16;

    // Difficulty + recommended level.
    drawBadge(ctx, pad, y, `Difficulty: ${data.difficulty ?? 'Normal'}`, { color: UI.gold });
    if (data.recommendedLevel != null) {
      drawBadge(ctx, pad + 230, y, `Rec. Lvl ${data.recommendedLevel}`, { color: UI.royal });
    }
    if (data.timeLeftMs != null) {
      drawBadge(ctx, pad + 410, y, `⏳ ${formatDuration(data.timeLeftMs)}`, { color: UI.blood });
    }
    y += 50;

    // Objectives.
    drawSectionTitle(ctx, pad, y, w - pad * 2, 'Objectives', { accent: rarity });
    y += 50;
    const objs = data.objectives ?? [];
    for (const o of objs) {
      ctx.save();
      // Checkbox.
      ctx.strokeStyle = rarity;
      ctx.lineWidth = 2;
      roundRect(ctx, pad, y, 24, 24, 4);
      ctx.stroke();
      if (o.done) {
        ctx.fillStyle = rarity;
        roundRect(ctx, pad + 4, y + 4, 16, 16, 2);
        ctx.fill();
        ctx.fillStyle = TEXT.light;
        ctx.font = '700 16px Cinzel, serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('✓', pad + 12, y + 12);
      }
      // Text.
      ctx.fillStyle = o.done ? TEXT.muted : TEXT.primary;
      ctx.font = fontCss('body');
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(o.text, pad + 36, y + 12);

      // Progress.
      if (o.target != null) {
        const px = pad + 36 + ctx.measureText(o.text).width + 16;
        const pw = w - pad * 2 - (px - pad) - 8;
        if (pw > 80) {
          drawProgressBar(ctx, px, y + 4, pw, 18, o.target ? (o.current ?? 0) / o.target : 0, {
            color: o.done ? UI.emerald : UI.gold,
            label: `${o.current ?? 0} / ${o.target}`,
          });
        }
      }
      ctx.restore();
      y += 38;
    }
    y += 20;

    // Rewards.
    drawSectionTitle(ctx, pad, y, w - pad * 2, 'Rewards', { accent: rarity });
    y += 50;
    const rewards = data.rewards ?? [];
    const rwW = (w - pad * 2 - 5 * 8) / 6;
    for (let i = 0; i < Math.min(rewards.length, 6); i++) {
      const rx = pad + i * (rwW + 8);
      ctx.fillStyle = withAlpha(UI.gold, 0.25);
      roundRect(ctx, rx, y, rwW, 80, 8);
      ctx.fill();
      ctx.strokeStyle = UI.gold;
      ctx.lineWidth = 2;
      roundRect(ctx, rx, y, rwW, 80, 8);
      ctx.stroke();

      if (rewards[i].icon) {
        ctx.font = '36px serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(rewards[i].icon, rx + rwW / 2, y + 30);
      }
      ctx.fillStyle = TEXT.primary;
      ctx.font = fontCss('bodySmall');
      ctx.fillText(rewards[i].name, rx + rwW / 2, y + 60);
      if (rewards[i].count != null) {
        ctx.fillStyle = UI.gold;
        ctx.font = fontCss('badge');
        ctx.fillText(`x${formatNumber(rewards[i].count)}`, rx + rwW / 2, y + 74);
      }
    }
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
    drawSparkles(ctx, SAFE_PADDING, SAFE_PADDING + HEADER_HEIGHT, this.size.width - SAFE_PADDING * 2, 200, {
      count: 10, color: UI.goldLight, seed: 'quest-sparkles',
    });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: data.giver ? `Quest Giver: ${data.giver}` : 'Quest Card',
      right: new Date().toLocaleDateString(),
      center: '📜 Quest',
    });
  }
}

function wrapLines(ctx, text, maxW) {
  const out = [];
  for (const paragraph of String(text).split('\n')) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxW && line) {
        out.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    out.push(line);
  }
  return out;
}

function formatDuration(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2,'0')}m`;
  if (m > 0) return `${m}m ${String(sec).padStart(2,'0')}s`;
  return `${sec}s`;
}

/**
 * @param {QuestData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new QuestRenderer().render(data);
}

export default { render, QuestRenderer };
