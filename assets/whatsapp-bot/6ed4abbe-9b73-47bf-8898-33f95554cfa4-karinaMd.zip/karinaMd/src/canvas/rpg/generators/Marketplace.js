/**
 * @file Marketplace.js
 * @description Shop / marketplace renderer. Left: category sidebar. Right:
 *   item grid with prices and stock. Bottom: player's gold + cart summary.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, RARITY, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette } from '../components/Effects.js';

/**
 * @typedef {Object} ShopItem
 * @property {string} id
 * @property {string} name
 * @property {string} [icon]
 * @property {number} price
 * @property {number} [stock]
 * @property {string} [rarity]
 * @property {string} [category]
 *
 * @typedef {Object} ShopData
 * @property {string} [title]
 * @property {string} [npc]
 * @property {number} [gold]
 * @property {ShopItem[]} items
 * @property {string[]} [categories]
 * @property {string} [activeCategory]
 * @property {{id:string,qty:number}[]} [cart]
 */

export class MarketplaceRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.SHOP });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'shop' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, {
      title: data.title ?? 'Marketplace',
      subtitle: data.npc ? `Merchant: ${data.npc}` : 'General Store',
    });

    // Sidebar.
    const sideW = 220;
    const sideX = pad;
    const sideY = top;
    const sideH = h - sideY - SAFE_PADDING - 90;
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.3);
    roundRect(ctx, sideX, sideY, sideW, sideH, 10);
    ctx.fill();

    const cats = data.categories ?? ['All', 'Weapons', 'Armor', 'Potions', 'Misc'];
    let cy = sideY + 20;
    for (const c of cats) {
      const active = c === (data.activeCategory ?? 'All');
      ctx.fillStyle = active ? UI.gold : withAlpha(PAPER.dark, 0.4);
      roundRect(ctx, sideX + 12, cy, sideW - 24, 36, 6);
      ctx.fill();
      ctx.fillStyle = active ? TEXT.light : TEXT.primary;
      ctx.font = fontCss('body');
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(c, sideX + 24, cy + 18);
      cy += 44;
    }

    // Items grid.
    const gridX = sideX + sideW + 20;
    const gridY = sideY;
    const gridW = w - pad - gridX;
    const cols = 3;
    const slotW = (gridW - (cols - 1) * 12) / cols;
    const slotH = 140;
    const items = data.items ?? [];
    for (let i = 0; i < items.length; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const ix = gridX + col * (slotW + 12);
      const iy = gridY + row * (slotH + 12);
      if (iy + slotH > h - SAFE_PADDING - 100) break;
      this.drawShopSlot(ix, iy, slotW, slotH, items[i], data.cart ?? []);
    }
  }

  drawShopSlot(x, y, w, h, item, cart) {
    const { ctx, data } = this;
    const rarity = RARITY[item.rarity] ?? RARITY.common;
    const inCart = cart.find((c) => c.id === item.id);

    // Backing.
    ctx.fillStyle = withAlpha(PAPER.shadow, 0.3);
    roundRect(ctx, x, y, w, h, 10);
    ctx.fill();

    // Rarity stripe on left.
    ctx.fillStyle = rarity;
    roundRect(ctx, x, y, 4, h, 2);
    ctx.fill();

    // Icon area.
    ctx.fillStyle = withAlpha(rarity, 0.2);
    roundRect(ctx, x + 12, y + 12, 70, 70, 8);
    ctx.fill();
    if (item.icon) {
      ctx.font = '40px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(item.icon, x + 47, y + 47);
    }

    // Name + category.
    ctx.fillStyle = TEXT.primary;
    ctx.font = fontCss('body');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(item.name, x + 92, y + 14);
    ctx.fillStyle = TEXT.muted;
    ctx.font = fontCss('bodySmall');
    ctx.fillText(item.category ?? '', x + 92, y + 38);

    // Rarity badge.
    drawBadge(ctx, x + 92, y + 60, (item.rarity ?? 'common').toUpperCase(), { color: rarity });

    // Price + stock row.
    ctx.fillStyle = UI.gold;
    ctx.font = fontCss('stat');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'bottom';
    ctx.fillText(`💰 ${formatNumber(item.price)}`, x + 14, y + h - 14);

    if (item.stock != null) {
      ctx.fillStyle = item.stock > 0 ? TEXT.secondary : UI.blood;
      ctx.font = fontCss('bodySmall');
      ctx.textAlign = 'right';
      ctx.fillText(item.stock > 0 ? `Stock: ${item.stock}` : 'SOLD OUT', x + w - 14, y + h - 14);
    }

    if (inCart) {
      ctx.fillStyle = UI.emerald;
      roundRect(ctx, x + w - 50, y + 12, 36, 24, 6);
      ctx.fill();
      ctx.fillStyle = TEXT.light;
      ctx.font = fontCss('badge');
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`x${inCart.qty}`, x + w - 32, y + 24);
    }

    void data;
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;

    drawBorder(ctx, w, h);

    // Cart summary bar.
    const cart = data.cart ?? [];
    const cartCount = cart.reduce((s, c) => s + c.qty, 0);
    const cartTotal = cart.reduce((s, c) => {
      const it = (data.items ?? []).find((i) => i.id === c.id);
      return s + (it ? it.price * c.qty : 0);
    }, 0);

    const barY = h - SAFE_PADDING - 80;
    ctx.fillStyle = withAlpha(UI.goldDark, 0.85);
    roundRect(ctx, SAFE_PADDING + 20, barY, w - (SAFE_PADDING + 20) * 2, 50, 10);
    ctx.fill();
    ctx.fillStyle = TEXT.light;
    ctx.font = fontCss('body');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(`🛒 Cart: ${cartCount} item(s)`, SAFE_PADDING + 40, barY + 25);
    ctx.textAlign = 'right';
    ctx.fillText(`Total: 💰 ${formatNumber(cartTotal)}   |   Your gold: 💰 ${formatNumber(data.gold ?? 0)}`, w - SAFE_PADDING - 40, barY + 25);

    drawFooter(ctx, w, h, {
      left: data.title ?? 'Marketplace',
      right: new Date().toLocaleDateString(),
      center: '🛒 Shop',
    });
  }
}

/**
 * @param {ShopData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new MarketplaceRenderer().render(data);
}

export default { render, MarketplaceRenderer };
