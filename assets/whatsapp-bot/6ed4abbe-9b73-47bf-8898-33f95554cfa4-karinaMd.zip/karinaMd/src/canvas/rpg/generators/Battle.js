/**
 * @file Battle.js
 * @description Battle scene renderer. Draws attacker vs defender with HP
 *   bars, damage popups, action log, and turn indicator.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT, TERRAIN } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';
import { createRandom } from '../core/Random.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawPlayer } from '../components/Player.js';
import { drawProgressBar, drawBadge } from '../components/Labels.js';
import { drawVignette, drawSparkles } from '../components/Effects.js';

/**
 * @typedef {Object} Combatant
 * @property {string}  name
 * @property {string}  [class]
 * @property {string}  [monsterType]   If set, draws a generic monster glyph.
 * @property {number}  hp
 * @property {number}  maxHp
 * @property {number}  [mp]
 * @property {number}  [maxMp]
 * @property {number}  [level]
 * @property {string}  [icon]          Emoji glyph for monsters.
 */

/**
 * @typedef {Object} BattleData
 * @property {Combatant} player
 * @property {Combatant} enemy
 * @property {number}    [turn=1]
 * @property {'player'|'enemy'} [turnSide]
 * @property {string[]} [log]
 * @property {{target:'player'|'enemy',amount:number,crit?:boolean}[]} [popups]
 * @property {string}   [seed]
 */

export class BattleRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.BATTLE });
  }

  async initialize() {
    this.rng = createRandom(this.data.seed ?? 'battle');
    /** @type {Combatant} */
    this.player = this.data.player ?? { name: 'Player', hp: 1, maxHp: 1 };
    /** @type {Combatant} */
    this.enemy = this.data.enemy ?? { name: 'Enemy', hp: 1, maxHp: 1 };
  }

  async drawBackground() {
    const { ctx } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawPaper(ctx, w, h, { seed: 'battle' });

    // Sky gradient.
    const sky = ctx.createLinearGradient(0, 0, 0, h * 0.6);
    sky.addColorStop(0, shade(UI.royal, -0.3));
    sky.addColorStop(1, shade(UI.blood, -0.4));
    ctx.fillStyle = sky;
    ctx.fillRect(SAFE_PADDING, SAFE_PADDING + HEADER_HEIGHT, w - SAFE_PADDING * 2, h * 0.45);

    // Ground.
    const ground = ctx.createLinearGradient(0, h * 0.55, 0, h);
    ground.addColorStop(0, TERRAIN.grass.dark);
    ground.addColorStop(1, shade(TERRAIN.grass.dark, -0.2));
    ctx.fillStyle = ground;
    ctx.fillRect(SAFE_PADDING, h * 0.55, w - SAFE_PADDING * 2, h * 0.35);
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    const stageY = h * 0.55;

    // Player on the left.
    const px = w * 0.32;
    drawPlayer(ctx, px, stageY - 20, 110, {
      cls: this.player.class ?? 'warrior',
      name: this.player.name,
      seed: `p:${this.player.name}`,
    });

    // Enemy on the right.
    const ex = w * 0.68;
    if (this.enemy.monsterType) {
      drawMonster(ctx, ex, stageY - 20, 110, this.enemy, this.rng);
    } else {
      drawPlayer(ctx, ex, stageY - 20, 110, {
        cls: this.enemy.class ?? 'rogue',
        name: this.enemy.name,
        seed: `e:${this.enemy.name}`,
      });
    }

    // HP/MP bars above each combatant.
    drawCombatantBars(ctx, px - 110, stageY - 180, 220, this.player, data.turnSide === 'player');
    drawCombatantBars(ctx, ex - 110, stageY - 180, 220, this.enemy, data.turnSide === 'enemy');

    // Damage popups.
    const popups = data.popups ?? [];
    for (const p of popups) {
      const tx = p.target === 'player' ? px : ex;
      drawDamagePopup(ctx, tx, stageY - 220, p.amount, p.crit);
    }
  }

  async drawDecorations() {
    const { ctx } = this;
    drawSparkles(ctx, this.size.width * 0.25, this.size.height * 0.3, this.size.width * 0.5, 60, {
      count: 14, color: UI.goldLight, seed: 'battle-sparkles',
    });
  }

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.55 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;

    drawBorder(ctx, w, h);
    drawHeader(ctx, w, {
      title: `Battle — Turn ${data.turn ?? 1}`,
      subtitle: data.turnSide === 'enemy' ? "Enemy's move" : 'Your move',
      accent: data.turnSide === 'enemy' ? UI.blood : UI.emerald,
    });

    // Action log at the bottom.
    const logY = h * 0.78;
    const logH = h - logY - SAFE_PADDING - 80;
    const logX = SAFE_PADDING + 20;
    const logW = w - (SAFE_PADDING + 20) * 2;

    ctx.fillStyle = withAlpha(PAPER.ink, 0.5);
    roundRect(ctx, logX, logY, logW, logH, 10);
    ctx.fill();

    ctx.fillStyle = withAlpha(UI.gold, 0.7);
    ctx.font = fontCss('badge');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText('BATTLE LOG', logX + 14, logY + 10);

    ctx.fillStyle = TEXT.light;
    ctx.font = fontCss('bodySmall');
    const log = data.log ?? [];
    let ly = logY + 36;
    for (const line of log.slice(-5)) {
      ctx.fillText(`• ${line}`, logX + 22, ly);
      ly += 24;
    }

    drawFooter(ctx, w, h, {
      left: this.player.name,
      right: `vs ${this.enemy.name}`,
      center: '⚔ Battle ⚔',
    });
  }
}

/**
 * Draw HP / MP bars + name plate for a combatant.
 */
function drawCombatantBars(ctx, x, y, w, c, isActive) {
  ctx.save();
  // Name plate.
  ctx.fillStyle = withAlpha(PAPER.ink, 0.7);
  roundRect(ctx, x, y, w, 28, 6);
  ctx.fill();
  if (isActive) {
    ctx.strokeStyle = UI.goldLight;
    ctx.lineWidth = 2;
    roundRect(ctx, x, y, w, 28, 6);
    ctx.stroke();
  }
  ctx.fillStyle = TEXT.light;
  ctx.font = fontCss('badge');
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(c.name, x + 10, y + 14);
  if (c.level != null) {
    ctx.textAlign = 'right';
    ctx.fillText(`LVL ${c.level}`, x + w - 10, y + 14);
  }

  // HP bar.
  drawProgressBar(ctx, x, y + 34, w, 22, c.maxHp ? c.hp / c.maxHp : 1, {
    color: UI.blood,
    label: `${formatNumber(c.hp)} / ${formatNumber(c.maxHp)}`,
  });
  // MP bar.
  if (c.maxMp != null) {
    drawProgressBar(ctx, x, y + 62, w, 16, c.maxMp ? c.mp / c.maxMp : 1, {
      color: UI.sapphire,
      label: `${c.mp} MP`,
    });
  }
  ctx.restore();
}

/**
 * Draw a damage popup.
 */
function drawDamagePopup(ctx, x, y, amount, crit) {
  ctx.save();
  const text = `-${formatNumber(amount)}`;
  ctx.font = crit ? `900 48px Cinzel, serif` : `700 36px Cinzel, serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 4;
  ctx.strokeStyle = '#000000';
  ctx.strokeText(text, x, y);
  ctx.fillStyle = crit ? UI.gold : UI.blood;
  ctx.fillText(text, x, y);
  if (crit) {
    ctx.font = '700 18px Cinzel, serif';
    ctx.fillStyle = UI.goldLight;
    ctx.fillText('CRITICAL!', x, y - 32);
  }
  ctx.restore();
}

/**
 * Draw a stylized monster. Falls back to a colored blob with an emoji glyph.
 */
function drawMonster(ctx, cx, cy, r, enemy, rng) {
  ctx.save();
  // Shadow.
  ctx.fillStyle = withAlpha('#000000', 0.35);
  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.95, r * 0.9, r * 0.25, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body.
  const colors = {
    goblin:  TERRAIN.forest.dark,
    orc:     TERRAIN.grass.dark,
    dragon:  UI.blood,
    skeleton:'#e0e0d8',
    ghost:   withAlpha('#c0c0ff', 0.7),
    slime:   UI.emerald,
  };
  const bodyColor = colors[enemy.monsterType] ?? UI.iron;
  ctx.fillStyle = bodyColor;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  // Shading.
  ctx.fillStyle = withAlpha('#000000', 0.25);
  ctx.beginPath();
  ctx.arc(cx + r * 0.25, cy + r * 0.15, r * 0.7, 0, Math.PI * 2);
  ctx.fill();

  // Eyes.
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(cx - r * 0.3, cy - r * 0.2, r * 0.15, 0, Math.PI * 2);
  ctx.arc(cx + r * 0.3, cy - r * 0.2, r * 0.15, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(cx - r * 0.27, cy - r * 0.18, r * 0.07, 0, Math.PI * 2);
  ctx.arc(cx + r * 0.33, cy - r * 0.18, r * 0.07, 0, Math.PI * 2);
  ctx.fill();

  // Mouth.
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(cx, cy + r * 0.25, r * 0.25, 0.2 * Math.PI, 0.8 * Math.PI);
  ctx.stroke();

  // Icon overlay if provided.
  if (enemy.icon) {
    ctx.font = `${Math.round(r * 1.4)}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(enemy.icon, cx, cy - r * 1.1);
  }

  // Name label.
  ctx.font = `600 18px Cinzel, serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  const labelW = ctx.measureText(enemy.name).width + 24;
  ctx.fillStyle = withAlpha('#000000', 0.6);
  roundRect(ctx, cx - labelW / 2, cy + r * 1.1, labelW, 26, 6);
  ctx.fill();
  ctx.fillStyle = TEXT.light;
  ctx.fillText(enemy.name, cx, cy + r * 1.14);

  void rng;
  ctx.restore();
}

/**
 * @param {BattleData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new BattleRenderer().render(data);
}

export default { render, BattleRenderer };
