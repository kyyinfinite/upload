/**
 * @file Achievement.js
 * @description Achievement panel renderer. Grid of achievement badges with
 *   unlocked/locked states, progress bars, and category filter chips.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, RARITY, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette } from '../components/Effects.js';

/**
 * @typedef {Object} AchievementItem
 * @property {string} id
 * @property {string} name
 * @property {string} [icon]
 * @property {string} [description]
 * @property {string} [rarity]
 * @property {boolean} [unlocked]
 * @property {number} [progress]    0..1
 * @property {number} [points]
 *
 * @typedef {Object} AchievementData
 * @property {string} [player]
 * @property {number} [totalPoints]
 * @property {number} [unlockedCount]
 * @property {number} [totalCount]
 * @property {AchievementItem[]} [achievements]
 * @property {string[]} [categories]
 * @property {string} [activeCategory]
 */

export class AchievementRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.ACHIEVEMENT });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'achievement' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, {
      title: 'Achievements',
      subtitle: data.player ?? 'Adventurer',
    });

    // Summary bar.
    drawSectionTitle(ctx, pad, top, w - pad * 2, 'Progress');
    const unlockRatio = data.totalCount ? (data.unlockedCount ?? 0) / data.totalCount : 0;
    drawProgressBar(ctx, pad, top + 50, w - pad * 2, 28, unlockRatio, {
      color: UI.gold,
      label: `${data.unlockedCount ?? 0} / ${data.totalCount ?? 0} • ${formatNumber(data.totalPoints ?? 0)} pts`,
    });

    // Category chips.
    const cats = data.categories ?? ['All', 'Combat', 'Exploration', 'Social', 'Collection'];
    let cx = pad;
    const catY = top + 100;
    for (const c of cats) {
      const active = c === (data.activeCategory ?? 'All');
      ctx.fillStyle = active ? UI.gold : withAlpha(PAPER.dark, 0.5);
      const tw = ctx.measureText(c).width;
      roundRect(ctx, cx, catY, tw + 28, 30, 15);
      ctx.fill();
      ctx.fillStyle = active ? TEXT.light : TEXT.primary;
      ctx.font = fontCss('bodySmall');
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(c, cx + (tw + 28) / 2, catY + 15);
      cx += tw + 36;
    }

    // Achievement grid.
    const gridY = catY + 50;
    const cols = 4;
    const slotW = (w - pad * 2 - (cols - 1) * 14) / cols;
    const slotH = 200;
    const items = data.achievements ?? [];
    for (let i = 0; i < items.length; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const ix = pad + col * (slotW + 14);
      const iy = gridY + row * (slotH + 14);
      if (iy + slotH > this.size.height - SAFE_PADDING - 80) break;
      this.drawAchievementSlot(ix, iy, slotW, slotH, items[i]);
    }
  }

  drawAchievementSlot(x, y, w, h, ach) {
    const { ctx } = this;
    const rarity = RARITY[ach.rarity] ?? RARITY.common;
    const unlocked = !!ach.unlocked;

    // Backing.
    ctx.fillStyle = unlocked ? withAlpha(rarity, 0.15) : withAlpha(PAPER.shadow, 0.4);
    roundRect(ctx, x, y, w, h, 10);
    ctx.fill();

    // Border.
    ctx.strokeStyle = unlocked ? rarity : PAPER.edge;
    ctx.lineWidth = unlocked ? 3 : 1.5;
    roundRect(ctx, x, y, w, h, 10);
    ctx.stroke();

    // Icon area.
    ctx.fillStyle = unlocked ? withAlpha(rarity, 0.3) : withAlpha('#000000', 0.4);
    roundRect(ctx, x + w / 2 - 40, y + 16, 80, 80, 12);
    ctx.fill();
    ctx.strokeStyle = unlocked ? rarity : PAPER.edge;
    ctx.lineWidth = 2;
    roundRect(ctx, x + w / 2 - 40, y + 16, 80, 80, 12);
    ctx.stroke();

    if (ach.icon) {
      ctx.font = '44px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = unlocked ? TEXT.primary : withAlpha(TEXT.muted, 0.5);
      ctx.fillText(unlocked ? ach.icon : '🔒', x + w / 2, y + 56);
    }

    // Name.
    ctx.fillStyle = unlocked ? TEXT.primary : TEXT.muted;
    ctx.font = fontCss('body');
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(ach.name ?? 'Achievement', x + w / 2, y + 108);

    // Description.
    ctx.fillStyle = TEXT.secondary;
    ctx.font = fontCss('bodyTiny');
    const desc = ach.description ?? '';
    const lines = wrapLines(ctx, desc, w - 24);
    for (let i = 0; i < Math.min(2, lines.length); i++) {
      ctx.fillText(lines[i], x + w / 2, y + 134 + i * 16);
    }

    // Progress or points.
    if (unlocked) {
      ctx.fillStyle = UI.gold;
      ctx.font = fontCss('badge');
      ctx.fillText(`+${ach.points ?? 0} pts`, x + w / 2, y + h - 22);
    } else if (ach.progress != null) {
      drawProgressBar(ctx, x + 12, y + h - 22, w - 24, 14, ach.progress, {
        color: UI.gold,
      });
    }
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: `${data.unlockedCount ?? 0} / ${data.totalCount ?? 0} unlocked`,
      right: `${formatNumber(data.totalPoints ?? 0)} pts`,
      center: '🏅 Achievements',
    });
  }
}

function wrapLines(ctx, text, maxW) {
  const out = [];
  for (const paragraph of String(text).split('\n')) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxW && line) {
        out.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    out.push(line);
  }
  return out;
}

/**
 * @param {AchievementData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new AchievementRenderer().render(data);
}

export default { render, AchievementRenderer };
