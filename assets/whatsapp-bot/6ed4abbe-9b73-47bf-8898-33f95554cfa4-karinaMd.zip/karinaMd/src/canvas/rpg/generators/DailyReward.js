/**
 * @file DailyReward.js
 * @description Daily reward renderer. 7-day reward track with the current
 *   day highlighted, claim animation, and streak counter.
 */

import { Renderer } from '../core/Renderer.js';
import { CANVAS_SIZES, SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { PAPER, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect, formatNumber } from '../core/Helpers.js';

import { drawPaper } from '../components/Paper.js';
import { drawBorder } from '../components/Border.js';
import { drawHeader } from '../components/Header.js';
import { drawFooter } from '../components/Footer.js';
import { drawSectionTitle, drawBadge, drawProgressBar } from '../components/Labels.js';
import { drawVignette, drawSparkles, drawGlow } from '../components/Effects.js';

/**
 * @typedef {Object} DailyReward
 * @property {string} [icon]
 * @property {string} [name]
 * @property {number} [count]
 * @property {boolean} [claimed]
 *
 * @typedef {Object} DailyRewardData
 * @property {number} [day=1]            Current day (1..7).
 * @property {number} [streak]
 * @property {DailyReward[]} [rewards]   Length 7.
 * @property {boolean} [canClaim]
 * @property {string} [player]
 */

export class DailyRewardRenderer extends Renderer {
  constructor() {
    super({ size: CANVAS_SIZES.DAILY });
  }

  async initialize() {}

  async drawBackground() {
    const { ctx } = this;
    drawPaper(ctx, this.size.width, this.size.height, { seed: 'daily' });
  }

  async drawObjects() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    const pad = SAFE_PADDING + 20;
    const top = SAFE_PADDING + HEADER_HEIGHT + 30;

    drawHeader(ctx, w, {
      title: 'Daily Rewards',
      subtitle: data.player ? `${data.player} • Day ${data.day ?? 1}` : `Day ${data.day ?? 1}`,
    });

    // Streak.
    const streak = data.streak ?? 0;
    drawSectionTitle(ctx, pad, top, w - pad * 2, 'Streak Progress');
    drawProgressBar(ctx, pad, top + 50, w - pad * 2, 28, Math.min(1, streak / 7), {
      color: UI.blood,
      label: `🔥 ${streak}-day streak`,
    });

    // 7-day grid.
    const gridY = top + 110;
    const cols = 7;
    const slotW = (w - pad * 2 - (cols - 1) * 12) / cols;
    const slotH = 320;
    const rewards = data.rewards ?? defaultRewards();
    const today = (data.day ?? 1) - 1;

    for (let i = 0; i < cols; i++) {
      const x = pad + i * (slotW + 12);
      const y = gridY;
      const isToday = i === today;
      const isClaimed = rewards[i]?.claimed;
      const isPast = i < today;

      this.drawRewardSlot(x, y, slotW, slotH, i + 1, rewards[i] ?? {}, {
        isToday,
        isClaimed,
        isPast,
        canClaim: data.canClaim && isToday,
      });
    }

    // Claim button.
    const btnY = gridY + slotH + 30;
    const btnW = 280;
    const btnH = 60;
    const btnX = (w - btnW) / 2;
    const canClaim = data.canClaim;
    ctx.fillStyle = canClaim ? UI.gold : withAlpha(UI.iron, 0.7);
    roundRect(ctx, btnX, btnY, btnW, btnH, 12);
    ctx.fill();
    ctx.fillStyle = canClaim ? shade(UI.gold, -0.3) : '#000000';
    ctx.font = `700 26px Cinzel, serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(canClaim ? 'CLAIM REWARD' : 'CLAIMED TODAY', btnX + btnW / 2, btnY + btnH / 2 + 2);

    if (canClaim) {
      drawGlow(ctx, btnX + btnW / 2, btnY + btnH / 2, 200, UI.goldLight, 0.6);
    }
  }

  drawRewardSlot(x, y, w, h, day, reward, state) {
    const { ctx } = this;
    const accent = state.isToday ? UI.gold : state.isPast ? UI.emerald : PAPER.edge;

    // Backing.
    ctx.fillStyle = state.isToday ? withAlpha(UI.gold, 0.18) : withAlpha(PAPER.shadow, 0.3);
    roundRect(ctx, x, y, w, h, 12);
    ctx.fill();

    // Border.
    ctx.strokeStyle = accent;
    ctx.lineWidth = state.isToday ? 4 : 2;
    roundRect(ctx, x, y, w, h, 12);
    ctx.stroke();

    // Day label.
    ctx.fillStyle = accent;
    ctx.font = fontCss('badge');
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(`DAY ${day}`, x + w / 2, y + 12);

    // Icon.
    ctx.font = `${Math.round(w * 0.5)}px serif`;
    ctx.textBaseline = 'middle';
    ctx.fillText(reward.icon ?? '🎁', x + w / 2, y + h / 2 - 10);

    // Name.
    ctx.fillStyle = TEXT.primary;
    ctx.font = fontCss('bodySmall');
    ctx.textBaseline = 'top';
    ctx.fillText(reward.name ?? 'Reward', x + w / 2, y + h - 70);

    // Count.
    if (reward.count != null) {
      ctx.fillStyle = UI.gold;
      ctx.font = fontCss('stat');
      ctx.fillText(`x${formatNumber(reward.count)}`, x + w / 2, y + h - 44);
    }

    // Status badge.
    if (state.isClaimed || state.isPast) {
      ctx.fillStyle = state.isClaimed ? UI.emerald : PAPER.edge;
      drawBadgeLocal(ctx, x + w / 2 - 50, y + h - 24, 100, 22, state.isClaimed ? '✓ CLAIMED' : 'PAST', state.isClaimed ? UI.emerald : PAPER.edge);
    } else if (state.isToday) {
      drawBadgeLocal(ctx, x + w / 2 - 50, y + h - 24, 100, 22, 'TODAY', UI.gold);
    }
  }

  async drawDecorations() {}

  async drawEffects() {
    const { ctx } = this;
    drawVignette(ctx, this.size.width, this.size.height, { strength: 0.4 });
    drawSparkles(ctx, SAFE_PADDING, SAFE_PADDING + HEADER_HEIGHT, this.size.width - SAFE_PADDING * 2, 200, {
      count: 14, color: UI.goldLight, seed: 'daily-sparkles',
    });
  }

  async drawUI() {
    const { ctx, data } = this;
    const w = this.size.width;
    const h = this.size.height;
    drawBorder(ctx, w, h);
    drawFooter(ctx, w, h, {
      left: `Day ${data.day ?? 1} / 7`,
      right: `Streak: ${data.streak ?? 0}`,
      center: '🎁 Daily Reward',
    });
  }
}

function drawBadgeLocal(ctx, x, y, w, h, text, color) {
  ctx.fillStyle = color;
  roundRect(ctx, x, y, w, h, 6);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = fontCss('badge');
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x + w / 2, y + h / 2 - 1);
}

function defaultRewards() {
  return [
    { icon: '🪙', name: 'Gold',       count: 100 },
    { icon: '⚗️', name: 'Potion',     count: 3 },
    { icon: '🪙', name: 'Gold',       count: 250 },
    { icon: '💎', name: 'Gems',       count: 5 },
    { icon: '📦', name: 'Loot Box',   count: 1 },
    { icon: '⚔️', name: 'Sword Shard', count: 2 },
    { icon: '🏆', name: 'Mega Chest', count: 1 },
  ];
}

/**
 * @param {DailyRewardData} data
 * @returns {Promise<Buffer>}
 */
export async function render(data) {
  return new DailyRewardRenderer().render(data);
}

export default { render, DailyRewardRenderer };
