# assets/

All on-disk assets used by the RPG Canvas library. Drop real PNG / TTF files
into the appropriate subfolder.

| Folder         | Contents                                              |
| -------------- | ----------------------------------------------------- |
| `fonts/`       | TTF font files registered by `core/Fonts.js`           |
| `icons/`       | Small icon PNGs (item icons, spell icons, etc.)        |
| `textures/`    | Tileable background textures                           |
| `decorations/` | Decorative sprite PNGs                                 |
| `monsters/`    | Monster sprite PNGs                                    |
| `npc/`         | NPC portrait PNGs                                      |
| `ui/`          | UI chrome (buttons, frames, panels)                    |
| `maps/`        | Pre-baked map backgrounds (optional)                   |
| `cache/`       | Runtime cache for rendered PNGs (auto-managed)         |

The library is fully procedural and will work without any of these files —
missing assets simply fall back to vector drawing. Drop PNGs in to upgrade
specific elements.
