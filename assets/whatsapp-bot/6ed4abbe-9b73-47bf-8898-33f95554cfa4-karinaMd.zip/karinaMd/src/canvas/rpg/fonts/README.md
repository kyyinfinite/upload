# fonts/

Reserved for font-specific helpers (e.g. font metric measurement, glyph
atlas builders, fallback chains). The current font registration pipeline
lives in `core/Fonts.js`. The actual TTF files live under `assets/fonts/`.
