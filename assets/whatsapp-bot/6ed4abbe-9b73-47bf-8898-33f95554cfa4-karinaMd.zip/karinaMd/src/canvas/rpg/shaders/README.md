# shaders/

Reserved for future procedural shader helpers (e.g. WebGL-style effect chains
or canvas filter wrappers). Currently empty — the library's effects pipeline
lives in `components/Effects.js`.
