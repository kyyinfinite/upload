# textures/

Reserved for high-level texture composition helpers (e.g. layered biome
textures, weather overlays). The current procedural texture primitives live
in `core/TextureCache.js`.
