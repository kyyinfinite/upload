/**
 * @file paths.js
 * @description Asset path constants. All file-system lookups for fonts,
 *   textures, icons and decorations resolve through this module.
 */

import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

/** Root directory of the RPG canvas library. */
export const LIB_ROOT = dirname(fileURLToPath(import.meta.url));

/** Root of the project that consumes the library (two levels up). */
export const PROJECT_ROOT = join(LIB_ROOT, '..', '..', '..', '..');

/** Base assets directory. */
export const ASSETS_DIR = join(LIB_ROOT, '..', 'assets');

export const PATHS = Object.freeze({
  ASSETS_DIR,
  FONTS_DIR:        join(ASSETS_DIR, 'fonts'),
  ICONS_DIR:        join(ASSETS_DIR, 'icons'),
  TEXTURES_DIR:     join(ASSETS_DIR, 'textures'),
  DECORATIONS_DIR:  join(ASSETS_DIR, 'decorations'),
  MONSTERS_DIR:     join(ASSETS_DIR, 'monsters'),
  NPC_DIR:          join(ASSETS_DIR, 'npc'),
  UI_DIR:           join(ASSETS_DIR, 'ui'),
  MAPS_DIR:         join(ASSETS_DIR, 'maps'),
  CACHE_DIR:        join(ASSETS_DIR, 'cache'),
});

/**
 * Resolve an asset filename inside a specific asset sub-folder.
 * @param {keyof typeof PATHS} bucket
 * @param {string} filename
 * @returns {string} Absolute path.
 */
export function assetPath(bucket, filename) {
  const dir = PATHS[bucket];
  if (!dir) throw new Error(`Unknown asset bucket: ${bucket}`);
  return join(dir, filename);
}

export default {
  LIB_ROOT,
  PROJECT_ROOT,
  ASSETS_DIR,
  PATHS,
  assetPath,
};
