/**
 * @file dimensions.js
 * @description Centralized canvas dimension presets. All renderers MUST source
 *   their width/height from this file to avoid magic numbers across the library.
 */

/**
 * Standard canvas size presets (in CSS pixels).
 * The CanvasManager will multiply these by `dpr` for the actual backing store.
 *
 * @enum {readonly {width:number,height:number}}
 */
export const CANVAS_SIZES = Object.freeze({
  /** Adventure map / world map (landscape). */
  MAP: Object.freeze({ width: 1600, height: 1000 }),
  /** Inventory grid (portrait-ish). */
  INVENTORY: Object.freeze({ width: 1000, height: 1200 }),
  /** Player profile (portrait). */
  PROFILE: Object.freeze({ width: 1000, height: 1400 }),
  /** Battle scene (landscape). */
  BATTLE: Object.freeze({ width: 1600, height: 1000 }),
  /** Quest card (portrait). */
  QUEST: Object.freeze({ width: 1000, height: 1300 }),
  /** Guild panel (landscape). */
  GUILD: Object.freeze({ width: 1400, height: 1000 }),
  /** Shop / marketplace (landscape). */
  SHOP: Object.freeze({ width: 1400, height: 1000 }),
  /** Leaderboard (portrait). */
  LEADERBOARD: Object.freeze({ width: 1000, height: 1400 }),
  /** Dungeon interior (landscape). */
  DUNGEON: Object.freeze({ width: 1600, height: 1000 }),
  /** Daily reward (square-ish). */
  DAILY: Object.freeze({ width: 1200, height: 1200 }),
  /** Achievement panel (landscape). */
  ACHIEVEMENT: Object.freeze({ width: 1400, height: 1000 }),
  /** Generic fallback. */
  DEFAULT: Object.freeze({ width: 1200, height: 900 }),
});

/** Default device-pixel-ratio used by the CanvasManager. */
export const DEFAULT_DPR = 2;

/** Safe padding applied around every canvas (px in CSS space). */
export const SAFE_PADDING = 48;

/** Default border thickness in CSS px. */
export const BORDER_THICKNESS = 18;

/** Default header / footer heights in CSS px. */
export const HEADER_HEIGHT = 110;
export const FOOTER_HEIGHT = 90;

export default {
  CANVAS_SIZES,
  DEFAULT_DPR,
  SAFE_PADDING,
  BORDER_THICKNESS,
  HEADER_HEIGHT,
  FOOTER_HEIGHT,
};
