/**
 * @file typography.js
 * @description Font family registrations and style presets. Keep all font
 *   names in sync with AssetLoader.registerFonts().
 */

export const FONT_FAMILY = Object.freeze({
  /** Decorative serif used for big headings, map titles, etc. */
  heading: 'Cinzel',
  /** Readable serif used for body / parchment text. */
  body: 'MedievalSharp',
  /** Monospace used for stats / numbers. */
  mono: 'Sarasa Mono SC',
  /** Fallback sans-serif if a registered font is missing. */
  fallback: 'sans-serif',
});

/**
 * Font style presets. Each preset references {@link FONT_FAMILY} so the actual
 * CSS string is always `'<weight> <size>px <family>'`.
 *
 * @typedef {Object} FontPreset
 * @property {string} family Font family name.
 * @property {number} size   Font size in CSS px.
 * @property {string} weight Font weight keyword or number.
 * @property {string} css    Pre-built CSS font string usable on ctx.font.
 */

/** @type {Record<string, FontPreset>} */
export const FONT_PRESETS = Object.freeze({
  mapTitle:    { family: FONT_FAMILY.heading, size: 64, weight: '700' },
  section:     { family: FONT_FAMILY.heading, size: 38, weight: '700' },
  subSection:  { family: FONT_FAMILY.heading, size: 28, weight: '600' },
  body:        { family: FONT_FAMILY.body,    size: 22, weight: '400' },
  bodySmall:   { family: FONT_FAMILY.body,    size: 18, weight: '400' },
  bodyTiny:    { family: FONT_FAMILY.body,    size: 14, weight: '400' },
  label:       { family: FONT_FAMILY.heading, size: 20, weight: '600' },
  stat:        { family: FONT_FAMILY.mono,    size: 22, weight: '600' },
  statLarge:   { family: FONT_FAMILY.mono,    size: 34, weight: '700' },
  badge:       { family: FONT_FAMILY.heading, size: 16, weight: '700' },
  footer:      { family: FONT_FAMILY.body,    size: 16, weight: '400' },
});

/**
 * Build a CSS font string from a preset.
 * @param {keyof typeof FONT_PRESETS} presetKey
 * @returns {string} CSS font value, e.g. '700 38px Cinzel'.
 */
export function fontCss(presetKey) {
  const p = FONT_PRESETS[presetKey];
  if (!p) throw new Error(`Unknown font preset: ${presetKey}`);
  return `${p.weight} ${p.size}px ${p.family}, ${FONT_FAMILY.fallback}`;
}

export default {
  FONT_FAMILY,
  FONT_PRESETS,
  fontCss,
};
