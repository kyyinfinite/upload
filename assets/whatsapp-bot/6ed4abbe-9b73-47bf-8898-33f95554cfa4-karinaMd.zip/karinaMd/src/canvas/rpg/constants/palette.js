/**
 * @file palette.js
 * @description Centralized color palettes used across every renderer.
 *   No renderer should hardcode hex colors — always import from here.
 */

/**
 * Core parchment / paper tones used by the Paper component and borders.
 */
export const PAPER = Object.freeze({
  base: '#e8d9b0',
  light: '#f3e8c8',
  dark: '#c9b384',
  shadow: '#a89560',
  ink: '#3a2c14',
  edge: '#7a6238',
});

/**
 * Map / terrain palette. Each terrain has a base + accent used for shading.
 */
export const TERRAIN = Object.freeze({
  ocean: { base: '#3a6fb5', light: '#5b8fd6', dark: '#2a4f8a' },
  river: { base: '#4f8fd6', light: '#7ab2e8', dark: '#3a6fb5' },
  forest: { base: '#3f7a3a', light: '#5a9a4a', dark: '#2c5a28' },
  grass: { base: '#a7c66a', light: '#c3dc8a', dark: '#7fa248' },
  desert: { base: '#e0c878', light: '#f0dca0', dark: '#bd9f4f' },
  mountain: { base: '#8c7a5e', light: '#a89678', dark: '#5e4f38' },
  snow: { base: '#e8edf2', light: '#ffffff', dark: '#b9c4cf' },
  road: { base: '#8a6a3a', light: '#a8854f', dark: '#5e4322' },
  swamp: { base: '#5a5a3a', light: '#74743f', dark: '#3a3a22' },
  lava: { base: '#d04a1a', light: '#ff7a3a', dark: '#8a2810' },
});

/**
 * UI accents used for buttons, frames, badges, etc.
 */
export const UI = Object.freeze({
  gold: '#d4a73a',
  goldLight: '#f0c75a',
  goldDark: '#8a6a1a',
  bronze: '#b87838',
  silver: '#c8c8d0',
  iron: '#5a5a62',
  royal: '#5a3a9a',
  blood: '#a82828',
  emerald: '#2a8a4a',
  sapphire: '#2a5ab5',
});

/**
 * Rarity tier colors used by items, achievements, etc.
 */
export const RARITY = Object.freeze({
  common: '#9a9a9a',
  uncommon: '#4aa84a',
  rare: '#3a78d4',
  epic: '#8a3ad4',
  legendary: '#d48a2a',
  mythic: '#d42a5a',
});

/**
 * Text colors for headings / body / hints.
 */
export const TEXT = Object.freeze({
  primary: '#2a1c0a',
  secondary: '#5a4322',
  muted: '#8a724a',
  light: '#f0e4c0',
  gold: '#d4a73a',
  danger: '#a82828',
  success: '#2a8a4a',
});

/**
 * Transparency overlays used by fog, shadows, and night effects.
 */
export const ALPHA = Object.freeze({
  fog: 0.42,
  shadow: 0.32,
  night: 0.38,
  cloud: 0.55,
  vignette: 0.6,
  highlight: 0.18,
});

export default {
  PAPER,
  TERRAIN,
  UI,
  RARITY,
  TEXT,
  ALPHA,
};
