/**
 * @file index.js
 * @description Barrel export for all constant modules. Importing from
 *   `@/src/canvas/rpg/constants` returns a single frozen namespace.
 */

import dimensions from './dimensions.js';
import palette from './palette.js';
import typography from './typography.js';
import paths from './paths.js';

export const DIMENSIONS = dimensions;
export const PALETTE = palette;
export const TYPOGRAPHY = typography;
export const PATHS = paths;

export {
  CANVAS_SIZES,
  DEFAULT_DPR,
  SAFE_PADDING,
  BORDER_THICKNESS,
  HEADER_HEIGHT,
  FOOTER_HEIGHT,
} from './dimensions.js';

export {
  PAPER,
  TERRAIN,
  UI,
  RARITY,
  TEXT,
  ALPHA,
} from './palette.js';

export {
  FONT_FAMILY,
  FONT_PRESETS,
  fontCss,
} from './typography.js';

export {
  LIB_ROOT,
  PROJECT_ROOT,
  ASSETS_DIR,
  PATHS as PATHS_MAP,
  assetPath,
} from './paths.js';

export default Object.freeze({
  ...dimensions,
  ...palette,
  ...typography,
  ...paths,
});
