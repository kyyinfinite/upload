# utils/

Reserved for misc utility helpers that don't fit elsewhere (e.g. layout
algorithms, color-space conversions, format converters). The current set
of utilities lives in `core/Helpers.js`.
