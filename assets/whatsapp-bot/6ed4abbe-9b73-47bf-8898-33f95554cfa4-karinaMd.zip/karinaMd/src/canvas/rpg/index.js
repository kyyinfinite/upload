/**
 * @file index.js
 * @description Public API for the RPG Canvas library. Everything the host
 *   WhatsApp bot needs is reachable from this single entrypoint:
 *
 *     import RPGCanvas from '@/src/canvas/rpg'
 *     const pngBuffer = await RPGCanvas.map(data)
 *
 * Adding a new renderer:
 *   1. Drop a new file in `generators/` exporting `render(data)`.
 *   2. Import it below and add a key on the `RPGCanvas` object.
 *
 * No core architecture changes are required.
 */

import { init as initAssets } from './core/AssetLoader.js';

// Generators.
import { render as renderMap } from './generators/AdventureMap.js';
import { render as renderInventory } from './generators/Inventory.js';
import { render as renderProfile } from './generators/Profile.js';
import { render as renderBattle } from './generators/Battle.js';
import { render as renderQuest } from './generators/Quest.js';
import { render as renderGuild } from './generators/Guild.js';
import { render as renderShop } from './generators/Marketplace.js';
import { render as renderLeaderboard } from './generators/Leaderboard.js';
import { render as renderDungeon } from './generators/DungeonMap.js';
import { render as renderDailyReward } from './generators/DailyReward.js';
import { render as renderAchievement } from './generators/Achievement.js';
import { render as renderComingSoon } from './generators/ComingSoon.js';

// Re-export internals for advanced consumers (testing / debugging).
import * as Constants from './constants/index.js';
import * as Core from './core/index.js';
import * as Components from './components/index.js';

/**
 * Initialize the library (loads fonts, primes caches). Idempotent.
 * Call this once at boot, or rely on the lazy init inside each renderer.
 *
 * @returns {Promise<void>}
 */
export async function init() {
  await initAssets();
}

/**
 * Public surface of the RPG Canvas SDK. Every property is an async renderer
 * that accepts a data payload and returns a PNG Buffer.
 *
 * @typedef {Object} RPGCanvasAPI
 * @property {typeof init} init
 * @property {(data:any) => Promise<Buffer>} map
 * @property {(data:any) => Promise<Buffer>} battle
 * @property {(data:any) => Promise<Buffer>} inventory
 * @property {(data:any) => Promise<Buffer>} profile
 * @property {(data:any) => Promise<Buffer>} guild
 * @property {(data:any) => Promise<Buffer>} shop
 * @property {(data:any) => Promise<Buffer>} leaderboard
 * @property {(data:any) => Promise<Buffer>} quest
 * @property {(data:any) => Promise<Buffer>} achievement
 * @property {(data:any) => Promise<Buffer>} dailyReward
 * @property {(data:any) => Promise<Buffer>} dungeon
 * @property {(data:any) => Promise<Buffer>} comingSoon
 * @property {typeof Constants} constants
 * @property {typeof Core} core
 * @property {typeof Components} components
 */

const RPGCanvas = Object.freeze({
  init,

  // Generators.
  map:          renderMap,
  battle:       renderBattle,
  inventory:    renderInventory,
  profile:      renderProfile,
  guild:        renderGuild,
  shop:         renderShop,
  leaderboard:  renderLeaderboard,
  quest:        renderQuest,
  achievement:  renderAchievement,
  dailyReward:  renderDailyReward,
  dungeon:      renderDungeon,
  comingSoon:   renderComingSoon,

  // Internals for advanced consumers.
  constants:  Constants,
  core:       Core,
  components: Components,
});

export default RPGCanvas;

// Named exports for tree-shakers who prefer them.
// NOTE: `init` is already exported via its `export async function` declaration.
export {
  renderMap,
  renderInventory,
  renderProfile,
  renderBattle,
  renderQuest,
  renderGuild,
  renderShop,
  renderLeaderboard,
  renderDungeon,
  renderDailyReward,
  renderAchievement,
  renderComingSoon,
  Constants,
  Core,
  Components,
};
