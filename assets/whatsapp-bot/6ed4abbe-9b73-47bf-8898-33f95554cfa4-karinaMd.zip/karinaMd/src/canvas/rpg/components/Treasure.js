/**
 * @file Treasure.js
 * @description Treasure chest drawing used by adventure maps and dungeon
 *   reward screens. Procedural — no external PNG required.
 */

import { UI, PAPER } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';
import { ALPHA } from '../constants/palette.js';

/**
 * Draw a treasure chest at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} w  Width of the chest.
 * @param {Object} [opts]
 * @param {boolean} [opts.open=true]   Whether the lid is open.
 * @param {boolean} [opts.glow=true]   Golden glow around open chests.
 * @param {number|string} [opts.seed='treasure']
 */
export function drawTreasure(ctx, cx, cy, w, opts = {}) {
  const open = opts.open ?? true;
  const glow = opts.glow ?? true;
  const seed = opts.seed ?? 'treasure';
  const rng = createRandom(seed);
  const h = w * 0.8;

  ctx.save();

  // Ground shadow.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow);
  ctx.beginPath();
  ctx.ellipse(cx, cy + h * 0.55, w * 0.55, h * 0.12, 0, 0, Math.PI * 2);
  ctx.fill();

  // Optional glow when open.
  if (open && glow) {
    const g = ctx.createRadialGradient(cx, cy - h * 0.2, 0, cx, cy - h * 0.2, w);
    g.addColorStop(0, withAlpha(UI.goldLight, 0.5));
    g.addColorStop(1, withAlpha(UI.goldLight, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy - h * 0.2, w, 0, Math.PI * 2);
    ctx.fill();
  }

  const x = cx - w / 2;
  const y = cy - h / 2;

  // Body.
  const bodyGrad = ctx.createLinearGradient(0, y, 0, y + h);
  bodyGrad.addColorStop(0, '#8a5a2a');
  bodyGrad.addColorStop(1, '#5a3818');
  ctx.fillStyle = bodyGrad;
  ctx.fillRect(x, y + h * 0.25, w, h * 0.6);

  // Metal bands.
  ctx.fillStyle = UI.goldDark;
  ctx.fillRect(x, y + h * 0.25, w, h * 0.08);
  ctx.fillRect(x, y + h * 0.75, w, h * 0.08);

  // Lid.
  ctx.save();
  if (open) {
    ctx.translate(x + w / 2, y + h * 0.25);
    ctx.rotate(-0.35);
    ctx.translate(-(x + w / 2), -(y + h * 0.25));
  }
  const lidGrad = ctx.createLinearGradient(0, y, 0, y + h * 0.3);
  lidGrad.addColorStop(0, shade('#8a5a2a', 0.15));
  lidGrad.addColorStop(1, '#6e4a26');
  ctx.fillStyle = lidGrad;
  ctx.beginPath();
  ctx.moveTo(x, y + h * 0.25);
  ctx.lineTo(x, y + h * 0.05);
  ctx.quadraticCurveTo(x + w / 2, y - h * 0.15, x + w, y + h * 0.05);
  ctx.lineTo(x + w, y + h * 0.25);
  ctx.closePath();
  ctx.fill();
  // Lid band.
  ctx.fillStyle = UI.goldDark;
  ctx.fillRect(x, y + h * 0.18, w, h * 0.07);
  ctx.restore();

  // Lock.
  ctx.fillStyle = UI.gold;
  ctx.beginPath();
  ctx.arc(cx, cy + h * 0.05, w * 0.08, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = PAPER.ink;
  ctx.fillRect(cx - w * 0.015, cy + h * 0.02, w * 0.03, h * 0.08);

  // Sparkles when open.
  if (open) {
    for (let i = 0; i < 6; i++) {
      const sx = cx + rng.range(-w * 0.3, w * 0.3);
      const sy = cy - h * 0.1 + rng.range(-h * 0.25, 0);
      const sr = rng.range(2, 5);
      ctx.fillStyle = withAlpha(UI.goldLight, rng.range(0.4, 0.9));
      ctx.beginPath();
      ctx.moveTo(sx, sy - sr);
      ctx.lineTo(sx + sr * 0.3, sy - sr * 0.3);
      ctx.lineTo(sx + sr, sy);
      ctx.lineTo(sx + sr * 0.3, sy + sr * 0.3);
      ctx.lineTo(sx, sy + sr);
      ctx.lineTo(sx - sr * 0.3, sy + sr * 0.3);
      ctx.lineTo(sx - sr, sy);
      ctx.lineTo(sx - sr * 0.3, sy - sr * 0.3);
      ctx.closePath();
      ctx.fill();
    }
  }

  ctx.restore();
}

export default { drawTreasure };
