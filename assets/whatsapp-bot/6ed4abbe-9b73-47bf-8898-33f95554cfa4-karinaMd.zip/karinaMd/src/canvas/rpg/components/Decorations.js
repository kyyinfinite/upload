/**
 * @file Decorations.js
 * @description Small decorative elements (rocks, bushes, flowers, crates,
 *   barrels, banners) used to enrich scenes without bloating any one
 *   generator. Each helper is self-contained and seedable.
 */

import { TERRAIN, UI, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a rock.
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} r
 * @param {Object} [opts] @param {number|string} [opts.seed]
 */
export function drawRock(ctx, x, y, r, opts = {}) {
  const rng = createRandom(opts.seed ?? `${x}:${y}`);
  ctx.save();
  // Shadow.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow * 0.7);
  ctx.beginPath();
  ctx.ellipse(x, y + r * 0.4, r * 1.1, r * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body.
  ctx.fillStyle = shade(TERRAIN.mountain.base, rng.range(-0.1, 0.1));
  ctx.beginPath();
  ctx.ellipse(x, y, r, r * 0.75, 0, 0, Math.PI * 2);
  ctx.fill();

  // Highlight.
  ctx.fillStyle = withAlpha('#ffffff', 0.15);
  ctx.beginPath();
  ctx.ellipse(x - r * 0.3, y - r * 0.3, r * 0.4, r * 0.25, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/**
 * Draw a small bush.
 */
export function drawBush(ctx, x, y, r, opts = {}) {
  const rng = createRandom(opts.seed ?? `bush:${x}:${y}`);
  ctx.save();
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow * 0.5);
  ctx.beginPath();
  ctx.ellipse(x, y + r * 0.4, r * 0.9, r * 0.2, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = shade(TERRAIN.forest.base, rng.range(-0.1, 0.1));
  for (let i = 0; i < 3; i++) {
    const ang = (i / 3) * Math.PI * 2;
    const bx = x + Math.cos(ang) * r * 0.4;
    const by = y + Math.sin(ang) * r * 0.2;
    ctx.beginPath();
    ctx.arc(bx, by, r * 0.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.beginPath();
  ctx.arc(x, y, r * 0.7, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/**
 * Draw scattered flowers.
 */
export function drawFlowers(ctx, x, y, w, h, opts = {}) {
  const count = opts.count ?? 6;
  const seed = opts.seed ?? 'flowers';
  const rng = createRandom(seed);
  const palette = [UI.blood, UI.gold, '#ffffff', UI.royal, '#ff8ac4'];
  ctx.save();
  for (let i = 0; i < count; i++) {
    const fx = x + rng.range(0, w);
    const fy = y + rng.range(0, h);
    const c = rng.pick(palette);
    // Stem.
    ctx.strokeStyle = TERRAIN.forest.dark;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(fx, fy);
    ctx.lineTo(fx, fy - 8);
    ctx.stroke();
    // Petals.
    ctx.fillStyle = c;
    for (let p = 0; p < 5; p++) {
      const a = (p / 5) * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(fx + Math.cos(a) * 2, fy - 8 + Math.sin(a) * 2, 2, 0, Math.PI * 2);
      ctx.fill();
    }
    // Center.
    ctx.fillStyle = UI.goldLight;
    ctx.beginPath();
    ctx.arc(fx, fy - 8, 1.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/**
 * Draw a wooden crate.
 */
export function drawCrate(ctx, x, y, size, opts = {}) {
  const rng = createRandom(opts.seed ?? `crate:${x}:${y}`);
  ctx.save();
  // Shadow.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow);
  ctx.beginPath();
  ctx.ellipse(x, y + size * 0.55, size * 0.55, size * 0.12, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body.
  const grad = ctx.createLinearGradient(x - size / 2, 0, x + size / 2, 0);
  grad.addColorStop(0, shade('#8a5a2a', -0.15));
  grad.addColorStop(0.5, '#8a5a2a');
  grad.addColorStop(1, shade('#8a5a2a', -0.25));
  ctx.fillStyle = grad;
  ctx.fillRect(x - size / 2, y - size / 2, size, size);

  // Plank lines.
  ctx.strokeStyle = withAlpha('#3a2410', 0.7);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x - size / 2, y - size / 6); ctx.lineTo(x + size / 2, y - size / 6);
  ctx.moveTo(x - size / 2, y + size / 6); ctx.lineTo(x + size / 2, y + size / 6);
  ctx.moveTo(x, y - size / 2); ctx.lineTo(x, y + size / 2);
  ctx.stroke();

  // Metal corners.
  ctx.fillStyle = UI.goldDark;
  for (const [cx, cy] of [[-1,-1],[1,-1],[-1,1],[1,1]]) {
    ctx.fillRect(x + cx * size * 0.4 - 3, y + cy * size * 0.4 - 3, 6, 6);
  }

  void rng;
  ctx.restore();
}

/**
 * Draw a barrel.
 */
export function drawBarrel(ctx, x, y, size, opts = {}) {
  ctx.save();
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow);
  ctx.beginPath();
  ctx.ellipse(x, y + size * 0.5, size * 0.45, size * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body (trapezoid).
  ctx.fillStyle = '#6e4a26';
  ctx.beginPath();
  ctx.moveTo(x - size * 0.35, y - size * 0.4);
  ctx.lineTo(x + size * 0.35, y - size * 0.4);
  ctx.lineTo(x + size * 0.4,  y + size * 0.4);
  ctx.lineTo(x - size * 0.4,  y + size * 0.4);
  ctx.closePath();
  ctx.fill();

  // Bands.
  ctx.fillStyle = UI.goldDark;
  ctx.fillRect(x - size * 0.4, y - size * 0.3, size * 0.8, size * 0.06);
  ctx.fillRect(x - size * 0.4, y + size * 0.2, size * 0.8, size * 0.06);

  // Top.
  ctx.fillStyle = '#5a3818';
  ctx.beginPath();
  ctx.ellipse(x, y - size * 0.4, size * 0.35, size * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/**
 * Draw a hanging banner.
 */
export function drawBanner(ctx, x, y, w, h, opts = {}) {
  const color = opts.color ?? UI.blood;
  const emblem = opts.emblem ?? null;
  ctx.save();
  // Pole.
  ctx.strokeStyle = '#3a2410';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(x, y - 10);
  ctx.lineTo(x, y + h + 20);
  ctx.stroke();
  // Cloth.
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x + 2, y);
  ctx.lineTo(x + w, y);
  ctx.lineTo(x + w, y + h - 10);
  ctx.lineTo(x + w / 2, y + h);
  ctx.lineTo(x + 2, y + h - 10);
  ctx.closePath();
  ctx.fill();
  // Outline.
  ctx.strokeStyle = withAlpha('#000000', 0.4);
  ctx.lineWidth = 1;
  ctx.stroke();
  // Emblem.
  if (emblem) {
    ctx.fillStyle = withAlpha('#ffffff', 0.9);
    ctx.font = `700 ${Math.round(w * 0.5)}px Cinzel, serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(emblem, x + w / 2, y + h / 2);
  }
  ctx.restore();
}

export default {
  drawRock,
  drawBush,
  drawFlowers,
  drawCrate,
  drawBarrel,
  drawBanner,
};
