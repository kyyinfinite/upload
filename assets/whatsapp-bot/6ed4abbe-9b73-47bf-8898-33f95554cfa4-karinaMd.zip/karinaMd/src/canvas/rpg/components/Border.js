/**
 * @file Border.js
 * @description Reusable decorative frame drawn around a canvas. Provides
 *   double-stroke gold border with corner ornaments, suitable for every
 *   renderer. No PNG asset required — fully procedural.
 */

import { UI, PAPER } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect } from '../core/Helpers.js';
import { BORDER_THICKNESS, SAFE_PADDING } from '../constants/dimensions.js';

/**
 * Draw the standard ornate border inside the safe-padding region.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w
 * @param {number} h
 * @param {Object} [opts]
 * @param {number} [opts.thickness=BORDER_THICKNESS]
 * @param {number} [opts.inset=SAFE_PADDING]
 * @param {string} [opts.color=UI.gold]
 * @param {string} [opts.shadowColor=PAPER.edge]
 */
export function drawBorder(ctx, w, h, opts = {}) {
  const thickness = opts.thickness ?? BORDER_THICKNESS;
  const inset = opts.inset ?? SAFE_PADDING;
  const color = opts.color ?? UI.gold;
  const shadowColor = opts.shadowColor ?? PAPER.edge;

  const x = inset;
  const y = inset;
  const fw = w - inset * 2;
  const fh = h - inset * 2;
  const r = thickness * 1.2;

  ctx.save();

  // Outer dark backing.
  ctx.fillStyle = withAlpha(shadowColor, 0.45);
  roundRect(ctx, x - 4, y - 4, fw + 8, fh + 8, r + 4);
  ctx.fill();

  // Gold base.
  ctx.fillStyle = color;
  roundRect(ctx, x, y, fw, fh, r);
  ctx.fill();

  // Inner highlight stroke.
  ctx.strokeStyle = shade(color, 0.35);
  ctx.lineWidth = 2;
  roundRect(ctx, x + 3, y + 3, fw - 6, fh - 6, r - 3);
  ctx.stroke();

  // Inner cutout to reveal content beneath.
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fillStyle = '#000';
  roundRect(ctx, x + thickness, y + thickness, fw - thickness * 2, fh - thickness * 2, Math.max(2, r - thickness));
  ctx.fill();
  ctx.globalCompositeOperation = 'source-over';

  // Corner ornaments (small diamonds).
  const corners = [
    [x + thickness * 0.6, y + thickness * 0.6],
    [x + fw - thickness * 0.6, y + thickness * 0.6],
    [x + thickness * 0.6, y + fh - thickness * 0.6],
    [x + fw - thickness * 0.6, y + fh - thickness * 0.6],
  ];
  for (const [cx, cy] of corners) {
    ctx.fillStyle = shade(color, 0.25);
    ctx.beginPath();
    ctx.moveTo(cx, cy - 6);
    ctx.lineTo(cx + 6, cy);
    ctx.lineTo(cx, cy + 6);
    ctx.lineTo(cx - 6, cy);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = shade(color, -0.2);
    ctx.beginPath();
    ctx.arc(cx, cy, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

export default { drawBorder };
