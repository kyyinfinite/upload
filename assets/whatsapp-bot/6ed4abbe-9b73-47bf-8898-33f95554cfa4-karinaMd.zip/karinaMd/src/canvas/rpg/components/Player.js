/**
 * @file Player.js
 * @description Procedural player token drawn on adventure maps and battle
 *   scenes. Parameterized by class (warrior / mage / rogue / ranger) so the
 *   silhouette, color, and weapon vary without external assets.
 */

import { UI, TEXT, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * @typedef {'warrior'|'mage'|'rogue'|'ranger'|'cleric'} PlayerClass
 */

const CLASS_COLORS = Object.freeze({
  warrior: UI.blood,
  mage:    UI.royal,
  rogue:   '#3a3a3a',
  ranger:  UI.emerald,
  cleric:  UI.gold,
});

/**
 * Draw a player token at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} radius
 * @param {Object} [opts]
 * @param {PlayerClass} [opts.cls='warrior']
 * @param {string} [opts.name] Optional name label below the token.
 * @param {number|string} [opts.seed='player']
 * @param {boolean} [opts.shadow=true] Whether to draw a ground shadow.
 */
export function drawPlayer(ctx, cx, cy, radius, opts = {}) {
  const cls = opts.cls ?? 'warrior';
  const name = opts.name;
  const seed = opts.seed ?? 'player';
  const showShadow = opts.shadow ?? true;
  const rng = createRandom(`${seed}:${cls}`);
  const color = CLASS_COLORS[cls] ?? UI.blood;

  ctx.save();

  // Ground shadow.
  if (showShadow) {
    ctx.fillStyle = withAlpha('#000000', ALPHA.shadow);
    ctx.beginPath();
    ctx.ellipse(cx, cy + radius * 0.95, radius * 0.9, radius * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Cape / robe base (semi-ellipse behind body).
  ctx.fillStyle = shade(color, -0.15);
  ctx.beginPath();
  ctx.ellipse(cx, cy + radius * 0.1, radius * 0.78, radius * 0.95, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body torso.
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(cx - radius * 0.45, cy + radius * 0.6);
  ctx.quadraticCurveTo(cx, cy - radius * 0.1, cx + radius * 0.45, cy + radius * 0.6);
  ctx.lineTo(cx + radius * 0.35, cy + radius * 0.85);
  ctx.lineTo(cx - radius * 0.35, cy + radius * 0.85);
  ctx.closePath();
  ctx.fill();

  // Head.
  ctx.fillStyle = '#e8c39a';
  ctx.beginPath();
  ctx.arc(cx, cy - radius * 0.25, radius * 0.32, 0, Math.PI * 2);
  ctx.fill();

  // Class-specific headgear.
  drawHeadgear(ctx, cx, cy, radius, cls, color);

  // Class-specific weapon.
  drawWeapon(ctx, cx, cy, radius, cls, color);

  // Subtle outline.
  ctx.strokeStyle = withAlpha('#000000', 0.4);
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Tiny emblem on the chest.
  ctx.fillStyle = withAlpha(UI.goldLight, 0.9);
  ctx.beginPath();
  ctx.arc(cx, cy + radius * 0.32, radius * 0.08, 0, Math.PI * 2);
  ctx.fill();

  // Name label.
  if (name) {
    ctx.font = `600 ${Math.round(radius * 0.4)}px Cinzel, serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const labelY = cy + radius * 1.1;
    const w = ctx.measureText(name).width + 24;
    ctx.fillStyle = withAlpha('#000000', 0.55);
    roundRectPath(ctx, cx - w / 2, labelY, w, radius * 0.55, 6);
    ctx.fill();
    ctx.fillStyle = TEXT.light;
    ctx.fillText(name, cx, labelY + radius * 0.08);
  }

  void rng;
  ctx.restore();
}

/**
 * Draw class-specific headgear.
 */
function drawHeadgear(ctx, cx, cy, r, cls, color) {
  ctx.save();
  ctx.fillStyle = shade(color, 0.1);
  switch (cls) {
    case 'warrior':
      // Helm with visor.
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.32, r * 0.36, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = withAlpha('#000000', 0.4);
      ctx.fillRect(cx - r * 0.3, cy - r * 0.32, r * 0.6, r * 0.08);
      break;
    case 'mage':
      // Pointy hat.
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.4, cy - r * 0.4);
      ctx.lineTo(cx, cy - r * 1.1);
      ctx.lineTo(cx + r * 0.4, cy - r * 0.4);
      ctx.closePath();
      ctx.fill();
      // Star.
      ctx.fillStyle = UI.goldLight;
      ctx.font = `${Math.round(r * 0.25)}px serif`;
      ctx.textAlign = 'center';
      ctx.fillText('✦', cx, cy - r * 0.7);
      break;
    case 'rogue':
      // Hood.
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.42, cy - r * 0.1);
      ctx.quadraticCurveTo(cx, cy - r * 0.75, cx + r * 0.42, cy - r * 0.1);
      ctx.lineTo(cx + r * 0.3, cy - r * 0.05);
      ctx.quadraticCurveTo(cx, cy - r * 0.45, cx - r * 0.3, cy - r * 0.05);
      ctx.closePath();
      ctx.fill();
      break;
    case 'ranger':
      // Hood with feather.
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.4, cy - r * 0.15);
      ctx.quadraticCurveTo(cx, cy - r * 0.7, cx + r * 0.4, cy - r * 0.15);
      ctx.lineTo(cx + r * 0.32, cy - r * 0.1);
      ctx.quadraticCurveTo(cx, cy - r * 0.4, cx - r * 0.32, cy - r * 0.1);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = shade(color, 0.4);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.25, cy - r * 0.5);
      ctx.lineTo(cx + r * 0.55, cy - r * 0.8);
      ctx.stroke();
      break;
    case 'cleric':
      // Halo.
      ctx.strokeStyle = withAlpha(UI.goldLight, 0.9);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.45, r * 0.38, 0, Math.PI * 2);
      ctx.stroke();
      break;
  }
  ctx.restore();
}

/**
 * Draw class-specific weapon beside the player.
 */
function drawWeapon(ctx, cx, cy, r, cls, color) {
  ctx.save();
  ctx.lineCap = 'round';
  switch (cls) {
    case 'warrior':
      // Sword.
      ctx.strokeStyle = '#c8c8d0';
      ctx.lineWidth = r * 0.08;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.55, cy + r * 0.7);
      ctx.lineTo(cx + r * 0.85, cy - r * 0.4);
      ctx.stroke();
      ctx.strokeStyle = shade(color, -0.2);
      ctx.lineWidth = r * 0.12;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.5, cy + r * 0.55);
      ctx.lineTo(cx + r * 0.65, cy + r * 0.7);
      ctx.stroke();
      break;
    case 'mage':
      // Staff with orb.
      ctx.strokeStyle = '#6e4a26';
      ctx.lineWidth = r * 0.08;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.55, cy + r * 0.85);
      ctx.lineTo(cx + r * 0.85, cy - r * 0.6);
      ctx.stroke();
      ctx.fillStyle = UI.royal;
      ctx.beginPath();
      ctx.arc(cx + r * 0.85, cy - r * 0.7, r * 0.14, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'rogue':
      // Twin daggers.
      ctx.strokeStyle = '#c8c8d0';
      ctx.lineWidth = r * 0.05;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.5, cy + r * 0.7);
      ctx.lineTo(cx + r * 0.7, cy + r * 0.2);
      ctx.moveTo(cx - r * 0.5, cy + r * 0.7);
      ctx.lineTo(cx - r * 0.7, cy + r * 0.2);
      ctx.stroke();
      break;
    case 'ranger':
      // Bow.
      ctx.strokeStyle = '#6e4a26';
      ctx.lineWidth = r * 0.06;
      ctx.beginPath();
      ctx.arc(cx + r * 0.7, cy + r * 0.2, r * 0.5, -Math.PI / 2.5, Math.PI / 2.5);
      ctx.stroke();
      ctx.strokeStyle = '#e8e8e8';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.5, cy - r * 0.3);
      ctx.lineTo(cx + r * 0.5, cy + r * 0.7);
      ctx.stroke();
      break;
    case 'cleric':
      // Mace.
      ctx.strokeStyle = '#6e4a26';
      ctx.lineWidth = r * 0.07;
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.55, cy + r * 0.85);
      ctx.lineTo(cx + r * 0.55, cy);
      ctx.stroke();
      ctx.fillStyle = UI.gold;
      ctx.beginPath();
      ctx.arc(cx + r * 0.55, cy - r * 0.1, r * 0.12, 0, Math.PI * 2);
      ctx.fill();
      break;
  }
  ctx.restore();
}

/** Local round-rect helper to avoid importing from Helpers (keeps file standalone). */
function roundRectPath(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + w, y,     r);
  ctx.closePath();
}

export default { drawPlayer };
