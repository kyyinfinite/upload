/**
 * @file Labels.js
 * @description Reusable text labels with backing chips. Used by every
 *   generator for stat blocks, item names, headers, etc. Centralizing
 *   these keeps typography consistent.
 */

import { UI, TEXT, PAPER } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { roundRect } from '../core/Helpers.js';

/**
 * Draw a labeled stat row: "Label: Value" with a colored chip for the value.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {number} h
 * @param {string} label
 * @param {string} value
 * @param {Object} [opts]
 * @param {string} [opts.accent=UI.gold]
 * @param {string} [opts.preset='body']
 */
export function drawStatRow(ctx, x, y, w, h, label, value, opts = {}) {
  const accent = opts.accent ?? UI.gold;
  const preset = opts.preset ?? 'body';
  ctx.save();

  // Background chip.
  ctx.fillStyle = withAlpha(PAPER.shadow, 0.25);
  roundRect(ctx, x, y, w, h, 6);
  ctx.fill();

  // Accent stripe on the left.
  ctx.fillStyle = accent;
  roundRect(ctx, x, y, 4, h, 2);
  ctx.fill();

  // Label.
  ctx.fillStyle = TEXT.secondary;
  ctx.font = fontCss(preset);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, x + 14, y + h / 2);

  // Value.
  ctx.fillStyle = TEXT.primary;
  ctx.font = fontCss('stat');
  ctx.textAlign = 'right';
  ctx.fillText(value, x + w - 14, y + h / 2);

  ctx.restore();
}

/**
 * Draw a section title with an underline rule.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {string} text
 * @param {Object} [opts]
 * @param {string} [opts.accent=UI.gold]
 */
export function drawSectionTitle(ctx, x, y, w, text, opts = {}) {
  const accent = opts.accent ?? UI.gold;
  ctx.save();
  ctx.fillStyle = TEXT.primary;
  ctx.font = fontCss('subSection');
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(text, x, y);

  // Underline.
  const tw = ctx.measureText(text).width;
  ctx.strokeStyle = accent;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x, y + 34);
  ctx.lineTo(x + Math.max(tw, 60), y + 34);
  ctx.stroke();

  // Faded extension across the rest of the row.
  ctx.strokeStyle = withAlpha(accent, 0.25);
  ctx.beginPath();
  ctx.moveTo(x + Math.max(tw, 60) + 12, y + 34);
  ctx.lineTo(x + w, y + 34);
  ctx.stroke();

  ctx.restore();
}

/**
 * Draw a chip badge (e.g. for rarity, level, class).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {string} text
 * @param {Object} [opts]
 * @param {string} [opts.color=UI.gold]
 * @param {string} [opts.textColor=TEXT.light]
 * @param {number} [opts.padding=8]
 */
export function drawBadge(ctx, x, y, text, opts = {}) {
  const color = opts.color ?? UI.gold;
  const textColor = opts.textColor ?? TEXT.light;
  const padding = opts.padding ?? 8;
  ctx.save();
  ctx.font = fontCss('badge');
  const w = ctx.measureText(text).width + padding * 2;
  const h = 22;

  ctx.fillStyle = shade(color, -0.15);
  roundRect(ctx, x, y, w, h, 6);
  ctx.fill();

  ctx.fillStyle = color;
  roundRect(ctx, x, y, w, h - 3, 6);
  ctx.fill();

  ctx.fillStyle = textColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x + w / 2, y + h / 2 - 1);

  ctx.restore();
}

/**
 * Draw a progress bar.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {number} h
 * @param {number} ratio       0..1
 * @param {Object} [opts]
 * @param {string} [opts.color=UI.emerald]
 * @param {string} [opts.bg=PAPER.shadow]
 * @param {string} [opts.label]
 */
export function drawProgressBar(ctx, x, y, w, h, ratio, opts = {}) {
  const color = opts.color ?? UI.emerald;
  const bg = opts.bg ?? PAPER.shadow;
  const label = opts.label ?? null;
  const clamped = Math.max(0, Math.min(1, ratio));
  ctx.save();

  ctx.fillStyle = withAlpha(bg, 0.5);
  roundRect(ctx, x, y, w, h, h / 2);
  ctx.fill();

  if (clamped > 0) {
    const grad = ctx.createLinearGradient(x, 0, x + w * clamped, 0);
    grad.addColorStop(0, shade(color, 0.15));
    grad.addColorStop(1, color);
    ctx.fillStyle = grad;
    roundRect(ctx, x, y, w * clamped, h, h / 2);
    ctx.fill();
  }

  if (label) {
    ctx.fillStyle = TEXT.light;
    ctx.font = fontCss('bodySmall');
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, x + w / 2, y + h / 2);
  }

  ctx.restore();
}

export default { drawStatRow, drawSectionTitle, drawBadge, drawProgressBar };
