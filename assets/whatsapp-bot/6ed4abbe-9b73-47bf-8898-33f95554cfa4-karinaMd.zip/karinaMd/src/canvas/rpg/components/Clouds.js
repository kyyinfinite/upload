/**
 * @file Clouds.js
 * @description Drifting cloud overlays for adventure maps. Soft, semi-
 *   transparent blobs that add atmospheric depth without obscuring terrain.
 */

import { withAlpha } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';
import { ALPHA } from '../constants/palette.js';

/**
 * Draw N soft clouds across the canvas.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w
 * @param {number} h
 * @param {Object} [opts]
 * @param {number} [opts.count=8]
 * @param {number} [opts.alpha=ALPHA.cloud]
 * @param {number|string} [opts.seed='clouds']
 * @param {string} [opts.color='#ffffff']
 */
export function drawClouds(ctx, w, h, opts = {}) {
  const count = opts.count ?? 8;
  const alpha = opts.alpha ?? ALPHA.cloud;
  const seed = opts.seed ?? 'clouds';
  const color = opts.color ?? '#ffffff';
  const rng = createRandom(seed);

  ctx.save();
  for (let i = 0; i < count; i++) {
    const cx = rng.range(-100, w + 100);
    const cy = rng.range(0, h * 0.6);
    const baseR = rng.range(60, 160);
    drawCloud(ctx, cx, cy, baseR, alpha, color, rng);
  }
  ctx.restore();
}

/**
 * Draw a single puffy cloud as several overlapping radial gradients.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} baseR
 * @param {number} alpha
 * @param {string} color
 * @param {ReturnType<typeof createRandom>} rng
 */
export function drawCloud(ctx, cx, cy, baseR, alpha, color, rng) {
  const puffs = 4 + Math.floor(rng.next() * 4);
  for (let i = 0; i < puffs; i++) {
    const x = cx + rng.range(-baseR, baseR);
    const y = cy + rng.range(-baseR * 0.25, baseR * 0.25);
    const r = baseR * rng.range(0.5, 1);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, withAlpha(color, alpha));
    g.addColorStop(1, withAlpha(color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
}

export default { drawClouds, drawCloud };
