/**
 * @file Header.js
 * @description Standard header banner used by every renderer. Renders a
 *   title with a decorative underline and optional subtitle / icon slot.
 */

import { PAPER, UI, TEXT } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha, shade } from '../core/Colors.js';
import { SAFE_PADDING, HEADER_HEIGHT } from '../constants/dimensions.js';
import { roundRect } from '../core/Helpers.js';

/**
 * Draw a standard header.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w Canvas width.
 * @param {Object} opts
 * @param {string} opts.title           Main heading text.
 * @param {string} [opts.subtitle]      Optional smaller subtitle.
 * @param {number} [opts.y=SAFE_PADDING] Top-left Y.
 * @param {number} [opts.height=HEADER_HEIGHT]
 * @param {string} [opts.accent=UI.gold]
 */
export function drawHeader(ctx, w, opts) {
  const { title, subtitle } = opts;
  const y = opts.y ?? SAFE_PADDING;
  const h = opts.height ?? HEADER_HEIGHT;
  const accent = opts.accent ?? UI.gold;
  const x = SAFE_PADDING;

  ctx.save();

  // Decorative ribbon backing.
  const grad = ctx.createLinearGradient(0, y, 0, y + h);
  grad.addColorStop(0, withAlpha(shade(accent, 0.15), 0.85));
  grad.addColorStop(1, withAlpha(shade(accent, -0.2), 0.85));
  ctx.fillStyle = grad;
  roundRect(ctx, x, y, w - SAFE_PADDING * 2, h, 12);
  ctx.fill();

  // Inset stroke.
  ctx.strokeStyle = withAlpha('#000000', 0.3);
  ctx.lineWidth = 2;
  roundRect(ctx, x + 3, y + 3, w - SAFE_PADDING * 2 - 6, h - 6, 9);
  ctx.stroke();

  // Title.
  ctx.fillStyle = TEXT.light;
  ctx.font = fontCss('section');
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const cx = x + (w - SAFE_PADDING * 2) / 2;
  const ty = subtitle ? y + h * 0.42 : y + h / 2;
  ctx.fillText(title, cx, ty);

  // Subtitle.
  if (subtitle) {
    ctx.fillStyle = withAlpha(TEXT.light, 0.85);
    ctx.font = fontCss('bodySmall');
    ctx.fillText(subtitle, cx, y + h * 0.75);
  }

  // Decorative flourishes on either side of the title.
  ctx.strokeStyle = withAlpha('#000000', 0.4);
  ctx.lineWidth = 2;
  for (const side of [-1, 1]) {
    const fx = cx + side * (ctx.measureText(title).width / 2 + 24);
    ctx.beginPath();
    ctx.moveTo(fx, y + h / 2);
    ctx.lineTo(fx + side * 18, y + h / 2);
    ctx.stroke();
    ctx.fillStyle = TEXT.light;
    ctx.beginPath();
    ctx.arc(fx + side * 18, y + h / 2, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

export default { drawHeader };
