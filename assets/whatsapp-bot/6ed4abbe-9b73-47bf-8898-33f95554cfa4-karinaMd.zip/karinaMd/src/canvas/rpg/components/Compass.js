/**
 * @file Compass.js
 * @description Decorative compass rose drawn procedurally in the corner of
 *   adventure maps. No external asset.
 */

import { UI, PAPER } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a compass rose.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx Center X.
 * @param {number} cy Center Y.
 * @param {number} radius Outer radius.
 * @param {Object} [opts]
 * @param {number|string} [opts.seed='compass']
 */
export function drawCompass(ctx, cx, cy, radius, opts = {}) {
  const seed = opts.seed ?? 'compass';
  const rng = createRandom(seed);
  ctx.save();
  ctx.translate(cx, cy);

  // Outer ring.
  ctx.strokeStyle = withAlpha(PAPER.ink, 0.7);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.78, 0, Math.PI * 2);
  ctx.stroke();

  // Tick marks.
  for (let i = 0; i < 32; i++) {
    const a = (i / 32) * Math.PI * 2;
    const long = i % 4 === 0;
    const r1 = radius;
    const r2 = radius - (long ? 12 : 6);
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * r1, Math.sin(a) * r1);
    ctx.lineTo(Math.cos(a) * r2, Math.sin(a) * r2);
    ctx.strokeStyle = withAlpha(PAPER.ink, long ? 0.85 : 0.4);
    ctx.lineWidth = long ? 2 : 1;
    ctx.stroke();
  }

  // Cardinal points + 4 cardinal star spikes.
  const points = ['N', 'E', 'S', 'W'];
  const colors = [UI.blood, UI.gold, UI.gold, UI.gold];
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 - Math.PI / 2;
    drawSpike(ctx, 0, 0, a, radius * 0.72, radius * 0.18, colors[i]);
  }

  // Intercardinal smaller spikes.
  for (let i = 0; i < 4; i++) {
    const a = ((i + 0.5) / 2) * Math.PI - Math.PI / 2;
    drawSpike(ctx, 0, 0, a, radius * 0.42, radius * 0.1, shade(UI.gold, -0.15));
  }

  // Center boss.
  ctx.fillStyle = UI.goldDark;
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = shade(UI.gold, 0.3);
  ctx.beginPath();
  ctx.arc(-radius * 0.02, -radius * 0.02, radius * 0.06, 0, Math.PI * 2);
  ctx.fill();

  // Cardinal letters.
  ctx.font = `700 ${Math.round(radius * 0.22)}px Cinzel, serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = PAPER.ink;
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 - Math.PI / 2;
    const rr = radius * 0.9;
    ctx.fillText(points[i], Math.cos(a) * rr, Math.sin(a) * rr);
  }

  // Subtle jitter to give it a hand-drawn feel.
  void rng;

  ctx.restore();
}

/**
 * Draw a single rhombus-shaped compass spike.
 */
function drawSpike(ctx, ox, oy, angle, length, width, color) {
  ctx.save();
  ctx.translate(ox, oy);
  ctx.rotate(angle);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(width, -length);
  ctx.lineTo(0, -length * 0.7);
  ctx.lineTo(-width, -length);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = withAlpha('#000000', 0.4);
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.restore();
}

export default { drawCompass };
