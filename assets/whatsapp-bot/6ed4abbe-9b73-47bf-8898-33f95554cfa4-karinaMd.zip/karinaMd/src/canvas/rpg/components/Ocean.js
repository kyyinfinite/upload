/**
 * @file Ocean.js
 * @description Tileable ocean renderer. Draws a base gradient + animated
 *   wave streaks. Used as the AdventureMap water region.
 */

import { TERRAIN } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Fill the entire canvas region with ocean and overlay wave streaks.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {number} h
 * @param {Object} [opts]
 * @param {number|string} [opts.seed='ocean']
 * @param {number} [opts.waves=120]
 */
export function drawOcean(ctx, x, y, w, h, opts = {}) {
  const seed = opts.seed ?? 'ocean';
  const waves = opts.waves ?? 120;
  const rng = createRandom(seed);

  ctx.save();

  // Vertical gradient.
  const grad = ctx.createLinearGradient(0, y, 0, y + h);
  grad.addColorStop(0, TERRAIN.ocean.light);
  grad.addColorStop(0.5, TERRAIN.ocean.base);
  grad.addColorStop(1, TERRAIN.ocean.dark);
  ctx.fillStyle = grad;
  ctx.fillRect(x, y, w, h);

  // Wave streaks.
  ctx.strokeStyle = withAlpha('#ffffff', 0.25);
  ctx.lineCap = 'round';
  for (let i = 0; i < waves; i++) {
    const wx = x + rng.range(0, w);
    const wy = y + rng.range(0, h);
    const len = rng.range(20, 80);
    const ang = rng.range(-0.2, 0.2);
    ctx.lineWidth = rng.range(0.5, 2);
    ctx.beginPath();
    ctx.moveTo(wx, wy);
    ctx.lineTo(wx + Math.cos(ang) * len, wy + Math.sin(ang) * len);
    ctx.stroke();
  }

  // Foam at top.
  ctx.fillStyle = withAlpha('#ffffff', 0.15);
  for (let i = 0; i < 30; i++) {
    const fx = x + rng.range(0, w);
    const fy = y + rng.range(0, h * 0.1);
    const fr = rng.range(4, 12);
    ctx.beginPath();
    ctx.arc(fx, fy, fr, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle deeper ripple shade at bottom.
  ctx.fillStyle = withAlpha(shade(TERRAIN.ocean.dark, -0.2), 0.3);
  ctx.fillRect(x, y + h * 0.8, w, h * 0.2);

  ctx.restore();
}

export default { drawOcean };
