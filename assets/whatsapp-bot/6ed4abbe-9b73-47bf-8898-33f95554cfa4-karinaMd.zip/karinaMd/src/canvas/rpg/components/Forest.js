/**
 * @file Forest.js
 * @description Tree cluster used as adventure-map terrain decoration.
 *   Procedurally placed coniferous + deciduous trees from a seeded RNG.
 */

import { TERRAIN, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a forest cluster centered at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} w Bounding width.
 * @param {Object} [opts]
 * @param {number} [opts.trees=8]
 * @param {number|string} [opts.seed='forest']
 */
export function drawForest(ctx, cx, cy, w, opts = {}) {
  const trees = opts.trees ?? 8;
  const seed = opts.seed ?? 'forest';
  const rng = createRandom(seed);

  ctx.save();

  // Soft ground shadow.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow * 0.5);
  ctx.beginPath();
  ctx.ellipse(cx, cy + w * 0.18, w * 0.55, w * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();

  // Trees, sorted back-to-front by Y for proper overlap.
  const positions = [];
  for (let i = 0; i < trees; i++) {
    positions.push({
      x: cx + rng.range(-w * 0.4, w * 0.4),
      y: cy + rng.range(-w * 0.1, w * 0.15),
      size: w * rng.range(0.18, 0.28),
      conifer: rng.next() > 0.4,
      shade: rng.range(-0.1, 0.1),
    });
  }
  positions.sort((a, b) => a.y - b.y);

  for (const p of positions) {
    if (p.conifer) drawConifer(ctx, p.x, p.y, p.size, p.shade);
    else drawDeciduous(ctx, p.x, p.y, p.size, p.shade);
  }

  ctx.restore();
}

/**
 * Draw a coniferous tree (pine).
 */
function drawConifer(ctx, x, y, size, shadeAmt) {
  ctx.save();
  // Trunk.
  ctx.fillStyle = '#3a2410';
  ctx.fillRect(x - size * 0.06, y, size * 0.12, size * 0.2);

  // Three stacked triangles.
  ctx.fillStyle = shade(TERRAIN.forest.base, shadeAmt);
  for (let i = 0; i < 3; i++) {
    const ty = y - i * size * 0.3;
    const ts = size * (0.5 - i * 0.12);
    ctx.beginPath();
    ctx.moveTo(x, ty - size * 0.55);
    ctx.lineTo(x - ts, ty);
    ctx.lineTo(x + ts, ty);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

/**
 * Draw a deciduous tree (round canopy).
 */
function drawDeciduous(ctx, x, y, size, shadeAmt) {
  ctx.save();
  // Trunk.
  ctx.fillStyle = '#3a2410';
  ctx.fillRect(x - size * 0.07, y, size * 0.14, size * 0.3);

  // Canopy: cluster of circles.
  const base = shade(TERRAIN.forest.light, shadeAmt);
  ctx.fillStyle = base;
  for (let i = 0; i < 4; i++) {
    const ang = (i / 4) * Math.PI * 2;
    const cx = x + Math.cos(ang) * size * 0.2;
    const cy = y - size * 0.3 + Math.sin(ang) * size * 0.18;
    ctx.beginPath();
    ctx.arc(cx, cy, size * 0.28, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = base;
  ctx.beginPath();
  ctx.arc(x, y - size * 0.35, size * 0.32, 0, Math.PI * 2);
  ctx.fill();

  // Highlight.
  ctx.fillStyle = withAlpha('#ffffff', 0.18);
  ctx.beginPath();
  ctx.arc(x - size * 0.12, y - size * 0.45, size * 0.12, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export default { drawForest };
