/**
 * @file Effects.js
 * @description Post-processing effects: vignette, glow, sparkles, screen
 *   tint, and "noise overlay". These run AFTER all other layers in the
 *   standard renderer pipeline.
 */

import { ALPHA, UI } from '../constants/palette.js';
import { withAlpha } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';
import { noiseTexture } from '../core/TextureCache.js';

/**
 * Apply a radial vignette.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w
 * @param {number} h
 * @param {Object} [opts]
 * @param {number} [opts.strength=ALPHA.vignette]
 * @param {string} [opts.color='#000000']
 */
export function drawVignette(ctx, w, h, opts = {}) {
  const strength = opts.strength ?? ALPHA.vignette;
  const color = opts.color ?? '#000000';
  const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.75);
  g.addColorStop(0, withAlpha(color, 0));
  g.addColorStop(1, withAlpha(color, strength));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

/**
 * Apply a full-canvas color tint (e.g. night overlay).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w
 * @param {number} h
 * @param {string} color
 * @param {number} alpha
 */
export function drawTint(ctx, w, h, color, alpha) {
  ctx.fillStyle = withAlpha(color, alpha);
  ctx.fillRect(0, 0, w, h);
}

/**
 * Scatter sparkle particles inside a rectangle.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {number} h
 * @param {Object} [opts]
 * @param {number} [opts.count=20]
 * @param {string} [opts.color=UI.goldLight]
 * @param {number|string} [opts.seed='sparkles']
 */
export function drawSparkles(ctx, x, y, w, h, opts = {}) {
  const count = opts.count ?? 20;
  const color = opts.color ?? UI.goldLight;
  const seed = opts.seed ?? 'sparkles';
  const rng = createRandom(seed);
  ctx.save();
  for (let i = 0; i < count; i++) {
    const px = x + rng.range(0, w);
    const py = y + rng.range(0, h);
    const r = rng.range(1.5, 4);
    const a = rng.range(0.3, 0.9);
    ctx.fillStyle = withAlpha(color, a);
    ctx.beginPath();
    ctx.moveTo(px, py - r);
    ctx.lineTo(px + r * 0.3, py - r * 0.3);
    ctx.lineTo(px + r, py);
    ctx.lineTo(px + r * 0.3, py + r * 0.3);
    ctx.lineTo(px, py + r);
    ctx.lineTo(px - r * 0.3, py + r * 0.3);
    ctx.lineTo(px - r, py);
    ctx.lineTo(px - r * 0.3, py - r * 0.3);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

/**
 * Add a soft radial glow around a point.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} radius
 * @param {string} [color=UI.goldLight]
 * @param {number} [strength=0.6]
 */
export function drawGlow(ctx, cx, cy, radius, color = UI.goldLight, strength = 0.6) {
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
  g.addColorStop(0, withAlpha(color, strength));
  g.addColorStop(1, withAlpha(color, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * Overlay a faint film-grain noise across the whole canvas.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w
 * @param {number} h
 * @param {number|string} [seed='grain']
 * @param {number} [alpha=0.06]
 */
export function drawGrain(ctx, w, h, seed = 'grain', alpha = 0.06) {
  const tex = noiseTexture(seed, '#000000');
  ctx.save();
  ctx.globalAlpha = alpha;
  const pattern = ctx.createPattern(tex, 'repeat');
  ctx.fillStyle = pattern;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

export default {
  drawVignette,
  drawTint,
  drawSparkles,
  drawGlow,
  drawGrain,
};
