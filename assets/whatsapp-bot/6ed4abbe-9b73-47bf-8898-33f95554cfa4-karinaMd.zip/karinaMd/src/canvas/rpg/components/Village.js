/**
 * @file Village.js
 * @description Cluster of small houses used as adventure-map area markers
 *   and quest destinations. Procedural, fully deterministic by seed.
 */

import { TERRAIN, UI, PAPER, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a small village cluster centered at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} w Bounding width.
 * @param {Object} [opts]
 * @param {number} [opts.houses=4]  Number of houses.
 * @param {number|string} [opts.seed='village']
 */
export function drawVillage(ctx, cx, cy, w, opts = {}) {
  const houses = opts.houses ?? 4;
  const seed = opts.seed ?? 'village';
  const rng = createRandom(seed);

  ctx.save();

  // Ground patch.
  ctx.fillStyle = withAlpha(TERRAIN.grass.base, 0.8);
  ctx.beginPath();
  ctx.ellipse(cx, cy + w * 0.18, w * 0.6, w * 0.18, 0, 0, Math.PI * 2);
  ctx.fill();

  // Ground shadow ring.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow * 0.5);
  ctx.beginPath();
  ctx.ellipse(cx, cy + w * 0.22, w * 0.55, w * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();

  // Houses around the center.
  const houseSize = w * 0.18;
  for (let i = 0; i < houses; i++) {
    const a = (i / houses) * Math.PI * 2 + rng.range(-0.2, 0.2);
    const r = w * 0.25;
    const hx = cx + Math.cos(a) * r;
    const hy = cy + Math.sin(a) * r * 0.55;
    drawHouse(ctx, hx, hy, houseSize, rng);
  }

  // Central well / banner.
  drawWell(ctx, cx, cy - w * 0.02, w * 0.1);

  ctx.restore();
}

/**
 * Draw a single house.
 */
function drawHouse(ctx, cx, cy, size, rng) {
  ctx.save();
  // Wall.
  ctx.fillStyle = shade('#d8c39a', rng.range(-0.15, 0.15));
  ctx.fillRect(cx - size / 2, cy - size / 2, size, size);

  // Roof.
  ctx.fillStyle = shade(UI.blood, rng.range(-0.2, 0.1));
  ctx.beginPath();
  ctx.moveTo(cx - size * 0.6, cy - size / 2);
  ctx.lineTo(cx, cy - size);
  ctx.lineTo(cx + size * 0.6, cy - size / 2);
  ctx.closePath();
  ctx.fill();

  // Door.
  ctx.fillStyle = '#3a2410';
  ctx.fillRect(cx - size * 0.15, cy + size * 0.05, size * 0.3, size * 0.45);

  // Windows.
  ctx.fillStyle = withAlpha('#ffd060', 0.85);
  ctx.fillRect(cx - size * 0.4, cy - size * 0.25, size * 0.18, size * 0.18);
  ctx.fillRect(cx + size * 0.22, cy - size * 0.25, size * 0.18, size * 0.18);

  ctx.restore();
}

/**
 * Draw a small central well.
 */
function drawWell(ctx, cx, cy, r) {
  ctx.save();
  // Base.
  ctx.fillStyle = '#7a6238';
  ctx.beginPath();
  ctx.ellipse(cx, cy, r, r * 0.4, 0, 0, Math.PI * 2);
  ctx.fill();
  // Water.
  ctx.fillStyle = TERRAIN.river.base;
  ctx.beginPath();
  ctx.ellipse(cx, cy, r * 0.6, r * 0.25, 0, 0, Math.PI * 2);
  ctx.fill();
  // Posts.
  ctx.fillStyle = '#3a2410';
  ctx.fillRect(cx - r * 1.1, cy - r * 1.6, r * 0.18, r * 1.6);
  ctx.fillRect(cx + r * 0.92, cy - r * 1.6, r * 0.18, r * 1.6);
  // Roof.
  ctx.fillStyle = UI.blood;
  ctx.beginPath();
  ctx.moveTo(cx - r * 1.4, cy - r * 1.5);
  ctx.lineTo(cx, cy - r * 2.1);
  ctx.lineTo(cx + r * 1.4, cy - r * 1.5);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export default { drawVillage };
