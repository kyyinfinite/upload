/**
 * @file Roads.js
 * @description Road / path renderer. Draws a dashed, slightly textured
 *   stroke between two points, with optional fork into a third point.
 */

import { TERRAIN } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a road between two points.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 * @param {Object} [opts]
 * @param {number} [opts.width=12]
 * @param {number} [opts.dash=0.6]  0 = solid, 1 = dashed.
 * @param {number|string} [opts.seed='road']
 */
export function drawRoad(ctx, x1, y1, x2, y2, opts = {}) {
  const width = opts.width ?? 12;
  const dash = opts.dash ?? 0.6;
  const seed = opts.seed ?? 'road';
  const rng = createRandom(seed);

  ctx.save();

  // Dark outline.
  ctx.strokeStyle = shade(TERRAIN.road.dark, -0.1);
  ctx.lineWidth = width + 3;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // Main surface.
  ctx.strokeStyle = TERRAIN.road.base;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  // Highlight (center stripe).
  if (dash > 0) {
    ctx.strokeStyle = withAlpha(TERRAIN.road.light, 0.7);
    ctx.lineWidth = width * 0.3;
    ctx.setLineDash([width * 1.5, width * 2 * dash]);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Scattered pebbles.
  const len = Math.hypot(x2 - x1, y2 - y1);
  const ang = Math.atan2(y2 - y1, x2 - x1);
  const perpX = -Math.sin(ang);
  const perpY = Math.cos(ang);
  const pebbles = Math.floor(len / 20);
  for (let i = 0; i < pebbles; i++) {
    const t = (i + 0.5) / pebbles;
    const px = x1 + (x2 - x1) * t + perpX * rng.range(-width * 0.6, width * 0.6);
    const py = y1 + (y2 - y1) * t + perpY * rng.range(-width * 0.6, width * 0.6);
    ctx.fillStyle = withAlpha('#000000', rng.range(0.1, 0.25));
    ctx.beginPath();
    ctx.arc(px, py, rng.range(0.6, 1.6), 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

export default { drawRoad };
