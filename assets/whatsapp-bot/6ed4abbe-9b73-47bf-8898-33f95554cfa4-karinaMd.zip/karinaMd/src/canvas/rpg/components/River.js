/**
 * @file River.js
 * @description Winding river drawn as a thick quadratic bezier stroke with
 *   a lighter inner highlight to suggest depth and current.
 */

import { TERRAIN } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a river from (x1,y1) to (x2,y2) with a mid-control point.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 * @param {Object} [opts]
 * @param {number} [opts.width=24]
 * @param {number} [opts.curvature=0.3]  -1..1 horizontal bend factor.
 * @param {number|string} [opts.seed='river']
 */
export function drawRiver(ctx, x1, y1, x2, y2, opts = {}) {
  const width = opts.width ?? 24;
  const curvature = opts.curvature ?? 0.3;
  const seed = opts.seed ?? 'river';
  const rng = createRandom(seed);

  // Control point: perpendicular midpoint offset.
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  const nx = -dy / len;
  const ny = dx / len;
  const bend = len * curvature * (rng.next() > 0.5 ? 1 : -1);
  const cx = mx + nx * bend;
  const cy = my + ny * bend;

  ctx.save();

  // Outer (dark) bank stroke.
  ctx.strokeStyle = shade(TERRAIN.river.dark, -0.1);
  ctx.lineWidth = width + 4;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(cx, cy, x2, y2);
  ctx.stroke();

  // Main water.
  ctx.strokeStyle = TERRAIN.river.base;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(cx, cy, x2, y2);
  ctx.stroke();

  // Inner highlight.
  ctx.strokeStyle = withAlpha(TERRAIN.river.light, 0.7);
  ctx.lineWidth = width * 0.35;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(cx, cy, x2, y2);
  ctx.stroke();

  // Tiny ripples.
  ctx.strokeStyle = withAlpha('#ffffff', 0.5);
  ctx.lineWidth = 1.5;
  const steps = 6;
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const px = (1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * cx + t * t * x2;
    const py = (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * cy + t * t * y2;
    const ang = Math.atan2(dy, dx);
    ctx.beginPath();
    ctx.moveTo(px - Math.cos(ang) * 4, py - Math.sin(ang) * 4);
    ctx.lineTo(px + Math.cos(ang) * 4, py + Math.sin(ang) * 4);
    ctx.stroke();
  }

  ctx.restore();
}

export default { drawRiver };
