/**
 * @file AreaNode.js
 * @description Interactive area node for adventure maps. Renders a glowing
 *   pin with an icon, level badge, and label. Used for towns, dungeons,
 *   quests, etc.
 */

import { UI, TEXT, RARITY, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * @typedef {'town'|'dungeon'|'quest'|'boss'|'resource'|'shrine'} AreaType
 */

const AREA_COLORS = Object.freeze({
  town:     UI.emerald,
  dungeon:  UI.blood,
  quest:    UI.gold,
  boss:     '#a00000',
  resource: UI.sapphire,
  shrine:   UI.royal,
});

/**
 * Draw an area node at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {Object} opts
 * @param {AreaType} [opts.type='town']
 * @param {string}   [opts.label]
 * @param {number}   [opts.level]
 * @param {string}   [opts.icon]   Short glyph (emoji or letter).
 * @param {string}   [opts.rarity] Key of RARITY; tints the ring.
 * @param {number|string} [opts.seed]
 */
export function drawAreaNode(ctx, cx, cy, opts = {}) {
  const type = opts.type ?? 'town';
  const label = opts.label ?? '';
  const level = opts.level ?? null;
  const icon = opts.icon ?? '';
  const rarity = opts.rarity ? RARITY[opts.rarity] : null;
  const seed = opts.seed ?? `node:${cx}:${cy}`;
  const color = AREA_COLORS[type] ?? UI.gold;
  const rng = createRandom(seed);

  const r = 22;
  ctx.save();

  // Outer glow.
  const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 3);
  glow.addColorStop(0, withAlpha(color, 0.5));
  glow.addColorStop(1, withAlpha(color, 0));
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 3, 0, Math.PI * 2);
  ctx.fill();

  // Pin shadow.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow);
  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.9, r * 0.9, r * 0.25, 0, 0, Math.PI * 2);
  ctx.fill();

  // Pin body (circle).
  ctx.fillStyle = shade(color, -0.1);
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  // Inner disc.
  ctx.fillStyle = shade(color, 0.15);
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.78, 0, Math.PI * 2);
  ctx.fill();

  // Rarity ring.
  if (rarity) {
    ctx.strokeStyle = rarity;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy, r + 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Icon.
  if (icon) {
    ctx.fillStyle = TEXT.light;
    ctx.font = `700 ${Math.round(r * 1.1)}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, cx, cy + 1);
  }

  // Level badge.
  if (level != null) {
    const bx = cx + r * 0.85;
    const by = cy - r * 0.85;
    ctx.fillStyle = UI.goldDark;
    ctx.beginPath();
    ctx.arc(bx, by, r * 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = TEXT.light;
    ctx.font = `700 ${Math.round(r * 0.6)}px Sarasa Mono SC, monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(level), bx, by + 1);
  }

  // Label below the pin.
  if (label) {
    ctx.font = `600 16px Cinzel, serif`;
    const w = ctx.measureText(label).width + 16;
    ctx.fillStyle = withAlpha('#000000', 0.6);
    roundRectLocal(ctx, cx - w / 2, cy + r + 6, w, 22, 6);
    ctx.fill();
    ctx.fillStyle = TEXT.light;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, cx, cy + r + 17);
  }

  void rng;
  ctx.restore();
}

function roundRectLocal(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + w, y,     r);
  ctx.closePath();
}

export default { drawAreaNode };
