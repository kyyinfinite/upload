/**
 * @file Footer.js
 * @description Standard footer with branding / signature line. Used by
 *   every renderer to keep visual consistency at the bottom of the canvas.
 */

import { TEXT, UI } from '../constants/palette.js';
import { fontCss } from '../constants/typography.js';
import { withAlpha } from '../core/Colors.js';
import { SAFE_PADDING, FOOTER_HEIGHT } from '../constants/dimensions.js';

/**
 * Draw a standard footer.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w Canvas width.
 * @param {number} h Canvas height.
 * @param {Object} [opts]
 * @param {string} [opts.left]  Left-side text (e.g. version / shard name).
 * @param {string} [opts.right] Right-side text (e.g. timestamp).
 * @param {string} [opts.center] Center text (e.g. attribution).
 * @param {number} [opts.height=FOOTER_HEIGHT]
 */
export function drawFooter(ctx, w, h, opts = {}) {
  const left = opts.left ?? '';
  const right = opts.right ?? '';
  const center = opts.center ?? '';
  const height = opts.height ?? FOOTER_HEIGHT;
  const y = h - SAFE_PADDING - height;

  ctx.save();

  // Thin separator line.
  ctx.strokeStyle = withAlpha(UI.gold, 0.5);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(SAFE_PADDING, y);
  ctx.lineTo(w - SAFE_PADDING, y);
  ctx.stroke();

  // Text rows.
  ctx.fillStyle = withAlpha(TEXT.muted, 0.85);
  ctx.font = fontCss('footer');
  ctx.textBaseline = 'middle';

  const midY = y + height / 2;
  if (left) {
    ctx.textAlign = 'left';
    ctx.fillText(left, SAFE_PADDING, midY);
  }
  if (right) {
    ctx.textAlign = 'right';
    ctx.fillText(right, w - SAFE_PADDING, midY);
  }
  if (center) {
    ctx.textAlign = 'center';
    ctx.fillStyle = withAlpha(UI.gold, 0.9);
    ctx.fillText(center, w / 2, midY);
  }

  ctx.restore();
}

export default { drawFooter };
