/**
 * @file Dungeon.js
 * @description Stylized dungeon entrance: dark cave mouth with stone arch
 *   and torches. Used by adventure map area markers and dungeon screens.
 */

import { TERRAIN, UI, PAPER, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a dungeon entrance at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} w Width of the entrance.
 * @param {Object} [opts]
 * @param {number|string} [opts.seed='dungeon']
 */
export function drawDungeon(ctx, cx, cy, w, opts = {}) {
  const seed = opts.seed ?? 'dungeon';
  const rng = createRandom(seed);
  const h = w * 1.1;

  ctx.save();

  // Mountain backdrop.
  ctx.fillStyle = shade(TERRAIN.mountain.base, -0.05);
  ctx.beginPath();
  ctx.moveTo(cx - w * 1.1, cy + h * 0.5);
  ctx.lineTo(cx - w * 0.5, cy - h * 0.4);
  ctx.lineTo(cx, cy - h * 0.55);
  ctx.lineTo(cx + w * 0.5, cy - h * 0.4);
  ctx.lineTo(cx + w * 1.1, cy + h * 0.5);
  ctx.closePath();
  ctx.fill();

  // Mountain shading.
  ctx.fillStyle = withAlpha('#000000', 0.2);
  ctx.beginPath();
  ctx.moveTo(cx, cy - h * 0.55);
  ctx.lineTo(cx + w * 0.5, cy - h * 0.4);
  ctx.lineTo(cx + w * 1.1, cy + h * 0.5);
  ctx.lineTo(cx, cy + h * 0.5);
  ctx.closePath();
  ctx.fill();

  // Stone arch.
  ctx.fillStyle = shade(TERRAIN.mountain.base, 0.1);
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.45, cy + h * 0.5);
  ctx.lineTo(cx - w * 0.45, cy);
  ctx.quadraticCurveTo(cx, cy - h * 0.55, cx + w * 0.45, cy);
  ctx.lineTo(cx + w * 0.45, cy + h * 0.5);
  ctx.closePath();
  ctx.fill();

  // Dark cave mouth.
  const caveGrad = ctx.createRadialGradient(cx, cy + h * 0.2, 0, cx, cy + h * 0.2, w * 0.5);
  caveGrad.addColorStop(0, '#000000');
  caveGrad.addColorStop(1, withAlpha('#000000', 0.6));
  ctx.fillStyle = caveGrad;
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.3, cy + h * 0.5);
  ctx.lineTo(cx - w * 0.3, cy + h * 0.05);
  ctx.quadraticCurveTo(cx, cy - h * 0.35, cx + w * 0.3, cy + h * 0.05);
  ctx.lineTo(cx + w * 0.3, cy + h * 0.5);
  ctx.closePath();
  ctx.fill();

  // Torches.
  for (const side of [-1, 1]) {
    const tx = cx + side * w * 0.4;
    const ty = cy + h * 0.1;
    drawTorch(ctx, tx, ty, w * 0.06, rng);
  }

  // Ground line.
  ctx.strokeStyle = withAlpha(PAPER.ink, 0.4);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx - w * 1.1, cy + h * 0.5);
  ctx.lineTo(cx + w * 1.1, cy + h * 0.5);
  ctx.stroke();

  ctx.restore();
}

/**
 * Draw a single flickering torch.
 */
function drawTorch(ctx, x, y, size, rng) {
  ctx.save();
  // Stick.
  ctx.strokeStyle = '#3a2410';
  ctx.lineWidth = size * 0.6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x, y + size * 4);
  ctx.stroke();

  // Flame.
  const fl = ctx.createRadialGradient(x, y - size * 0.5, 0, x, y - size * 0.5, size * 2.5);
  fl.addColorStop(0, withAlpha('#ffe080', 0.95));
  fl.addColorStop(0.5, withAlpha(UI.blood, ALPHA.highlight + 0.4));
  fl.addColorStop(1, withAlpha(UI.blood, 0));
  ctx.fillStyle = fl;
  ctx.beginPath();
  ctx.ellipse(x, y - size * 0.6, size * 1.4, size * 2.4, 0, 0, Math.PI * 2);
  ctx.fill();

  // Tiny ember.
  ctx.fillStyle = withAlpha('#ffd060', 0.9);
  ctx.beginPath();
  ctx.arc(x + rng.range(-2, 2), y - size * 0.4, size * 0.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

export default { drawDungeon };
