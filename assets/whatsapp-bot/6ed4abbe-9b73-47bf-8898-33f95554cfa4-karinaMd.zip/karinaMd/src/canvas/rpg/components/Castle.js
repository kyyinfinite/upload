/**
 * @file Castle.js
 * @description Stylized castle silhouette used on adventure maps. Multiple
 *   towers, central keep, flag, and gate. Procedural.
 */

import { TERRAIN, UI, PAPER, ALPHA } from '../constants/palette.js';
import { withAlpha, shade } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw a castle at (cx, cy).
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx
 * @param {number} cy
 * @param {number} w Width of the castle footprint.
 * @param {Object} [opts]
 * @param {number|string} [opts.seed='castle']
 * @param {string} [opts.banner=UI.blood] Banner color.
 */
export function drawCastle(ctx, cx, cy, w, opts = {}) {
  const seed = opts.seed ?? 'castle';
  const rng = createRandom(seed);
  const banner = opts.banner ?? UI.blood;
  const h = w * 0.7;

  ctx.save();

  // Ground shadow.
  ctx.fillStyle = withAlpha('#000000', ALPHA.shadow);
  ctx.beginPath();
  ctx.ellipse(cx, cy + h * 0.5, w * 0.6, h * 0.1, 0, 0, Math.PI * 2);
  ctx.fill();

  // Mountain base.
  ctx.fillStyle = shade(TERRAIN.mountain.base, -0.05);
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.7, cy + h * 0.5);
  ctx.lineTo(cx - w * 0.4, cy + h * 0.1);
  ctx.lineTo(cx + w * 0.4, cy + h * 0.1);
  ctx.lineTo(cx + w * 0.7, cy + h * 0.5);
  ctx.closePath();
  ctx.fill();

  // Side towers.
  drawTower(ctx, cx - w * 0.35, cy + h * 0.05, w * 0.2, h * 0.7);
  drawTower(ctx, cx + w * 0.35, cy + h * 0.05, w * 0.2, h * 0.7);

  // Central keep (taller).
  drawTower(ctx, cx, cy - h * 0.05, w * 0.28, h * 0.95, { banner });

  // Curtain wall connecting towers.
  const wallY = cy + h * 0.25;
  const wallH = h * 0.3;
  ctx.fillStyle = shade(TERRAIN.mountain.base, 0.05);
  ctx.fillRect(cx - w * 0.5, wallY, w, wallH);

  // Merlons on the wall.
  ctx.fillStyle = shade(TERRAIN.mountain.base, 0.1);
  const merlonW = w * 0.06;
  for (let i = 0; i < 8; i++) {
    const mx = cx - w * 0.5 + i * (w / 8);
    ctx.fillRect(mx, wallY - merlonW, merlonW * 0.7, merlonW);
  }

  // Gate.
  const gateW = w * 0.18;
  const gateH = h * 0.3;
  ctx.fillStyle = '#1c0f06';
  ctx.beginPath();
  ctx.moveTo(cx - gateW / 2, cy + h * 0.5);
  ctx.lineTo(cx - gateW / 2, cy + h * 0.5 - gateH * 0.7);
  ctx.quadraticCurveTo(cx, cy + h * 0.5 - gateH, cx + gateW / 2, cy + h * 0.5 - gateH * 0.7);
  ctx.lineTo(cx + gateW / 2, cy + h * 0.5);
  ctx.closePath();
  ctx.fill();

  // Portcullis grid.
  ctx.strokeStyle = withAlpha(UI.iron, 0.8);
  ctx.lineWidth = 1;
  for (let i = 1; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(cx - gateW / 2 + (gateW / 6) * i, cy + h * 0.5 - gateH * 0.7);
    ctx.lineTo(cx - gateW / 2 + (gateW / 6) * i, cy + h * 0.5);
    ctx.stroke();
  }
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(cx - gateW / 2, cy + h * 0.5 - (gateH / 4) * i);
    ctx.lineTo(cx + gateW / 2, cy + h * 0.5 - (gateH / 4) * i);
    ctx.stroke();
  }

  void rng;
  void PAPER;
  ctx.restore();
}

/**
 * Draw a single tower.
 */
function drawTower(ctx, cx, cy, w, h, opts = {}) {
  ctx.save();
  // Body.
  const grad = ctx.createLinearGradient(cx - w / 2, 0, cx + w / 2, 0);
  grad.addColorStop(0, shade('#9a8870', -0.1));
  grad.addColorStop(0.5, '#a89678');
  grad.addColorStop(1, shade('#9a8870', -0.2));
  ctx.fillStyle = grad;
  ctx.fillRect(cx - w / 2, cy - h, w, h);

  // Crenellations.
  ctx.fillStyle = shade('#9a8870', 0.05);
  const merlonW = w * 0.18;
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(cx - w / 2 + i * (w / 4), cy - h - merlonW, merlonW, merlonW);
  }

  // Window.
  ctx.fillStyle = '#1c0f06';
  ctx.fillRect(cx - w * 0.08, cy - h * 0.6, w * 0.16, h * 0.18);

  // Banner on a pole.
  if (opts.banner) {
    const px = cx;
    const py = cy - h - merlonW * 2;
    ctx.strokeStyle = '#3a2410';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px, py - h * 0.25);
    ctx.stroke();

    ctx.fillStyle = opts.banner;
    ctx.beginPath();
    ctx.moveTo(px, py - h * 0.22);
    ctx.lineTo(px + w * 0.45, py - h * 0.18);
    ctx.lineTo(px + w * 0.35, py - h * 0.12);
    ctx.lineTo(px + w * 0.45, py - h * 0.06);
    ctx.lineTo(px, py - h * 0.08);
    ctx.closePath();
    ctx.fill();
  }

  ctx.restore();
}

export default { drawCastle };
