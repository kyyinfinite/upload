/**
 * @file Paper.js
 * @description Reusable parchment background. Used by every renderer as the
 *   base layer. Pulls a pre-computed texture from TextureCache so the same
 *   grain is reused across all images — important for performance and visual
 *   consistency.
 */

import { paperTexture } from '../core/TextureCache.js';
import { PAPER, ALPHA } from '../constants/palette.js';
import { withAlpha } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';

/**
 * Draw the parchment paper background, edge-darkened and lightly stained.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w Width of the canvas (CSS space).
 * @param {number} h Height of the canvas (CSS space).
 * @param {Object} [opts]
 * @param {number|string} [opts.seed='paper']
 * @param {number} [opts.vignette=ALPHA.vignette] Strength of edge darkening.
 */
export function drawPaper(ctx, w, h, opts = {}) {
  const seed = opts.seed ?? 'paper';
  const vignette = opts.vignette ?? ALPHA.vignette;

  // Tile the cached paper texture across the whole canvas.
  const tex = paperTexture(seed);
  const pattern = ctx.createPattern(tex, 'repeat');
  ctx.fillStyle = pattern;
  ctx.fillRect(0, 0, w, h);

  // Edge vignette: a radial gradient transparent in center, dark at edges.
  const grad = ctx.createRadialGradient(
    w / 2, h / 2, Math.min(w, h) * 0.3,
    w / 2, h / 2, Math.max(w, h) * 0.75,
  );
  grad.addColorStop(0, withAlpha(PAPER.shadow, 0));
  grad.addColorStop(1, withAlpha(PAPER.edge, vignette));
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // A handful of irregular "age stains" for character.
  const rng = createRandom(`${seed}:stains`);
  ctx.save();
  for (let i = 0; i < 6; i++) {
    const x = rng.range(0, w);
    const y = rng.range(0, h);
    const r = rng.range(60, 180);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, withAlpha(PAPER.edge, rng.range(0.05, 0.15)));
    g.addColorStop(1, withAlpha(PAPER.edge, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export default { drawPaper };
