/**
 * @file Fog.js
 * @description Reusable fog overlay. Two modes:
 *   - 'cached'  (default) uses the pre-computed fog texture from TextureCache
 *   - 'live'    regenerates blobs per-call (slower, but seedable per-render)
 */

import { fogTexture } from '../core/TextureCache.js';
import { withAlpha } from '../core/Colors.js';
import { createRandom } from '../core/Random.js';
import { ALPHA } from '../constants/palette.js';

/**
 * Overlay fog across the canvas.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} w
 * @param {number} h
 * @param {Object} [opts]
 * @param {'cached'|'live'} [opts.mode='cached']
 * @param {number} [opts.alpha=ALPHA.fog] Multiplier applied to fog density.
 * @param {number|string} [opts.seed='fog']
 * @param {number} [opts.blobs=40] Only used in 'live' mode.
 * @param {string} [opts.color='#e8e8e8']
 */
export function drawFog(ctx, w, h, opts = {}) {
  const mode = opts.mode ?? 'cached';
  const alpha = opts.alpha ?? ALPHA.fog;
  const seed = opts.seed ?? 'fog';
  const color = opts.color ?? '#e8e8e8';

  ctx.save();
  ctx.globalAlpha = alpha / ALPHA.fog; // normalize so passing alpha=0.2 halves density

  if (mode === 'cached') {
    const tex = fogTexture(seed);
    const pattern = ctx.createPattern(tex, 'repeat');
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
  } else {
    const blobs = opts.blobs ?? 40;
    const rng = createRandom(seed);
    for (let i = 0; i < blobs; i++) {
      const x = rng.range(0, w);
      const y = rng.range(0, h);
      const r = rng.range(80, 240);
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, withAlpha(color, ALPHA.fog * rng.range(0.5, 1)));
      g.addColorStop(1, withAlpha(color, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

export default { drawFog };
