/**
 * @file Colors.js
 * @description Color manipulation helpers — all renderers route hex/rgb/hsl
 *   conversions through here. No renderer should hand-roll string parsing.
 */

import PALETTE from '../constants/palette.js';

/**
 * Parse any color string (`#rgb`, `#rrggbb`, `#rrggbbaa`, `rgb(...)`, or
 * `rgba(...)`) into an RGBA tuple. This makes all downstream helpers
 * (withAlpha, shade, lerpColor) composable — you can pass the output of
 * one to another without worrying about format.
 *
 * @param {string} color
 * @returns {[number,number,number,number]} [r,g,b,a] — r/g/b in [0,255], a ∈ [0,1].
 */
export function hexToRgba(color) {
  const s = String(color).trim();

  // rgba(...) / rgb(...)
  if (s.startsWith('rgb')) {
    const inner = s.replace(/^rgba?\(/, '').replace(/\)$/, '').trim();
    const parts = inner.split(',').map((p) => parseFloat(p.trim()));
    const [r, g, b] = parts;
    const a = parts.length === 4 ? parts[3] : 1;
    return [r, g, b, a];
  }

  // hex
  let h = s.replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  if (h.length === 4) h = h.split('').map((c) => c + c).join('');
  if (h.length !== 6 && h.length !== 8) {
    throw new Error(`Invalid color: ${color}`);
  }
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  const a = h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1;
  return [r, g, b, a];
}

/**
 * Convert an RGBA tuple to an `rgba()` CSS string.
 * @param {[number,number,number,number?]} rgba
 * @returns {string}
 */
export function rgbaCss([r, g, b, a = 1]) {
  return `rgba(${r|0}, ${g|0}, ${b|0}, ${a})`;
}

/**
 * Linear interpolate between two hex colors.
 * @param {string} c1
 * @param {string} c2
 * @param {number} t ∈ [0,1]
 * @returns {string} `rgba(...)` string.
 */
export function lerpColor(c1, c2, t) {
  const a = hexToRgba(c1);
  const b = hexToRgba(c2);
  const r = a[0] + (b[0] - a[0]) * t;
  const g = a[1] + (b[1] - a[1]) * t;
  const bl = a[2] + (b[2] - a[2]) * t;
  const al = a[3] + (b[3] - a[3]) * t;
  return rgbaCss([r, g, bl, al]);
}

/**
 * Adjust the brightness of a hex color. `amount` in [-1, 1].
 * @param {string} hex
 * @param {number} amount
 * @returns {string} `rgba(...)` string.
 */
export function shade(hex, amount) {
  const [r, g, b, a] = hexToRgba(hex);
  if (amount >= 0) {
    return rgbaCss([
      r + (255 - r) * amount,
      g + (255 - g) * amount,
      b + (255 - b) * amount,
      a,
    ]);
  }
  const k = 1 + amount;
  return rgbaCss([r * k, g * k, b * k, a]);
}

/**
 * Apply an alpha multiplier to a hex color.
 * @param {string} hex
 * @param {number} alpha ∈ [0,1]
 * @returns {string}
 */
export function withAlpha(hex, alpha) {
  const [r, g, b] = hexToRgba(hex);
  return rgbaCss([r, g, b, alpha]);
}

/** Convenience access to the global palette. */
export const PALETTE_P = PALETTE;

export default {
  PALETTE,
  hexToRgba,
  rgbaCss,
  lerpColor,
  shade,
  withAlpha,
};
