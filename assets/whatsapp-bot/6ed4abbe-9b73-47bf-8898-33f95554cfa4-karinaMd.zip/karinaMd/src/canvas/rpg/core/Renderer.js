/**
 * @file Renderer.js
 * @description Abstract base class that defines the standard renderer
 *   lifecycle every generator MUST follow:
 *
 *     initialize() → drawBackground() → drawObjects() →
 *     drawDecorations() → drawEffects() → drawUI() → return buffer
 *
 * Generators extend this class and implement the protected draw* hooks.
 * The public entrypoint is `render(data)`. Subclasses cannot override the
 * `render()` shape — only the hooks.
 */

import { createManagedCanvas } from './CanvasManager.js';
import { init as initAssets } from './AssetLoader.js';
import { CANVAS_SIZES, DEFAULT_DPR } from '../constants/dimensions.js';

/**
 * @abstract
 */
export class Renderer {
  /**
   * @param {Object} config
   * @param {{width:number,height:number}} [config.size]  Target CSS size.
   * @param {number} [config.dpr]                          Device pixel ratio.
   */
  constructor(config = {}) {
    this.size = config.size ?? CANVAS_SIZES.DEFAULT;
    this.dpr = config.dpr ?? DEFAULT_DPR;
    /** @type {any} */
    this.data = null;
    /** @type {CanvasHandle|null} */
    this.handle = null;
    /** @type {CanvasRenderingContext2D|null} */
    this.ctx = null;
  }

  /**
   * Standard public entrypoint. Subclasses should NOT override this — they
   * implement the protected hooks below instead.
   *
   * @param {object} data Renderer payload.
   * @returns {Promise<Buffer>} PNG buffer.
   */
  async render(data) {
    await initAssets();
    this.data = data ?? {};
    this.handle = createManagedCanvas(this.size.width, this.size.height, { dpr: this.dpr });
    this.ctx = this.handle.ctx;

    try {
      await this.initialize();
      await this.drawBackground();
      await this.drawObjects();
      await this.drawDecorations();
      await this.drawEffects();
      await this.drawUI();
      return this.handle.canvas.toBuffer('image/png');
    } finally {
      this.handle.dispose();
      this.handle = null;
      this.ctx = null;
    }
  }

  /**
   * Optional pre-draw hook — load extra assets, compute layout, seed RNG.
   * @returns {void|Promise<void>}
   */
  async initialize() {}

  /**
   * Draw the base background (paper, terrain, gradient).
   * @returns {void|Promise<void>}
   */
  async drawBackground() {}

  /**
   * Draw primary objects (player, monsters, items, etc.).
   * @returns {void|Promise<void>}
   */
  async drawObjects() {}

  /**
   * Draw secondary decorative elements (trees, rocks, banners).
   * @returns {void|Promise<void>}
   */
  async drawDecorations() {}

  /**
   * Draw post-processing effects (fog, vignette, glow, particles).
   * @returns {void|Promise<void>}
   */
  async drawEffects() {}

  /**
   * Draw the UI layer (header, footer, buttons, labels).
   * @returns {void|Promise<void>}
   */
  async drawUI() {}
}

export default { Renderer };
