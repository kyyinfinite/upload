/**
 * @file TextureCache.js
 * @description Lazy procedural texture factory. Computes expensive textures
 *   (paper grain, fog overlay, wood, parchment) exactly once per process and
 *   returns cached tiles on subsequent calls. All textures are drawn to an
 *   offscreen canvas so they can be `drawImage`-d by components.
 */

import { createCanvas } from '@napi-rs/canvas';
import { createRandom } from './Random.js';
import { PAPER, TERRAIN, ALPHA } from '../constants/palette.js';
import { shade, withAlpha } from './Colors.js';

const _cache = new Map();

/**
 * Fetch a cached texture by key, or compute it via the supplied factory.
 *
 * @param {string} key Cache key.
 * @param {(rng: ReturnType<typeof createRandom>) => import('@napi-rs/canvas').Canvas} factory
 *   Builds the texture on first call.
 * @param {number|string} [seed] Seed for the factory's RNG.
 * @returns {import('@napi-rs/canvas').Canvas}
 */
export function cached(key, factory, seed = 1) {
  const cacheKey = `${key}:${seed}`;
  if (_cache.has(cacheKey)) return _cache.get(cacheKey);
  const rng = createRandom(seed);
  const canvas = factory(rng);
  _cache.set(cacheKey, canvas);
  return canvas;
}

/**
 * Build a parchment-paper texture tile (1024×1024).
 *
 * @param {number|string} [seed]
 * @returns {import('@napi-rs/canvas').Canvas}
 */
export function paperTexture(seed = 'paper') {
  return cached('paper', (rng) => {
    const size = 1024;
    const c = createCanvas(size, size);
    const ctx = c.getContext('2d');

    // Base fill.
    ctx.fillStyle = PAPER.base;
    ctx.fillRect(0, 0, size, size);

    // Soft radial gradient for vignette feel.
    const grad = ctx.createRadialGradient(size / 2, size / 2, size * 0.2, size / 2, size / 2, size * 0.7);
    grad.addColorStop(0, withAlpha(PAPER.light, 0.4));
    grad.addColorStop(1, withAlpha(PAPER.shadow, 0.2));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    // Fibers: thousands of short translucent strokes.
    ctx.lineCap = 'round';
    for (let i = 0; i < 4000; i++) {
      const x = rng.range(0, size);
      const y = rng.range(0, size);
      const len = rng.range(3, 12);
      const ang = rng.range(0, Math.PI * 2);
      const dx = Math.cos(ang) * len;
      const dy = Math.sin(ang) * len;
      const dark = rng.next() > 0.5;
      ctx.strokeStyle = withAlpha(dark ? PAPER.shadow : PAPER.light, rng.range(0.05, 0.18));
      ctx.lineWidth = rng.range(0.4, 1.2);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + dx, y + dy);
      ctx.stroke();
    }

    // Sparse darker speckles.
    for (let i = 0; i < 200; i++) {
      const x = rng.range(0, size);
      const y = rng.range(0, size);
      const r = rng.range(0.5, 1.6);
      ctx.fillStyle = withAlpha(PAPER.edge, rng.range(0.1, 0.3));
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    return c;
  }, seed);
}

/**
 * Build a fog overlay texture (transparent background, soft grey blobs).
 *
 * @param {number|string} [seed]
 * @returns {import('@napi-rs/canvas').Canvas}
 */
export function fogTexture(seed = 'fog') {
  return cached('fog', (rng) => {
    const size = 1024;
    const c = createCanvas(size, size);
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, size, size);

    const blobs = 60;
    for (let i = 0; i < blobs; i++) {
      const x = rng.range(0, size);
      const y = rng.range(0, size);
      const r = rng.range(80, 240);
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, withAlpha('#e8e8e8', ALPHA.fog * rng.range(0.5, 1)));
      g.addColorStop(1, withAlpha('#e8e8e8', 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    return c;
  }, seed);
}

/**
 * Build a generic noise tile used to perturb any background.
 *
 * @param {number|string} [seed]
 * @param {string} [color='#000000']
 * @returns {import('@napi-rs/canvas').Canvas}
 */
export function noiseTexture(seed = 'noise', color = '#000000') {
  return cached(`noise:${color}`, (rng) => {
    const size = 512;
    const c = createCanvas(size, size);
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(size, size);
    const [r, g, b] = hexToRgb(color);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = rng.next();
      img.data[i + 0] = r;
      img.data[i + 1] = g;
      img.data[i + 2] = b;
      img.data[i + 3] = Math.floor(v * 40); // very faint
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }, seed);
}

/**
 * Build a wood plank texture (for shop / inventory frames).
 *
 * @param {number|string} [seed]
 * @returns {import('@napi-rs/canvas').Canvas}
 */
export function woodTexture(seed = 'wood') {
  return cached('wood', (rng) => {
    const size = 1024;
    const c = createCanvas(size, size);
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#6e4a26';
    ctx.fillRect(0, 0, size, size);

    // Plank seams.
    const plankCount = 6;
    const plankH = size / plankCount;
    for (let p = 0; p < plankCount; p++) {
      const y = p * plankH;
      ctx.fillStyle = shade('#6e4a26', rng.range(-0.15, 0.1));
      ctx.fillRect(0, y, size, plankH);

      // Grain.
      for (let i = 0; i < 300; i++) {
        const gx = rng.range(0, size);
        const gy = y + rng.range(0, plankH);
        ctx.strokeStyle = withAlpha(rng.next() > 0.5 ? '#3a2410' : '#8a5e34', rng.range(0.05, 0.2));
        ctx.lineWidth = rng.range(0.3, 1);
        ctx.beginPath();
        ctx.moveTo(gx, gy);
        ctx.lineTo(gx + rng.range(20, 80), gy + rng.range(-2, 2));
        ctx.stroke();
      }
      // Seam line.
      ctx.strokeStyle = withAlpha('#1c0f06', 0.7);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(size, y);
      ctx.stroke();
    }
    return c;
  }, seed);
}

/**
 * Helper: hex → rgb tuple (local copy to avoid circular import).
 */
function hexToRgb(hex) {
  let h = hex.replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
}

/**
 * Clear every cached texture. Intended for tests.
 */
export function clear() {
  _cache.clear();
}

export default {
  cached,
  paperTexture,
  fogTexture,
  noiseTexture,
  woodTexture,
  clear,
};
