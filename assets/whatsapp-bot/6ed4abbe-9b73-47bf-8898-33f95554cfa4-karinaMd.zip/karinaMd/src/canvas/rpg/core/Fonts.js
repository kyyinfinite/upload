/**
 * @file Fonts.js
 * @description Thin wrapper around `@napi-rs/canvas` GlobalFonts. Exposes a
 *   one-shot registration routine called by AssetLoader. Renderers should
 *   never call GlobalFonts directly — they go through AssetLoader.
 */

import { GlobalFonts } from '@napi-rs/canvas';
import { existsSync } from 'node:fs';
import { PATHS } from '../constants/paths.js';
import { FONT_FAMILY } from '../constants/typography.js';

/**
 * Mapping of font family → relative path inside `assets/fonts`.
 * AssetLoader will register every file that exists; missing ones fall back
 * to `FONT_FAMILY.fallback`.
 */
export const FONT_FILES = Object.freeze({
  [FONT_FAMILY.heading]: ['Cinzel-Regular.ttf', 'Cinzel-Bold.ttf'],
  [FONT_FAMILY.body]:    ['MedievalSharp-Regular.ttf'],
  [FONT_FAMILY.mono]:    ['SarasaMonoSC-Regular.ttf', 'SarasaMonoSC-Bold.ttf'],
});

let _registered = false;
let _availableFamilies = new Set();

/**
 * Register every font file declared in {@link FONT_FILES} that physically
 * exists on disk. Safe to call multiple times — only the first call performs
 * actual registration.
 *
 * @returns {Promise<{registered:string[], missing:string[]}>}
 */
export async function registerFonts() {
  if (_registered) {
    return { registered: [..._availableFamilies], missing: [] };
  }

  const registered = [];
  const missing = [];

  for (const [family, files] of Object.entries(FONT_FILES)) {
    let anyOk = false;
    for (const file of files) {
      const abs = `${PATHS.FONTS_DIR}/${file}`;
      if (existsSync(abs)) {
        try {
          GlobalFonts.registerFromPath(abs, family);
          anyOk = true;
        } catch {
          missing.push(abs);
        }
      } else {
        missing.push(abs);
      }
    }
    if (anyOk) {
      _availableFamilies.add(family);
      registered.push(family);
    }
  }

  _registered = true;
  return { registered, missing };
}

/**
 * Check whether a font family is registered and ready.
 * @param {string} family
 * @returns {boolean}
 */
export function hasFont(family) {
  return _availableFamilies.has(family);
}

export default { FONT_FILES, registerFonts, hasFont };
