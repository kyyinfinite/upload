/**
 * @file Exporter.js
 * @description Output helpers around PNG buffers produced by Renderer.render().
 *   Centralizes encoding options, metadata, and (optional) disk persistence.
 */

import { writeFile, mkdir } from 'node:fs/promises';
import { dirname } from 'node:path';
import { PATHS } from '../constants/paths.js';

/**
 * Default PNG encoding options for `canvas.toBuffer`.
 */
export const PNG_OPTIONS = Object.freeze({
  compressionLevel: 6,
  filters: 1,
  background: 0x00000000,
});

/**
 * Convert a managed canvas handle to a PNG buffer with consistent options.
 *
 * @param {import('./CanvasManager.js').CanvasHandle} handle
 * @returns {Buffer}
 */
export function toPng(handle) {
  return handle.canvas.toBuffer('image/png', PNG_OPTIONS);
}

/**
 * Persist a buffer to disk under the assets/cache directory.
 *
 * @param {Buffer} buffer
 * @param {string} filename
 * @returns {Promise<string>} Absolute path of the written file.
 */
export async function saveToCache(buffer, filename) {
  const abs = `${PATHS.CACHE_DIR}/${filename}`;
  await mkdir(dirname(abs), { recursive: true });
  await writeFile(abs, buffer);
  return abs;
}

/**
 * Compute a stable filename from a key and timestamp.
 *
 * @param {string} key e.g. 'map', 'profile'.
 * @param {string|number} [id] Optional id (user id, map id, etc.).
 * @returns {string}
 */
export function makeFilename(key, id = '') {
  const ts = Date.now();
  const safeId = String(id).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 32);
  return `${key}${safeId ? `_${safeId}` : ''}_${ts}.png`;
}

export default { PNG_OPTIONS, toPng, saveToCache, makeFilename };
