/**
 * @file core/index.js
 * @description Barrel export for all core modules.
 */

export { default as CanvasManager } from './CanvasManager.js';
export { createManagedCanvas, withCanvas, getTotalAllocatedBytes } from './CanvasManager.js';

export { default as AssetLoader } from './AssetLoader.js';
export { init, loadImage, loadAsset, setTexture, getTexture, isInitialized, reset, stats } from './AssetLoader.js';

export { default as TextureCache } from './TextureCache.js';
export { cached, paperTexture, fogTexture, noiseTexture, woodTexture } from './TextureCache.js';

export { default as Renderer } from './Renderer.js';
export { Renderer as RendererClass } from './Renderer.js';

export { default as Exporter } from './Exporter.js';
export { toPng, saveToCache, makeFilename, PNG_OPTIONS } from './Exporter.js';

export { default as Random, createRandom } from './Random.js';
export { default as Noise, createNoise2D } from './Noise.js';
export { default as Colors } from './Colors.js';
export { hexToRgba, rgbaCss, lerpColor, shade, withAlpha } from './Colors.js';
export { default as Fonts } from './Fonts.js';
export { registerFonts, hasFont, FONT_FILES } from './Fonts.js';
export { default as Helpers } from './Helpers.js';
export { clamp, lerp, roundRect, drawWrappedText, wrapText, dist, formatNumber, formatDuration, hashString } from './Helpers.js';

export { default } from './Renderer.js';
