/**
 * @file Helpers.js
 * @description Generic geometry / drawing helpers shared across components
 *   and generators. Pure functions only — no canvas state is mutated except
 *   where explicitly stated.
 */

/**
 * Clamp a value into a range.
 * @param {number} v
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
export const clamp = (v, min, max) => (v < min ? min : v > max ? max : v);

/**
 * Linear interpolation.
 * @param {number} a
 * @param {number} b
 * @param {number} t
 * @returns {number}
 */
export const lerp = (a, b, t) => a + (b - a) * t;

/**
 * Round-rect path helper. napi-rs/canvas supports `ctx.roundRect`, but we
 * provide a manual fallback so renderers work on older builds too.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {number} h
 * @param {number|number[]} radius
 */
export function roundRect(ctx, x, y, w, h, radius) {
  let r;
  if (Array.isArray(radius)) {
    const [tl, tr, br, bl] = radius;
    r = { tl, tr, br, bl };
  } else {
    r = { tl: radius, tr: radius, br: radius, bl: radius };
  }
  // Clamp radii so they never exceed half of the shorter side.
  const maxR = Math.min(w, h) / 2;
  r.tl = Math.min(r.tl, maxR);
  r.tr = Math.min(r.tr, maxR);
  r.br = Math.min(r.br, maxR);
  r.bl = Math.min(r.bl, maxR);

  ctx.beginPath();
  ctx.moveTo(x + r.tl, y);
  ctx.lineTo(x + w - r.tr, y);
  ctx.arcTo(x + w, y,         x + w, y + r.tr, r.tr);
  ctx.lineTo(x + w, y + h - r.br);
  ctx.arcTo(x + w, y + h,     x + w - r.br, y + h, r.br);
  ctx.lineTo(x + r.bl, y + h);
  ctx.arcTo(x, y + h,         x, y + h - r.bl, r.bl);
  ctx.lineTo(x, y + r.tl);
  ctx.arcTo(x, y,             x + r.tl, y, r.tl);
  ctx.closePath();
}

/**
 * Draw a multi-line text block with wrapping. The context's `font`,
 * `fillStyle`, `textAlign`, and `textBaseline` must already be set.
 *
 * @param {CanvasRenderingContext2D} ctx
 * @param {string} text
 * @param {number} x
 * @param {number} y
 * @param {number} maxWidth
 * @param {number} lineHeight
 */
export function drawWrappedText(ctx, text, x, y, maxWidth, lineHeight) {
  const paragraphs = String(text).split('\n');
  let cursorY = y;
  for (const paragraph of paragraphs) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        ctx.fillText(line, x, cursorY);
        cursorY += lineHeight;
        line = word;
      } else {
        line = test;
      }
    }
    if (line) {
      ctx.fillText(line, x, cursorY);
      cursorY += lineHeight;
    }
  }
  return cursorY;
}

/**
 * Wrap text into an array of lines without drawing.
 * @param {CanvasRenderingContext2D} ctx
 * @param {string} text
 * @param {number} maxWidth
 * @returns {string[]}
 */
export function wrapText(ctx, text, maxWidth) {
  const out = [];
  for (const paragraph of String(text).split('\n')) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        out.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    out.push(line);
  }
  return out;
}

/**
 * Distance between two points.
 */
export const dist = (x1, y1, x2, y2) => Math.hypot(x2 - x1, y2 - y1);

/**
 * Format a big number with `k`/`M`/`B` suffixes.
 * @param {number} n
 * @returns {string}
 */
export function formatNumber(n) {
  const abs = Math.abs(n);
  if (abs >= 1e9) return `${(n / 1e9).toFixed(1)}B`;
  if (abs >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (abs >= 1e3) return `${(n / 1e3).toFixed(1)}k`;
  return `${n}`;
}

/**
 * Time-remaining formatter (ms → "1d 02h 15m").
 * @param {number} ms
 * @returns {string}
 */
export function formatDuration(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d > 0) return `${d}d ${String(h).padStart(2,'0')}h ${String(m).padStart(2,'0')}m`;
  if (h > 0) return `${h}h ${String(m).padStart(2,'0')}m`;
  if (m > 0) return `${m}m ${String(sec).padStart(2,'0')}s`;
  return `${sec}s`;
}

/**
 * Simple deterministic string hash (FNV-1a 32-bit). Useful when a generator
 * wants to derive a seed from a user ID.
 * @param {string} str
 * @returns {number}
 */
export function hashString(str) {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return hash >>> 0;
}

export default {
  clamp,
  lerp,
  roundRect,
  drawWrappedText,
  wrapText,
  dist,
  formatNumber,
  formatDuration,
  hashString,
};
