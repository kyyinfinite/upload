/**
 * @file CanvasManager.js
 * @description Centralized Canvas factory. Every renderer obtains its canvas,
 *   context, and DPI scaling through this manager — never via direct
 *   `createCanvas()` calls. The manager also owns the export pipeline and
 *   memory accounting.
 */

import { createCanvas } from '@napi-rs/canvas';
import { DEFAULT_DPR } from '../constants/dimensions.js';

/**
 * @typedef {Object} CanvasHandle
 * @property {import('@napi-rs/canvas').Canvas} canvas      Underlying canvas (DPR-scaled).
 * @property {CanvasRenderingContext2D} ctx                  2D context already pre-scaled.
 * @property {number} width                                  CSS-space width.
 * @property {number} height                                 CSS-space height.
 * @property {number} dpr                                    Device pixel ratio used.
 * @property {() => void} dispose                            Free resources.
 */

let _totalAllocated = 0;

/**
 * Create a managed canvas pre-scaled for the given DPR.
 *
 * The returned `ctx` is configured so that all drawing code can use CSS-space
 * coordinates (i.e. the dimensions originally passed in). The backing store
 * is `width * dpr` × `height * dpr` for crisp output on high-DPI displays.
 *
 * @param {number} width  CSS-space width.
 * @param {number} height CSS-space height.
 * @param {Object} [opts]
 * @param {number} [opts.dpr=DEFAULT_DPR] Device pixel ratio.
 * @returns {CanvasHandle}
 */
export function createManagedCanvas(width, height, opts = {}) {
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) {
    throw new Error(`Invalid canvas dimensions: ${width}x${height}`);
  }
  const dpr = opts.dpr ?? DEFAULT_DPR;
  const backingW = Math.ceil(width * dpr);
  const backingH = Math.ceil(height * dpr);

  const canvas = createCanvas(backingW, backingH);
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.textBaseline = 'alphabetic';
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  _totalAllocated += backingW * backingH * 4;

  let disposed = false;

  return Object.freeze({
    canvas,
    ctx,
    width,
    height,
    dpr,
    dispose() {
      if (disposed) return;
      disposed = true;
      _totalAllocated -= backingW * backingH * 4;
      // napi-rs canvas doesn't expose explicit free; dropping refs is enough.
      ctx.clearRect(0, 0, width, height);
    },
  });
}

/**
 * Current cumulative backing-store allocation in bytes (best-effort).
 * Useful for monitoring memory leaks in long-running bots.
 * @returns {number}
 */
export function getTotalAllocatedBytes() {
  return _totalAllocated;
}

/**
 * Convenience: render a callback onto a fresh managed canvas and return the
 * PNG buffer. Handles dispose automatically.
 *
 * @param {number} width
 * @param {number} height
 * @param {(ctx: CanvasRenderingContext2D, handle: CanvasHandle) => void|Promise<void>} draw
 * @param {Object} [opts]
 * @param {number} [opts.dpr]
 * @returns {Promise<Buffer>} PNG buffer.
 */
export async function withCanvas(width, height, draw, opts = {}) {
  const handle = createManagedCanvas(width, height, opts);
  try {
    await draw(handle.ctx, handle);
    return handle.canvas.toBuffer('image/png');
  } finally {
    handle.dispose();
  }
}

export default { createManagedCanvas, getTotalAllocatedBytes, withCanvas };
