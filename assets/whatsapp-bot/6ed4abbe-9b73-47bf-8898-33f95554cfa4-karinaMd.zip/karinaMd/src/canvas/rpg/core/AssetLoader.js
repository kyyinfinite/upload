/**
 * @file AssetLoader.js
 * @description Singleton asset loader. Loads PNG images, fonts, and textures
 *   exactly once and caches them for the lifetime of the process. All
 *   generators and components MUST route asset lookups through this loader.
 */

import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { Image } from '@napi-rs/canvas';
import { PATHS, assetPath } from '../constants/paths.js';
import { registerFonts } from './Fonts.js';

/**
 * @typedef {Object} AssetLoaderOptions
 * @property {boolean} [autoRegisterFonts=true] Whether to call registerFonts() on init().
 * @property {number} [maxImages=512] Maximum number of cached images before LRU eviction.
 */

const _imageCache = new Map();
const _textureCache = new Map();
let _initialized = false;
let _initPromise = null;

/**
 * Initialize the loader. Idempotent. Safe to `await` from multiple generators
 * in parallel — initialization runs exactly once.
 *
 * @param {AssetLoaderOptions} [opts]
 * @returns {Promise<void>}
 */
export async function init(opts = {}) {
  if (_initialized) return;
  if (_initPromise) return _initPromise;

  _initPromise = (async () => {
    if (opts.autoRegisterFonts !== false) {
      await registerFonts();
    }
    _initialized = true;
  })();

  return _initPromise;
}

/**
 * Load an image file from disk (or return a cached copy).
 * The cache key is the absolute path, so loading the same file twice returns
 * the same `Image` instance.
 *
 * @param {string} absPath Absolute filesystem path.
 * @returns {Promise<Image>}
 */
export async function loadImage(absPath) {
  if (_imageCache.has(absPath)) {
    return _imageCache.get(absPath);
  }
  if (!existsSync(absPath)) {
    throw new Error(`AssetLoader: image not found: ${absPath}`);
  }
  const buf = await readFile(absPath);
  const img = new Image();
  img.src = buf;
  _imageCache.set(absPath, img);

  // LRU-ish eviction.
  if (_imageCache.size > 512) {
    const firstKey = _imageCache.keys().next().value;
    _imageCache.delete(firstKey);
  }
  return img;
}

/**
 * Load an image from one of the asset buckets.
 *
 * @param {keyof typeof PATHS} bucket
 * @param {string} filename
 * @returns {Promise<Image>}
 */
export async function loadAsset(bucket, filename) {
  return loadImage(assetPath(bucket, filename));
}

/**
 * Register a pre-decoded texture under a logical name. Used by TextureCache
 * so that procedural textures (e.g. paper, fog) are computed only once.
 *
 * @param {string} key
 * @param {import('@napi-rs/canvas').Canvas|Image} texture
 */
export function setTexture(key, texture) {
  _textureCache.set(key, texture);
}

/**
 * Fetch a previously registered texture.
 * @param {string} key
 * @returns {import('@napi-rs/canvas').Canvas|Image|undefined}
 */
export function getTexture(key) {
  return _textureCache.get(key);
}

/**
 * Has the loader been initialized?
 * @returns {boolean}
 */
export function isInitialized() {
  return _initialized;
}

/**
 * Clear every cache and reset state. Intended for tests.
 * @returns {void}
 */
export function reset() {
  _imageCache.clear();
  _textureCache.clear();
  _initialized = false;
  _initPromise = null;
}

/**
 * Current cache statistics.
 * @returns {{images:number, textures:number, initialized:boolean}}
 */
export function stats() {
  return {
    images: _imageCache.size,
    textures: _textureCache.size,
    initialized: _initialized,
  };
}

export default {
  init,
  loadImage,
  loadAsset,
  setTexture,
  getTexture,
  isInitialized,
  reset,
  stats,
};
