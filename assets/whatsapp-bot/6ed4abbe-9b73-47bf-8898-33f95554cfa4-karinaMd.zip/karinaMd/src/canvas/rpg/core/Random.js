/**
 * @file Random.js
 * @description Deterministic, seedable PRNG utility. Identical seeds MUST
 *   produce identical sequences, so a generator seeded with the same value
 *   yields a pixel-identical image — this is the cornerstone of reproducible
 *   procedural rendering.
 *
 * Implementation: mulberry32 — fast, 32-bit, well-distributed, and tiny.
 */

/**
 * @typedef {Object} RandomAPI
 * @property {() => number} next       Returns a float in [0, 1).
 * @property {(min:number,max:number) => number} range   Float in [min, max).
 * @property {(min:number,max:number) => number} int     Integer in [min, max] inclusive.
 * @property {<T>(arr:readonly T[]) => T} pick            Random element of an array.
 * @property {<T>(arr:readonly T[]) => T[]} shuffle       Returns a shuffled copy.
 * @property {(mean:number, sd:number) => number} gauss   Normal-distributed value.
 * @property {() => number} seed Returns the original seed (for debugging).
 */

/**
 * Create a seeded random generator.
 *
 * @param {number|string} [seed] Numeric seed or string (hashed to a uint32).
 *   When omitted, a time-based seed is used (non-deterministic).
 * @returns {RandomAPI}
 */
export function createRandom(seed) {
  const numericSeed = normalizeSeed(seed);
  const state = { value: numericSeed >>> 0 };

  const next = () => {
    // mulberry32
    state.value |= 0;
    state.value = (state.value + 0x6d2b79f5) | 0;
    let t = Math.imul(state.value ^ (state.value >>> 15), 1 | state.value);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  const range = (min, max) => min + next() * (max - min);

  const int = (min, max) => Math.floor(min + next() * (max - min + 1));

  const pick = (arr) => {
    if (!arr.length) throw new Error('pick() from empty array');
    return arr[Math.floor(next() * arr.length)];
  };

  const shuffle = (arr) => {
    const out = arr.slice();
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(next() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  };

  const gauss = (mean, sd) => {
    // Box-Muller
    const u = 1 - next();
    const v = next();
    const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    return mean + z * sd;
  };

  return { next, range, int, pick, shuffle, gauss, seed: numericSeed };
}

/**
 * Convert any seed (number / string / undefined) to a uint32 numeric seed.
 * @param {number|string|undefined} seed
 * @returns {number}
 */
function normalizeSeed(seed) {
  if (seed === undefined || seed === null) {
    return (Date.now() ^ (Math.random() * 0xffffffff)) >>> 0;
  }
  if (typeof seed === 'number') {
    return seed >>> 0;
  }
  // String → FNV-1a 32-bit hash
  let hash = 0x811c9dc5;
  for (let i = 0; i < seed.length; i++) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return hash >>> 0;
}

export default { createRandom };
