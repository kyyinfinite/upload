/**
 * @file Noise.js
 * @description Value-noise generator backed by a seeded PRNG. Provides 2D
 *   smooth noise used by terrain generation, fog, cloud cover, and texture
 *   perturbation. Deterministic: same seed → identical noise field.
 */

import { createRandom } from './Random.js';

/**
 * @typedef {Object} Noise2D
 * @property {(x:number,y:number) => number} noise   Returns [0,1].
 * @property {(x:number,y:number,octaves:number,persistence:number,scale:number) => number} fractal
 *   Fractal Brownian Motion (fBm) accumulator.
 */

/**
 * Build a 2D value-noise field.
 *
 * @param {number|string} [seed] Seed for the underlying hash grid.
 * @param {number} [gridSize=64] Hash-grid resolution. Larger → smoother noise.
 * @returns {Noise2D}
 */
export function createNoise2D(seed, gridSize = 64) {
  const rng = createRandom(seed);
  const size = Math.max(2, gridSize | 0);
  const grid = new Float32Array(size * size);
  for (let i = 0; i < grid.length; i++) grid[i] = rng.next();

  const at = (x, y) => {
    const ix = ((x % size) + size) % size;
    const iy = ((y % size) + size) % size;
    return grid[iy * size + ix];
  };

  const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10); // smoothstep

  const noise = (x, y) => {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;

    const v00 = at(xi,     yi);
    const v10 = at(xi + 1, yi);
    const v01 = at(xi,     yi + 1);
    const v11 = at(xi + 1, yi + 1);

    const u = fade(xf);
    const v = fade(yf);

    const a = v00 + (v10 - v00) * u;
    const b = v01 + (v11 - v01) * u;
    return a + (b - a) * v;
  };

  const fractal = (x, y, octaves = 4, persistence = 0.5, scale = 0.05) => {
    let amp = 1;
    let freq = scale;
    let sum = 0;
    let norm = 0;
    for (let o = 0; o < octaves; o++) {
      sum += noise(x * freq, y * freq) * amp;
      norm += amp;
      amp *= persistence;
      freq *= 2;
    }
    return sum / norm;
  };

  return { noise, fractal };
}

export default { createNoise2D };
