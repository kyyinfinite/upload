import { createCanvas } from '@napi-rs/canvas';
import GIFEncoder from 'gifencoder';
import os from 'os';

export async function generateServerStatsGIF() {
  const WIDTH = 600;
  const HEIGHT = 350;
  const FRAMES = 15;
  const FRAME_DELAY = 150;

  const COLORS = {
    background: '#E0F2FE',
    cardBg: '#FFFFFF',
    primary: '#1E293B',
    secondary: '#64748B',
    accent: '#3B82F6',
    success: '#10B981',
    chartLine: '#8B5CF6',
    grid: '#E2E8F0'
  };

  const getMetrics = () => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePercent = ((usedMem / totalMem) * 100).toFixed(1);
    
    const cpus = os.cpus();
    const cpuUsage = cpus.reduce((acc, cpu) => {
      const total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
      const idle = cpu.times.idle;
      return acc + ((total - idle) / total) * 100;
    }, 0) / cpus.length;

    const uptime = process.uptime();
    const uptimeFormatted = formatUptime(uptime);
    const latencyData = Array.from({ length: 30 }, () => Math.random() * 50 + 20);

    return {
      nodeVersion: process.version,
      platform: os.platform(),
      arch: os.arch(),
      cpuUsage: cpuUsage.toFixed(1),
      memUsagePercent,
      usedMemGB: (usedMem / (1024 ** 3)).toFixed(2),
      totalMemGB: (totalMem / (1024 ** 3)).toFixed(2),
      uptime: uptimeFormatted,
      latencyData,
      currentLatency: Math.round(Math.random() * 50 + 20)
    };
  };

  const formatUptime = (seconds) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const encoder = new GIFEncoder(WIDTH, HEIGHT);
  encoder.start();
  encoder.setRepeat(0);
  encoder.setDelay(FRAME_DELAY);
  encoder.setQuality(10);

  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext('2d');

  const metrics = getMetrics();
  const latencyHistory = [...metrics.latencyData];

  const drawServerIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.fillStyle = COLORS.accent;
    ctx.lineWidth = 2;

    for (let i = 0; i < 3; i++) {
      const offsetY = i * (size / 3.5);
      ctx.strokeRect(x, y + offsetY, size, size / 4);
      
      ctx.fillStyle = i === 1 ? COLORS.success : COLORS.accent;
      ctx.beginPath();
      ctx.arc(x + size * 0.15, y + offsetY + size / 8, 2, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = COLORS.success;
      ctx.beginPath();
      ctx.arc(x + size * 0.3, y + offsetY + size / 8, 2, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  };

  const drawClockIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.fillStyle = COLORS.accent;
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(x + size / 2, y + size / 2);
    ctx.lineTo(x + size / 2, y + size * 0.2);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(x + size / 2, y + size / 2);
    ctx.lineTo(x + size * 0.75, y + size / 2);
    ctx.stroke();

    ctx.restore();
  };

  const drawSignalIcon = (ctx, x, y, size, frame) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.fillStyle = COLORS.accent;
    ctx.lineWidth = 2;

    const pulsePhase = (frame % FRAMES) / FRAMES;
    
    for (let i = 0; i < 3; i++) {
      const phase = (pulsePhase + i * 0.33) % 1;
      const radius = size * 0.3 + (size * 0.7 * phase);
      const opacity = 1 - phase;
      
      ctx.strokeStyle = `rgba(59, 130, 246, ${opacity * 0.6})`;
      ctx.beginPath();
      ctx.arc(x + size / 2, y + size / 2, radius, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = COLORS.accent;
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  };

  const drawCPUIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.fillStyle = COLORS.accent;
    ctx.lineWidth = 2;

    ctx.strokeRect(x + size * 0.2, y + size * 0.2, size * 0.6, size * 0.6);
    
    for (let i = 0; i < 3; i++) {
      const offset = size * 0.25 + i * size * 0.25;
      ctx.beginPath();
      ctx.moveTo(x, y + offset);
      ctx.lineTo(x + size * 0.2, y + offset);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x + size * 0.8, y + offset);
      ctx.lineTo(x + size, y + offset);
      ctx.stroke();
    }

    ctx.restore();
  };

  const drawMemoryIcon = (ctx, x, y, size) => {
    ctx.save();
    ctx.strokeStyle = COLORS.accent;
    ctx.lineWidth = 2;

    ctx.strokeRect(x, y + size * 0.2, size, size * 0.6);
    
    ctx.fillStyle = COLORS.background;
    ctx.fillRect(x + size * 0.45, y + size * 0.2, size * 0.1, size * 0.15);
    
    ctx.fillStyle = COLORS.accent;
    for (let i = 0; i < 5; i++) {
      ctx.fillRect(x + size * 0.15 + i * size * 0.15, y + size * 0.75, size * 0.08, size * 0.15);
    }

    ctx.restore();
  };

  const drawLatencyGraph = (ctx, x, y, width, height, data, frame) => {
    ctx.save();

    ctx.fillStyle = COLORS.cardBg;
    ctx.fillRect(x, y, width, height);

    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const yPos = y + (height / 4) * i;
      ctx.beginPath();
      ctx.moveTo(x, yPos);
      ctx.lineTo(x + width, yPos);
      ctx.stroke();
    }

    const offset = (frame % 10) * 2;
    const shiftedData = [...data.slice(offset % data.length), ...data.slice(0, offset % data.length)];

    ctx.strokeStyle = COLORS.chartLine;
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    const maxLatency = Math.max(...data);
    const minLatency = Math.min(...data);
    const range = maxLatency - minLatency || 1;

    shiftedData.forEach((value, i) => {
      const xPos = x + (width / (shiftedData.length - 1)) * i;
      const yPos = y + height - ((value - minLatency) / range) * height * 0.8 - height * 0.1;

      if (i === 0) {
        ctx.moveTo(xPos, yPos);
      } else {
        ctx.lineTo(xPos, yPos);
      }
    });

    ctx.stroke();

    ctx.lineTo(x + width, y + height);
    ctx.lineTo(x, y + height);
    ctx.closePath();
    
    const gradient = ctx.createLinearGradient(0, y, 0, y + height);
    gradient.addColorStop(0, 'rgba(139, 92, 246, 0.3)');
    gradient.addColorStop(1, 'rgba(139, 92, 246, 0.05)');
    ctx.fillStyle = gradient;
    ctx.fill();

    ctx.restore();
  };

  const drawProgressBar = (ctx, x, y, width, height, percentage, color) => {
    ctx.save();

    ctx.fillStyle = COLORS.grid;
    ctx.fillRect(x, y, width, height);

    const fillWidth = (width * percentage) / 100;
    const gradient = ctx.createLinearGradient(x, 0, x + fillWidth, 0);
    gradient.addColorStop(0, color);
    gradient.addColorStop(1, color + 'CC');
    ctx.fillStyle = gradient;
    ctx.fillRect(x, y, fillWidth, height);

    ctx.strokeStyle = COLORS.secondary;
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, width, height);

    ctx.restore();
  };

  for (let frame = 0; frame < FRAMES; frame++) {
    ctx.save();

    ctx.fillStyle = COLORS.background;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 22px Arial';
    ctx.fillText('Server Statistics Dashboard', 25, 35);

    ctx.fillStyle = COLORS.secondary;
    ctx.font = '13px Arial';
    ctx.fillText('Real-time Performance Metrics', 25, 53);

    ctx.fillStyle = COLORS.cardBg;
    ctx.fillRect(15, 70, 270, 265);
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    ctx.strokeRect(15, 70, 270, 265);

    drawServerIcon(ctx, 28, 83, 28);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 15px Arial';
    ctx.fillText('Node.js Environment', 65, 97);
    
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '12px Arial';
    ctx.fillText(`Version: ${metrics.nodeVersion}`, 65, 113);
    ctx.fillText(`Platform: ${metrics.platform} (${metrics.arch})`, 65, 128);

    drawClockIcon(ctx, 28, 148, 26);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Uptime', 63, 163);
    ctx.fillStyle = COLORS.success;
    ctx.font = 'bold 15px Arial';
    ctx.fillText(metrics.uptime, 63, 180);

    drawCPUIcon(ctx, 28, 200, 26);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('CPU Usage', 63, 215);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '12px Arial';
    ctx.fillText(`${metrics.cpuUsage}%`, 63, 230);
    drawProgressBar(ctx, 140, 220, 130, 10, parseFloat(metrics.cpuUsage), COLORS.accent);

    drawMemoryIcon(ctx, 28, 252, 26);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Memory Usage', 63, 267);
    ctx.fillStyle = COLORS.secondary;
    ctx.font = '12px Arial';
    ctx.fillText(`${metrics.usedMemGB}GB / ${metrics.totalMemGB}GB`, 63, 282);
    drawProgressBar(ctx, 28, 297, 242, 10, parseFloat(metrics.memUsagePercent), COLORS.success);

    ctx.fillStyle = COLORS.cardBg;
    ctx.fillRect(300, 70, 285, 265);
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    ctx.strokeRect(300, 70, 285, 265);

    drawSignalIcon(ctx, 313, 83, 26, frame);
    ctx.fillStyle = COLORS.primary;
    ctx.font = 'bold 15px Arial';
    ctx.fillText('Network Latency', 348, 97);
    
    ctx.fillStyle = COLORS.accent;
    ctx.font = 'bold 19px Arial';
    ctx.fillText(`${metrics.currentLatency} ms`, 348, 118);

    drawLatencyGraph(ctx, 313, 135, 260, 185, latencyHistory, frame);

    ctx.restore();
    encoder.addFrame(ctx);
  }

  encoder.finish();
  return encoder.out.getData();
}