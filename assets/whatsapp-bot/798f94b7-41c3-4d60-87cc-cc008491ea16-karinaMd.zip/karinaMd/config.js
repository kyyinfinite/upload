import {
  isOwnerDb,
  isPremiumDb,
  isBannedDb,
} from './src/lib/role-db.js'

const config = {
  info: {
    website: 'https://example.com',
    grupwa:  'https://chat.whatsapp.com/xxxx',
    github:  'https://github.com/yourusername/yourbot',
    docs:    'https://docs.example.com',
  },

  owner: {
    name:   'KyyInfinite',
    number: ['6283815201912'],
    email:  'kyyinfinite@gmail.com', //opsional
  },

  session: {
    pairingNumber:  '6283815201912',
    usePairingCode: true,
    autoReconnect:  true,
    maxReconnectAttempts: 10,
    reconnectInterval: 5000,
  },

  bot: {
    name:      'æ-KARINA', //NAMA BOT KALIAN
    version:   '1.0.1',
    developer: 'KyyInfinire',
    timezone:  'Asia/Jakarta',
    language:  'id',
  },
  
    assets: {
    menuThumbnail: 'https://files.catbox.moe/tz9wtc.png',
    storeProductImage: 'https://files.catbox.moe/bkgro8.jpeg', //THUMBNAIL UNTUK PRODUK COSTUMER SERVICE
  },
  saluran: {
    store: '120363409140476254@newsletter', //AUTO UPDATE TESTIMONI DAN INFO STOCK
    id:   '120363428189885113@newsletter',
    name: 'KYYINFINITE',
    link: 'https://example.com',
  },

  mode: 'public',

  command: {
    prefix:           ['.', '!', '/', '#'],
    caseSensitive:    false,
    spaceAfterPrefix: false,
    allowNoPrefix:    false,
  },

  cooldown: {
    default:  3,
    owner:    0,
    premium:  1,
    group:    5,
    ai:       10,
    download: 15,
  },

  limits: {
    maxDownloadSize:  100 * 1024 * 1024,
    maxImageSize:     10 * 1024 * 1024,
    maxVideoSize:     50 * 1024 * 1024,
    maxAudioSize:     20 * 1024 * 1024,
    maxDocumentSize:  25 * 1024 * 1024,
    freeUserLimit:    10,
    premiumUserLimit: 100,
  },

  ai: {
    provider: 'groq',
    defaultModel: 'llama-3.3-70b-versatile',
    maxTokens: 4096,
    temperature: 0.7,
    timeout: 60000,
  },


// GROQ KEY, GAPERLU KALIAN APA APA IN!!!
  groq: {
    keys: [
      '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',
      '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',
      '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',
      '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',
      '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',
    ].filter(k => k && !k.includes('placeholder')),
    'groq-manage': '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',
    fallbackModels: [
      'llama-3.3-70b-versatile',
      'llama-3.1-70b-versatile',
      'llama-3.1-8b-instant',
      'gemma2-9b-it',
      'mixtral-8x7b-32768',
    ],
  },

  //========telegram bot configuration
//TIDAK PERLU KALIAN ISI SAMA SEKALI
  telegram: {
  enabled:          true,
  
  botToken:         '',
  ownerId:          '',
  
  // Optional
  backupChatId:     '',
  devChatId:        '',

  // Notify settings
  ownerKey:         'main',
  ownerKeys:        ['main'],
  notifyConnection: true,
  notifyCommands:   false,
  notifyErrors:     true,
  notifyOrders:     true,
},

  discord: {
    enabled:    false,
    webhookUrl: '',
    notify: {
      connection: true,
      errors:     true,
      orders:     true,
    },
  },


//UBAH SESUAI KEMAUAN
messages: {
  // command disabled
  commandDisabled: '❌ Fitur ini sedang dinonaktifkan.',

  ownerOnly: '❌ *Akses Ditolak*\n\n> Hanya owner yang dapat menggunakan fitur ini.',
  premiumOnly: '❌ *Akses Ditolak*\n\n> Hanya member premium yang dapat menggunakan fitur ini.\n> Hubungi owner untuk info premium.',
  groupOnly: '❌ Fitur ini hanya dapat digunakan di dalam grup.',
  privateOnly: '❌ Fitur ini hanya dapat digunakan di chat pribadi.',
  adminOnly: '❌ Hanya admin grup yang dapat menggunakan fitur ini.',
  botAdminRequired: '❌ *Bot Bukan Admin!* Jadikan bot sebagai admin grup terlebih dahulu.',
  cooldown: (remaining) => `⏳ Tunggu *${remaining}* detik lagi untuk menggunakan command ini.`,

  handlerError: (cmd, err) => `❌ Command *${cmd}* error: ${err.message}`,

  banned: null,
},

  database: {
    path:       './storage/data/database',
    autoSave:   true,
    saveDelay:  1500,
    backup: {
      enabled:  true,
      interval: 24 * 60 * 60 * 1000,
      maxBackups: 7,
      path:     './storage/backups/database',
    },
  },

  storage: {
    root:      './storage',
    temp:      './storage/.tmp',
    logs:      './storage/logs',
    backups:   './storage/backups',
    cache:     './storage/cache',
    media:     './storage/media',
    maxAge: {
      temp:    30 * 60 * 1000,
      cache:   7 * 24 * 60 * 60 * 1000,
      logs:    30 * 24 * 60 * 60 * 1000,
    },
  },

  features: {
    antilink:      true,
    antinsfw:      true,
    antitoxic:     true,
    antibot:       true,
    autoread:      false,
    autorecording: false,
    autotyping:    false,
    autostatus:    false,
    anticall:      true,
    groupOnly:     false,
    privateOnly:   false,
    store:         true,
    games:         true,
    downloadMenu:  true,
  },

  plugins: {
    autoload:      true,
    hotReload:     true,
    debounce:      300,
    loadTimeout:   5000,
    disabled:      [],
    disabledCategories: [],
  },

  security: {
    maxWarnings:     3,
    warnExpiry:      24 * 60 * 60 * 1000,
    autoKick:        true,
    blockUnknown:    false,
    verifyUsers:     false,
    captcha:         false,
    rateLimit: {
      enabled:       true,
      maxRequests:   30,
      windowMs:      60 * 1000,
      blockDuration: 5 * 60 * 1000,
    },

    botDetection: {
      enabled: true,

      scoring: {
        forwardingScoreHigh: 20,   
        forwardingScoreMax:  40,  
        newsletter:          20,  
        botMetadata:         30,   
        statusGroup:         10,  
        protocolMessage:     30,   // protocolMessage / senderKeyDistributionMessage
        quotedBot:           15,   // Reply ke pesan bot sendiri (loop)
        pushNameSuspicious:  10,   // PushName mengandung kata 'bot','admin', dll.
        unknownJid:          10,   // JID sumber bukan @g.us / @s.whatsapp.net
        deviceIdAnomaly:     15,   // Device ID > maxAllowedDeviceId
        deviceIdChange:      20,   // Device berganti dalam 1 window
      },

      // Ambang batas aksi berdasarkan total skor
      thresholds: {
        warn:   20,   // Skor ≥ 20  → kirim peringatan ke user (tapi tetap proses pesan)
        delete: 40,   // Skor ≥ 40  → hapus pesan + hentikan pemrosesan
        kick:   60,   // Skor ≥ 60  → tendang dari grup
        ban:    80,   // Skor ≥ 80  → ban permanen ke database
      },

      // Toggle aksi individual
      actions: {
        log:            true,   // Tulis ke storage/logs/security.log
        warnUser:       true,   // Kirim pesan peringatan ke user
        deleteMessage:  true,   // Hapus pesan mencurigakan
        kickFromGroup:  true,   // Tendang dari grup
        banUser:        true,   // Ban permanen
        notifyOwner:    true,   // Notif ke nomor owner pertama
      },

      // Pengaturan cooldown & rate
      cooldown: {
        warnCooldown:         5 * 60 * 1000, 
        messageWindow:        60 * 1000,      
        maxMessagesPerWindow: 15,            
      },
      deviceId: {
        maxAllowedDeviceId: 5,      
        allowUnknown:       false, 
      },
      suspiciousPushNames: [
        'bot', 'admin', 'support', 'official', 'server',
        'api', 'system', 'robot', 'auto', 'spam',
      ],
    },
  },

  errorHandler: {
    enabled:           true,
    autoAnalyze:       true,
    analyzeDebounce:   5000,
    maxPendingErrors:  10,
    notifyOnCritical:  true,
    exitOnUncaught:    false,
    logStackTrace:     true,
    ignoredErrors: [
      'write EOF',
      'ECONNRESET',
      'EPIPE',
      'ETIMEDOUT',
      'ENOTFOUND',
      'ECONNREFUSED',
      'EHOSTUNREACH',
      'EADDRINUSE',
    ],
  },

  performance: {
    enableMetrics:  true,
    logInterval:    60 * 60 * 1000,
    maxMemoryMB:    500,
    maxCPUPercent:  80,
    autoRestart: {
      enabled:      false,
      onHighMemory: true,
      onHighCPU:    false,
      threshold:    90,
    },
  },

  api: {
    timeout: 30000,
    retries: 3,
    retryDelay: 1000,
    maxConcurrent: 10,
  },

  logger: {
    level:       process.env.LOG_LEVEL || 'info',
    colorize:    true,
    timestamp:   true,
    saveToFile:  true,
    maxFileSize: 10 * 1024 * 1024,
    maxFiles:    5,
  },

  maintenance: {
    enabled:  false,
    message:  'Bot sedang dalam maintenance. Coba lagi nanti.',
    allowedUsers: [],
  },

  beta: {
    enabled:  false,
    features: [],
    allowedUsers: [],
  },
}

function normNum(jid) {
  return String(jid || '').split(':')[0].split('@')[0].replace(/[^0-9]/g, '')
}

function matchNum(a, b) {
  return !!(a && b && (a === b || a.endsWith(b) || b.endsWith(a)))
}

config.isOwner = function (jid) {
  const num = normNum(jid)
  if (!num) return false

  const inConfig = config.owner.number.some(o => matchNum(num, normNum(o)))
  if (inConfig) return true

  return isOwnerDb(num)
}

config.isPremium = function (jid) {
  if (config.isOwner(jid)) return true
  return isPremiumDb(jid)
}

config.isBanned = function (jid) {
  if (config.isOwner(jid)) return false
  return isBannedDb(jid)
}

config.isMaintenanceMode = function () {
  return config.maintenance.enabled
}

config.isAllowedInMaintenance = function (jid) {
  if (config.isOwner(jid)) return true
  const num = normNum(jid)
  return config.maintenance.allowedUsers.some(u => matchNum(num, normNum(u)))
}

config.isBetaTester = function (jid) {
  if (!config.beta.enabled) return false
  if (config.isOwner(jid)) return true
  const num = normNum(jid)
  return config.beta.allowedUsers.some(u => matchNum(num, normNum(u)))
}

config.hasBetaFeature = function (featureName) {
  return config.beta.enabled && config.beta.features.includes(featureName)
}

config.getStoragePath = function (type) {
  const paths = {
    root:    config.storage.root,
    temp:    config.storage.temp,
    logs:    config.storage.logs,
    backups: config.storage.backups,
    cache:   config.storage.cache,
    media:   config.storage.media,
  }
  return paths[type] || config.storage.root
}

config.getCooldown = function (context) {
  if (config.isOwner(context.sender)) return config.cooldown.owner
  if (config.isPremium(context.sender)) return config.cooldown.premium
  if (context.isGroup) return config.cooldown.group
  return config.cooldown.default
}

config.getUserLimit = function (jid) {
  if (config.isOwner(jid)) return Infinity
  if (config.isPremium(jid)) return config.limits.premiumUserLimit
  return config.limits.freeUserLimit
}

config.validateFileSize = function (size, type) {
  const limits = {
    image:    config.limits.maxImageSize,
    video:    config.limits.maxVideoSize,
    audio:    config.limits.maxAudioSize,
    document: config.limits.maxDocumentSize,
    default:  config.limits.maxDownloadSize,
  }
  const maxSize = limits[type] || limits.default
  return size <= maxSize
}

config.isFeatureEnabled = function (featureName) {
  return config.features[featureName] !== false
}

config.isPluginDisabled = function (pluginName) {
  return config.plugins.disabled.includes(pluginName)
}

config.isCategoryDisabled = function (categoryName) {
  return config.plugins.disabledCategories.includes(categoryName)
}

config.shouldAutoRestart = function (memoryUsage, cpuUsage) {
  if (!config.performance.autoRestart.enabled) return false
  const memPercent = (memoryUsage / (config.performance.maxMemoryMB * 1024 * 1024)) * 100
  const threshold  = config.performance.autoRestart.threshold

  if (config.performance.autoRestart.onHighMemory && memPercent >= threshold) return true
  if (config.performance.autoRestart.onHighCPU && cpuUsage >= threshold) return true

  return false
}

config.merge = function (updates) {
  const merge = (target, source) => {
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        target[key] = target[key] || {}
        merge(target[key], source[key])
      } else {
        target[key] = source[key]
      }
    }
  }
  merge(config, updates)
  return config
}

config.export = function () {
  const safeConfig = JSON.parse(JSON.stringify(config))

  if (safeConfig.groq?.keys) {
    safeConfig.groq.keys = safeConfig.groq.keys.map(k => k.slice(0, 8) + '...')
  }
  if (safeConfig.groq?.['groq-manage']) {
    safeConfig.groq['groq-manage'] = safeConfig.groq['groq-manage'].slice(0, 8) + '...'
  }
  if (safeConfig.groq?.['groq-ai']) {
    safeConfig.groq['groq-ai'] = safeConfig.groq['groq-ai'].slice(0, 8) + '...'
  }

  return safeConfig
}

config.validate = function () {
  const errors = []

  if (!config.owner.number || !config.owner.number.length) {
    errors.push('owner.number tidak boleh kosong')
  }

  if (!config.session.pairingNumber) {
    errors.push('session.pairingNumber tidak boleh kosong')
  }

  if (!config.groq.keys || !config.groq.keys.length) {
    errors.push('groq.keys tidak boleh kosong (minimal 1 key)')
  }

  if (!['public', 'self'].includes(config.mode)) {
    errors.push('mode harus "public" atau "self"')
  }

  if (config.cooldown.default < 0) {
    errors.push('cooldown.default harus >= 0')
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

if (process.env.NODE_ENV !== 'production') {
  const validation = config.validate()
  if (!validation.valid) {
    console.error('⚠️  Config validation errors:')
    validation.errors.forEach(err => console.error(`   - ${err}`))
  }
}

export default config