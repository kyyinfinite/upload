import type { WASocket, WAMessage } from '@kyyinfinite/baileys';

export type MediaInput = string | Buffer;

export interface ButtonV2BuildOptions {
  [key: string]: unknown;
}

export declare class ButtonV2 {
  constructor(client: WASocket);

  // Wrapper API
  title(v: string): this;
  subtitle(v: string): this;
  body(v: string): this;
  footer(v: string): this;
  thumbnail(path: MediaInput): this;
  media(obj: Record<string, unknown>): this;
  payload(obj: Record<string, unknown>): this;
  context(obj: Record<string, unknown>): this;
  button(displayText: string, buttonId: string): this;
  rawButton(obj: Record<string, unknown>): this;

  // Engine methods (inherited, also available)
  setTitle(v: string): this;
  setSubtitle(v: string): this;
  setBody(v: string): this;
  setFooter(v: string): this;
  setThumbnail(path: MediaInput): this;
  setMedia(obj: Record<string, unknown>): this;
  addPayload(obj: Record<string, unknown>): this;
  setContextInfo(obj: Record<string, unknown>): this;
  addButton(displayText: string, buttonId: string): this;
  addRawButton(obj: Record<string, unknown>): this;

  build(jid: string, opts?: ButtonV2BuildOptions): Promise<WAMessage>;
  send(jid: string, opts?: ButtonV2BuildOptions): Promise<void>;
}
