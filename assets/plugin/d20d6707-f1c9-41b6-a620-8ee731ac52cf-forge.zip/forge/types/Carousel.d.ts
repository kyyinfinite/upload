import type { WASocket, WAMessage } from '@kyyinfinite/baileys';
import type { ButtonCard } from './Button.js';

export interface CarouselBuildOptions {
  [key: string]: unknown;
}

export declare class Carousel {
  constructor(client: WASocket);

  // Wrapper API
  body(v: string): this;
  footer(v: string): this;
  payload(obj: Record<string, unknown>): this;
  context(obj: Record<string, unknown>): this;
  /** Accepts a single ButtonCard or an array. Each card must have hasMediaAttachment: true. */
  card(c: ButtonCard | ButtonCard[]): this;

  // Engine methods (inherited, also available)
  setBody(v: string): this;
  setFooter(v: string): this;
  addPayload(obj: Record<string, unknown>): this;
  setContextInfo(obj: Record<string, unknown>): this;
  addCard(c: ButtonCard | ButtonCard[]): this;

  build(jid: string, opts?: CarouselBuildOptions): WAMessage;
  send(jid: string, opts?: CarouselBuildOptions): Promise<void>;
}
