import type { WASocket } from '@kyyinfinite/baileys';

export interface InlineEntityOptions {
  hyperlink?: boolean;
  citation?: boolean;
  latex?: boolean;
  /** When false the text is returned unchanged with empty entity arrays. */
  extract?: boolean;
}

export interface ExtractIEResult {
  text: string;
  ie: Array<{
    type: 'hyperlink' | 'citation' | 'latex';
    key: string;
    url: string;
    text?: string;
    trusted?: boolean;
    width?: number;
    height?: number;
    font_height?: number;
    padding?: number;
  }>;
  inline_entities: unknown[];
}

export interface ResolveMediaOptions {
  resolveUrl?: boolean;
  resolveWAUrl?: boolean;
  result?: 'url' | 'buffer' | 'base64';
  resize?: boolean;
  width?: number;
  height?: number;
}

export interface Mp4PreviewOptions {
  time?: number;
  width?: number;
  height?: number;
  result?: 'buffer' | 'base64';
  silent?: boolean;
}

export type MediaResolvable = string | Buffer | MediaResolvable[];

export declare class Toolkit {
  static extractIE(text: string, options?: InlineEntityOptions): ExtractIEResult;

  /** Resizes an image buffer using sharp. Returns a PNG buffer. */
  static resize(buffer: Buffer, x: number, y: number, fit?: string): Promise<Buffer>;

  /** Recursively resolves all Promises nested inside an object or array. */
  static waitAllPromises<T>(input: T): Promise<T>;

  /** Downloads a URL as a Buffer. Returns an empty Buffer on failure when silent. */
  static fetchBuffer(url: string, options?: RequestInit, config?: { silent?: boolean }): Promise<Buffer>;

  /**
   * Uploads a Buffer or URL to the WhatsApp CDN and returns the resulting CDN URL.
   * Uses the `@newsletter` JID for uploads.
   */
  static toUrl(client: WASocket, path: string | Buffer, mediaType: string): Promise<string>;

  /**
   * Master media resolver. Accepts a URL string, base64 string, Buffer, or
   * array of any of those. Handles optional resize and optional CDN upload.
   */
  static resolveMedia(
    client: WASocket,
    media: MediaResolvable,
    mediaType: string,
    options?: ResolveMediaOptions
  ): Promise<string | Buffer | string[] | Buffer[] | undefined>;

  /** Parses MP4 binary data to extract the duration in seconds. */
  static getMp4Duration(buffer: Buffer, config?: { silent?: boolean }): number;

  /** Extracts a frame from an MP4 buffer using ffmpeg. */
  static getMp4Preview(videoBuffer: Buffer, options?: Mp4PreviewOptions): Promise<Buffer | string>;
}
