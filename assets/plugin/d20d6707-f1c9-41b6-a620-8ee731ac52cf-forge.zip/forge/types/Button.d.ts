import type { WASocket, WAMessage } from '@kyyinfinite/baileys';

export type MediaInput = string | Buffer;

export interface ButtonCard {
  body: { text: string };
  footer: { text: string };
  header: {
    title: string;
    subtitle: string;
    hasMediaAttachment: boolean;
    [key: string]: unknown;
  };
  nativeFlowMessage: {
    messageParamsJson: string;
    buttons: Array<{ name: string; buttonParamsJson: string }>;
  };
}

export interface ButtonOptions {
  id?: string;
  [key: string]: unknown;
}

export interface ButtonBuildOptions {
  [key: string]: unknown;
}

export declare class Button {
  constructor(client: WASocket);

  // Wrapper API
  title(v: string): this;
  subtitle(v: string): this;
  body(v: string): this;
  footer(v: string): this;
  image(path: MediaInput, opts?: Record<string, unknown>): this;
  video(path: MediaInput, opts?: Record<string, unknown>): this;
  document(path: MediaInput, opts?: Record<string, unknown>): this;
  media(obj: Record<string, unknown>): this;
  params(obj: Record<string, unknown>): this;
  payload(obj: Record<string, unknown>): this;
  context(obj: Record<string, unknown>): this;
  reply(text: string, id: string, opts?: ButtonOptions): this;
  url(text: string, href: string, webview?: string, opts?: ButtonOptions): this;
  copy(text: string, code: string, opts?: ButtonOptions): this;
  call(text: string, id: string, opts?: ButtonOptions): this;
  reminder(text: string, id: string, opts?: ButtonOptions): this;
  cancelReminder(text: string, id: string, opts?: ButtonOptions): this;
  location(opts?: ButtonOptions): this;
  address(text: string, id: string, opts?: ButtonOptions): this;
  selection(title: string, opts?: Record<string, unknown>): this;
  section(title: string, highlight_label?: string): this;
  row(header: string, title: string, description: string, id: string): this;
  button(name: string, params?: Record<string, unknown>): this;
  clear(): this;

  // Engine methods (inherited, also available)
  setTitle(v: string): this;
  setSubtitle(v: string): this;
  setBody(v: string): this;
  setFooter(v: string): this;
  setImage(path: MediaInput, opts?: Record<string, unknown>): this;
  setVideo(path: MediaInput, opts?: Record<string, unknown>): this;
  setDocument(path: MediaInput, opts?: Record<string, unknown>): this;
  setMedia(obj: Record<string, unknown>): this;
  setParams(obj: Record<string, unknown>): this;
  addPayload(obj: Record<string, unknown>): this;
  setContextInfo(obj: Record<string, unknown>): this;
  addReply(text: string, id: string, opts?: ButtonOptions): this;
  addUrl(text: string, href: string, webview?: string, opts?: ButtonOptions): this;
  addCopy(text: string, code: string, opts?: ButtonOptions): this;
  addCall(text: string, id: string, opts?: ButtonOptions): this;
  addReminder(text: string, id: string, opts?: ButtonOptions): this;
  addCancelReminder(text: string, id: string, opts?: ButtonOptions): this;
  addLocation(opts?: ButtonOptions): this;
  addAddress(text: string, id: string, opts?: ButtonOptions): this;
  addSelection(title: string, opts?: Record<string, unknown>): this;
  makeSection(title: string, highlight_label?: string): this;
  makeRow(header: string, title: string, description: string, id: string): this;
  addButton(name: string, params?: Record<string, unknown>): this;
  clearButtons(): this;

  toCard(): Promise<ButtonCard>;
  build(jid: string, opts?: ButtonBuildOptions): Promise<WAMessage>;
  send(jid: string, opts?: ButtonBuildOptions): Promise<void>;

  static readonly paramsList: Record<string, unknown>;
}
