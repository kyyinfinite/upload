import type { WASocket, WAMessage, WAMessageKey } from '@kyyinfinite/baileys';
import type { Button } from './Button.js';
import type { ButtonV2 } from './ButtonV2.js';
import type { Carousel } from './Carousel.js';
import type { AIRich } from './AIRich.js';

export type MediaInput = string | Buffer;

export interface SendOptions {
  /** Quote an existing message. */
  quoted?: WAMessage;
  [key: string]: unknown;
}

export interface ImageSendOptions extends SendOptions {
  caption?: string;
  mimetype?: string;
}

export interface VideoSendOptions extends SendOptions {
  caption?: string;
  mimetype?: string;
  gifPlayback?: boolean;
}

export interface AudioSendOptions extends SendOptions {
  mimetype?: string;
  /** When true, sends as a voice note (PTT). */
  ptt?: boolean;
}

export interface DocumentSendOptions extends SendOptions {
  mimetype?: string;
  fileName?: string;
  caption?: string;
}

export interface LocationSendOptions {
  name?: string;
  address?: string;
  /** JPEG thumbnail buffer. */
  thumbnail?: Buffer;
  quoted?: WAMessage;
  [key: string]: unknown;
}

export interface ContactSendOptions {
  /** Display name shown above the contact card. Defaults to 'Contact'. */
  name?: string;
  quoted?: WAMessage;
  [key: string]: unknown;
}

export declare class Bot {
  constructor(client: WASocket);

  button(): Button;
  buttonV2(): ButtonV2;
  carousel(): Carousel;
  ai(): AIRich;

  text(jid: string, text: string, opts?: SendOptions): Promise<WAMessage | undefined>;
  image(jid: string, path: MediaInput, opts?: ImageSendOptions): Promise<WAMessage | undefined>;
  video(jid: string, path: MediaInput, opts?: VideoSendOptions): Promise<WAMessage | undefined>;
  audio(jid: string, path: MediaInput, opts?: AudioSendOptions): Promise<WAMessage | undefined>;
  document(jid: string, path: MediaInput, opts?: DocumentSendOptions): Promise<WAMessage | undefined>;
  sticker(jid: string, path: MediaInput, opts?: SendOptions): Promise<WAMessage | undefined>;
  location(jid: string, lat: number, lng: number, opts?: LocationSendOptions): Promise<WAMessage | undefined>;
  contact(jid: string, vcard: string, opts?: ContactSendOptions): Promise<WAMessage | undefined>;
  reply(jid: string, text: string, quoted: WAMessage, opts?: Record<string, unknown>): Promise<WAMessage | undefined>;
  react(jid: string, key: WAMessageKey, emoji: string): Promise<WAMessage | undefined>;
  delete(jid: string, key: WAMessageKey): Promise<WAMessage | undefined>;
  edit(jid: string, key: WAMessageKey, text: string): Promise<WAMessage | undefined>;
  /** Forwards a message with the "Forwarded" label. */
  forward(jid: string, message: WAMessage, opts?: Record<string, unknown>): Promise<WAMessage | undefined>;
  /** Copies a message without the "Forwarded" label. */
  copy(jid: string, message: WAMessage, opts?: Record<string, unknown>): Promise<WAMessage | undefined>;
}
