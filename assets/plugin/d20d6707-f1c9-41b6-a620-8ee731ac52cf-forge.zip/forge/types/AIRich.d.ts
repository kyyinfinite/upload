import type { WASocket, WAMessage } from '@kyyinfinite/baileys';
import type { InlineEntityOptions } from './Toolkit.js';

export type MediaInput = string | Buffer;

/** A single search source entry: [favicon_url, page_url, display_text] */
export type SourceItem = [string, string, string];

export interface TextOptions extends InlineEntityOptions {}

export interface ImageOptions {
  /** 0 = generated, 1 = loading, 2 = error */
  status?: number;
}

export interface VideoInput {
  url?: string;
  file_length?: number | Promise<number>;
  duration?: number | Promise<number>;
  thumbnail?: string | Buffer | Promise<string | Buffer>;
  mime_type?: string;
  [key: string]: unknown;
}

export interface VideoOptions {
  /** Automatically derive file_length, duration, and thumbnail from the buffer. */
  autoFill?: boolean;
  status?: number;
  mime_type?: string;
  file_length?: number;
  duration?: number;
  thumbnail?: string | Buffer;
}

export interface TableOptions extends InlineEntityOptions {}

export interface SuggestOptions {
  layout?: 'Single' | 'HScroll' | 'ActionRow';
  /** When true with multiple suggestions, renders as a horizontally scrollable list. */
  scroll?: boolean;
}

export interface ReelItem {
  _avatar?: string;
  _thumbnail?: string;
  title?: string;
  description?: string;
  views?: string | number;
  duration?: number;
  [key: string]: unknown;
}

export interface ProductItem {
  image?: string | Buffer;
  title?: string;
  price?: string;
  currency?: string;
  [key: string]: unknown;
}

export interface PostItem {
  profile_picture_url?: string;
  thumbnail_url?: string;
  footer_icon?: string;
  username?: string;
  caption?: string;
  [key: string]: unknown;
}

export interface AIRichBuildOptions {
  forwarded?: boolean;
  notification?: boolean;
  /** Include the base64-encoded unified response payload. Default: true. */
  includesUnifiedResponse?: boolean;
  /** Include submessages in the output. Default: true. */
  includesSubmessages?: boolean;
  quoted?: WAMessage;
  quotedParticipant?: string;
  [key: string]: unknown;
}

export interface TokenizerResult {
  codeBlock: Array<{ codeContent: string; highlightType: number }>;
  unified_codeBlock: Array<{ content: string; type: number }>;
}

export interface TableMetadataResult {
  title: string;
  rows: unknown[];
  unified_rows: unknown[];
}

export declare class AIRich {
  constructor(client: WASocket);

  // Wrapper API
  title(v: string): this;
  footer(v: string): this;
  payload(obj: Record<string, unknown>): this;
  context(obj: Record<string, unknown>): this;
  text(content: string, opts?: TextOptions): this;
  image(url: MediaInput | MediaInput[], opts?: ImageOptions): this;
  video(url: MediaInput | VideoInput | Array<MediaInput | VideoInput>, opts?: VideoOptions): this;
  table(data: string[][], opts?: TableOptions): this;
  code(language: string, code: string): this;
  source(sources: SourceItem | SourceItem[]): this;
  suggest(suggestion: string | string[], opts?: SuggestOptions): this;
  product(data: ProductItem | ProductItem[]): this;
  post(data: PostItem[]): this;
  reels(items: ReelItem[]): this;
  tip(text: string): this;
  section(obj: Record<string, unknown>): this;
  submessage(obj: Record<string, unknown>): this;

  // Engine methods (inherited, also available)
  setTitle(v: string): this;
  setFooter(v: string): this;
  addPayload(obj: Record<string, unknown>): this;
  setContextInfo(obj: Record<string, unknown>): this;
  addText(content: string, opts?: TextOptions): this;
  addImage(url: MediaInput | MediaInput[], opts?: ImageOptions): this;
  addVideo(url: MediaInput | VideoInput | Array<MediaInput | VideoInput>, opts?: VideoOptions): this;
  addTable(data: string[][], opts?: TableOptions): this;
  addCode(language: string, code: string): this;
  addSource(sources: SourceItem | SourceItem[]): this;
  addSuggest(suggestion: string | string[], opts?: SuggestOptions): this;
  addProduct(data: ProductItem | ProductItem[]): this;
  addPost(data: PostItem[]): this;
  addReels(items: ReelItem[]): this;
  addTip(text: string): this;
  addSection(obj: Record<string, unknown>): this;
  addSubmessage(obj: Record<string, unknown>): this;

  build(opts?: AIRichBuildOptions): Promise<Record<string, unknown>>;
  send(jid: string, opts?: AIRichBuildOptions): Promise<void>;

  static tokenizer(code: string, lang: string): TokenizerResult;
  static toTableMetadata(arr: string[][], opts?: TableOptions): TableMetadataResult;
  static newLayout(
    name: 'Single' | 'HScroll' | 'ActionRow',
    data: Record<string, unknown> | Record<string, unknown>[],
    extra?: Record<string, unknown>
  ): Record<string, unknown>;
}
