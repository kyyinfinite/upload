import { Button }   from '../builders/Button.js';
import { ButtonV2 } from '../builders/ButtonV2.js';
import { Carousel } from '../builders/Carousel.js';
import { AIRich }   from '../builders/AIRich.js';

/**
 * Normalises a path argument into the shape Baileys sendMessage expects.
 * A Buffer is passed as-is; anything else is treated as a URL.
 */
function toMedia(path) {
  return Buffer.isBuffer(path) ? path : { url: path };
}

/**
 * Separates the `quoted` field from the rest of the options so it can be
 * forwarded to the second argument of sendMessage rather than the content.
 */
function splitOpts(opts) {
  const { quoted, ...content } = opts;
  return { content, send: quoted ? { quoted } : {} };
}

export class Bot {
  #client;

  /**
   * @param {import('@kyyinfinite/baileys').WASocket} client - An active Baileys socket.
   */
  constructor(client) {
    if (!client) throw new Error('Socket is required');
    this.#client = client;
  }

  button()   { return new Button(this.#client); }
  buttonV2() { return new ButtonV2(this.#client); }
  carousel() { return new Carousel(this.#client); }
  ai()       { return new AIRich(this.#client); }

  text(jid, text, opts = {}) {
    const { content, send } = splitOpts(opts);
    return this.#client.sendMessage(jid, { text, ...content }, send);
  }

  image(jid, path, opts = {}) {
    const { content, send } = splitOpts(opts);
    return this.#client.sendMessage(jid, { image: toMedia(path), ...content }, send);
  }

  video(jid, path, opts = {}) {
    const { content, send } = splitOpts(opts);
    return this.#client.sendMessage(jid, { video: toMedia(path), ...content }, send);
  }

  audio(jid, path, opts = {}) {
    const { content, send } = splitOpts(opts);
    return this.#client.sendMessage(jid, { audio: toMedia(path), ...content }, send);
  }

  document(jid, path, opts = {}) {
    const { content, send } = splitOpts(opts);
    return this.#client.sendMessage(jid, { document: toMedia(path), ...content }, send);
  }

  sticker(jid, path, opts = {}) {
    const { content, send } = splitOpts(opts);
    return this.#client.sendMessage(jid, { sticker: toMedia(path), ...content }, send);
  }

  location(jid, lat, lng, { name, address, thumbnail, quoted, ...rest } = {}) {
    return this.#client.sendMessage(
      jid,
      {
        location: {
          degreesLatitude: lat,
          degreesLongitude: lng,
          ...(name      && { name }),
          ...(address   && { address }),
          ...(thumbnail && { jpegThumbnail: thumbnail }),
        },
        ...rest,
      },
      quoted ? { quoted } : {}
    );
  }

  contact(jid, vcard, { name = 'Contact', quoted, ...rest } = {}) {
    return this.#client.sendMessage(
      jid,
      { contacts: { displayName: name, contacts: [{ vcard }] }, ...rest },
      quoted ? { quoted } : {}
    );
  }

  reply(jid, text, quoted, opts = {}) {
    return this.#client.sendMessage(jid, { text }, { quoted, ...opts });
  }

  react(jid, key, emoji) {
    return this.#client.sendMessage(jid, { react: { text: emoji, key } });
  }

  delete(jid, key) {
    return this.#client.sendMessage(jid, { delete: key });
  }

  edit(jid, key, text) {
    return this.#client.sendMessage(jid, { edit: key, text });
  }

  /**
   * Forwards a message with the "Forwarded" label visible to the recipient.
   */
  forward(jid, message, opts = {}) {
    return this.#client.copyNForward(jid, message, true, opts);
  }

  /**
   * Copies a message without the "Forwarded" label.
   */
  copy(jid, message, opts = {}) {
    return this.#client.copyNForward(jid, message, false, opts);
  }
}
