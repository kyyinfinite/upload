import { AIRich as EngineAIRich } from '../../_build-m.js';

export class AIRich extends EngineAIRich {
  title(v)          { return this.setTitle(v); }
  footer(v)         { return this.setFooter(v); }
  payload(obj)      { return this.addPayload(obj); }
  context(obj)      { return this.setContextInfo(obj); }
  text(t, opts)     { return this.addText(t, opts); }
  image(url, opts)  { return this.addImage(url, opts); }
  video(url, opts)  { return this.addVideo(url, opts); }
  table(t, opts)    { return this.addTable(t, opts); }
  code(lang, code)  { return this.addCode(lang, code); }
  source(s)         { return this.addSource(s); }
  suggest(s, opts)  { return this.addSuggest(s, opts); }
  product(d)        { return this.addProduct(d); }
  post(d)           { return this.addPost(d); }
  reels(items)      { return this.addReels(items); }
  tip(t)            { return this.addTip(t); }
  section(s)        { return this.addSection(s); }
  submessage(s)     { return this.addSubmessage(s); }
}
