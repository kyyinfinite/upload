import { ButtonV2 as EngineButtonV2 } from '../../_build-m.js';

export class ButtonV2 extends EngineButtonV2 {
  title(v)         { return this.setTitle(v); }
  subtitle(v)      { return this.setSubtitle(v); }
  body(v)          { return this.setBody(v); }
  footer(v)        { return this.setFooter(v); }
  thumbnail(path)  { return this.setThumbnail(path); }
  media(obj)       { return this.setMedia(obj); }
  payload(obj)     { return this.addPayload(obj); }
  context(obj)     { return this.setContextInfo(obj); }
  button(text, id) { return this.addButton(text, id); }
  rawButton(obj)   { return this.addRawButton(obj); }
}
