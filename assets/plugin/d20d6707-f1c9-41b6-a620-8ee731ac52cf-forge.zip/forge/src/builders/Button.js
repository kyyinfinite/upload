import { Button as EngineButton } from '../../_build-m.js';

export class Button extends EngineButton {
  title(v)                        { return this.setTitle(v); }
  subtitle(v)                     { return this.setSubtitle(v); }
  body(v)                         { return this.setBody(v); }
  footer(v)                       { return this.setFooter(v); }
  image(path, opts)               { return this.setImage(path, opts); }
  video(path, opts)               { return this.setVideo(path, opts); }
  document(path, opts)            { return this.setDocument(path, opts); }
  media(obj)                      { return this.setMedia(obj); }
  params(obj)                     { return this.setParams(obj); }
  payload(obj)                    { return this.addPayload(obj); }
  context(obj)                    { return this.setContextInfo(obj); }
  reply(text, id, opts)           { return this.addReply(text, id, opts); }
  url(text, href, webview, opts)  { return this.addUrl(text, href, webview, opts); }
  copy(text, code, opts)          { return this.addCopy(text, code, opts); }
  call(text, id, opts)            { return this.addCall(text, id, opts); }
  reminder(text, id, opts)        { return this.addReminder(text, id, opts); }
  cancelReminder(text, id, opts)  { return this.addCancelReminder(text, id, opts); }
  location(opts)                  { return this.addLocation(opts); }
  address(text, id, opts)         { return this.addAddress(text, id, opts); }
  selection(title, opts)          { return this.addSelection(title, opts); }
  section(title, hl)              { return this.makeSection(title, hl); }
  row(header, title, desc, id)    { return this.makeRow(header, title, desc, id); }
  button(name, p)                 { return this.addButton(name, p); }
  clear()                         { return this.clearButtons(); }
}
