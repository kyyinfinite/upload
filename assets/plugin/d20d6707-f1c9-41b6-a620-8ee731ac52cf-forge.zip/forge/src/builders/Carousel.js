import { Carousel as EngineCarousel } from '../../_build-m.js';

export class Carousel extends EngineCarousel {
  body(v)      { return this.setBody(v); }
  footer(v)    { return this.setFooter(v); }
  payload(obj) { return this.addPayload(obj); }
  context(obj) { return this.setContextInfo(obj); }
  card(c)      { return this.addCard(c); }
}
