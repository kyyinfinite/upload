import { Bot } from '@kyyinfinite/forge';

export async function sendReplyButtons(bot, jid) {
  await bot.button()
    .title('Quick Actions')
    .body('What would you like to do?')
    .footer('Tap a button to continue')
    .image('https://example.com/banner.jpg')
    .reply('Track my order', 'action_track')
    .reply('Contact support', 'action_support')
    .reply('View my account', 'action_account')
    .send(jid);
}

export async function sendCtaButtons(bot, jid) {
  await bot.button()
    .body('Ready to get started?')
    .footer('Limited time offer')
    .url('Open website', 'https://example.com', 'FULL')
    .copy('Copy promo code', 'LUMINA2025')
    .call('Call sales', '+15550001234')
    .send(jid);
}

export async function sendSelectionList(bot, jid) {
  await bot.button()
    .body('Browse our catalog')
    .footer('Select a category to explore')
    .selection('Open catalog')
      .section('Electronics')
        .row('', 'Phones', 'Latest models and deals', 'cat_phones')
        .row('', 'Laptops', 'Work and gaming machines', 'cat_laptops')
        .row('', 'Accessories', 'Cases, cables, and more', 'cat_accessories')
      .section('Clothing')
        .row('', 'Men', "Men's collection", 'cat_men')
        .row('', 'Women', "Women's collection", 'cat_women')
        .row('', 'Kids', "Children's clothing", 'cat_kids')
    .send(jid);
}

export async function sendVideoButton(bot, jid) {
  await bot.button()
    .title('New product launch')
    .body('Watch the reveal and shop now.')
    .footer('Available for 24 hours only')
    .video('https://example.com/launch.mp4')
    .reply('Shop now', 'shop')
    .url('See full video', 'https://youtube.com/watch?v=example', 'FULL')
    .send(jid);
}

// Demo
async function main(sock) {
  const bot = new Bot(sock);
  const jid = '1234567890@s.whatsapp.net';

  await sendReplyButtons(bot, jid);
  await sendCtaButtons(bot, jid);
  await sendSelectionList(bot, jid);
  await sendVideoButton(bot, jid);
}
