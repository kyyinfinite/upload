import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@kyyinfinite/baileys';
import { Bot } from '@kyyinfinite/forge';

function extractButtonResponse(msg) {
  return (
    msg.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson
      ? JSON.parse(msg.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson)
      : null
  );
}

function extractText(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    ''
  );
}

async function sendMainMenu(bot, jid) {
  await bot.button()
    .title('Lumina Demo Bot')
    .body('Welcome! Choose an option to continue.')
    .footer('Powered by @kyyinfinite/forge')
    .reply('Interactive Buttons', 'demo_button')
    .reply('AI Rich Response', 'demo_ai')
    .reply('Carousel', 'demo_carousel')
    .reply('Media', 'demo_media')
    .send(jid);
}

async function sendDemoButton(bot, jid) {
  await bot.button()
    .title('Button Demo')
    .body('Here are all available button types.')
    .image('https://example.com/demo.jpg')
    .reply('Quick Reply', 'qr_demo')
    .url('Open URL', 'https://example.com', 'FULL')
    .copy('Copy Code', 'DEMO123')
    .call('Call Demo', '+15550000000')
    .send(jid);
}

async function sendDemoAI(bot, jid) {
  await bot.ai()
    .title('AI Demo')
    .text('This is a **rich AI response** with multiple content types.')
    .code('javascript', `const hello = () => console.log('Hello, Lumina!');`)
    .table([
      ['Feature', 'Status'],
      ['Text',    '✓ Supported'],
      ['Code',    '✓ Supported'],
      ['Table',   '✓ Supported'],
      ['Image',   '✓ Supported'],
      ['Video',   '✓ Supported'],
    ])
    .suggest(['More examples', 'Back to menu'])
    .send(jid);
}

async function sendDemoCarousel(bot, jid) {
  const cards = await Promise.all([
    bot.button()
      .title('Card One')
      .body('First card in the carousel.')
      .image('https://example.com/card1.jpg')
      .reply('Select', 'select_1')
      .toCard(),
    bot.button()
      .title('Card Two')
      .body('Second card in the carousel.')
      .image('https://example.com/card2.jpg')
      .reply('Select', 'select_2')
      .toCard(),
    bot.button()
      .title('Card Three')
      .body('Third card in the carousel.')
      .image('https://example.com/card3.jpg')
      .reply('Select', 'select_3')
      .toCard(),
  ]);

  await bot.carousel()
    .body('Scroll to see all cards')
    .card(cards)
    .send(jid);
}

async function sendDemoMedia(bot, jid) {
  await bot.image(jid, 'https://example.com/photo.jpg', { caption: 'A sample image' });
  await bot.text(jid, 'Media demo complete. Type "menu" to go back.');
}

async function handleButtonResponse(bot, jid, response) {
  const id = response?.id;

  if (id === 'demo_button') return sendDemoButton(bot, jid);
  if (id === 'demo_ai')     return sendDemoAI(bot, jid);
  if (id === 'demo_carousel') return sendDemoCarousel(bot, jid);
  if (id === 'demo_media')  return sendDemoMedia(bot, jid);

  await bot.text(jid, `Button response: ${id}`);
}

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('auth');
  const sock = makeWASocket({ auth: state, printQRInTerminal: true });
  const bot = new Bot(sock);

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'close') {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) start();
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const text = extractText(msg).toLowerCase().trim();
    const buttonResponse = extractButtonResponse(msg);

    if (buttonResponse) {
      await handleButtonResponse(bot, jid, buttonResponse);
      return;
    }

    if (text === 'menu' || text === 'start') {
      await sendMainMenu(bot, jid);
      return;
    }

    await bot.text(jid, 'Send "menu" to see the demo options.');
  });
}

start();
