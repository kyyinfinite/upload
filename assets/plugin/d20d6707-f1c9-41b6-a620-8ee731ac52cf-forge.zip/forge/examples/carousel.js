import { Bot } from '@kyyinfinite/forge';

async function buildProductCard(bot, { title, description, price, imageUrl, id }) {
  return bot.button()
    .title(title)
    .body(description)
    .footer(price)
    .image(imageUrl)
    .reply('Add to cart', `cart_${id}`)
    .url('View details', `https://example.com/products/${id}`, 'FULL')
    .toCard();
}

export async function sendProductCarousel(bot, jid) {
  const products = [
    {
      id: '1',
      title: 'Nike Air Max 90',
      description: 'Classic streetwear comfort with modern cushioning.',
      price: '$129.99',
      imageUrl: 'https://example.com/products/shoe1.jpg',
    },
    {
      id: '2',
      title: 'Adidas Ultraboost 23',
      description: 'Energy-returning midsole for long-distance runners.',
      price: '$189.99',
      imageUrl: 'https://example.com/products/shoe2.jpg',
    },
    {
      id: '3',
      title: 'New Balance 990v6',
      description: 'Made in USA. Premium leather and mesh upper.',
      price: '$174.99',
      imageUrl: 'https://example.com/products/shoe3.jpg',
    },
  ];

  // Build all cards (uploads media in parallel)
  const cards = await Promise.all(products.map(p => buildProductCard(bot, p)));

  await bot.carousel()
    .body('Top picks for you this week')
    .card(cards)
    .send(jid);
}

export async function sendNewsCarousel(bot, jid) {
  const articles = [
    {
      headline: 'AI Breakthrough',
      summary: 'Researchers achieve new milestone in language understanding.',
      imageUrl: 'https://example.com/news/ai.jpg',
      url: 'https://example.com/news/ai-breakthrough',
    },
    {
      headline: 'Climate Report 2025',
      summary: 'New data shows accelerating change in global temperatures.',
      imageUrl: 'https://example.com/news/climate.jpg',
      url: 'https://example.com/news/climate-2025',
    },
  ];

  const cards = await Promise.all(
    articles.map(a =>
      bot.button()
        .title(a.headline)
        .body(a.summary)
        .image(a.imageUrl)
        .url('Read article', a.url, 'FULL')
        .toCard()
    )
  );

  await bot.carousel()
    .body("Today's top stories")
    .card(cards)
    .send(jid);
}

// Demo
async function main(sock) {
  const bot = new Bot(sock);
  const jid = '1234567890@s.whatsapp.net';

  await sendProductCarousel(bot, jid);
  await sendNewsCarousel(bot, jid);
}
