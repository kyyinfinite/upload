import { Bot } from '@kyyinfinite/forge';

export async function sendBasicButtons(bot, jid) {
  await bot.buttonV2()
    .body('Which option do you prefer?')
    .footer('Choose one')
    .button('Option A', 'opt_a')
    .button('Option B', 'opt_b')
    .button('Option C', 'opt_c')
    .send(jid);
}

export async function sendButtonsWithThumbnail(bot, jid) {
  await bot.buttonV2()
    .body('Rate your last order')
    .footer('Your feedback helps us improve')
    .thumbnail('https://example.com/order-thumb.jpg')
    .button('😍 Excellent', 'rate_5')
    .button('😊 Good', 'rate_4')
    .button('😐 Okay', 'rate_3')
    .send(jid);
}

// Demo
async function main(sock) {
  const bot = new Bot(sock);
  const jid = '1234567890@s.whatsapp.net';

  await sendBasicButtons(bot, jid);
  await sendButtonsWithThumbnail(bot, jid);
}
