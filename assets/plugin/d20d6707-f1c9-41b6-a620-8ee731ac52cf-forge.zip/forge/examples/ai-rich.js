import { Bot } from '@kyyinfinite/forge';

export async function sendTextResponse(bot, jid) {
  await bot.ai()
    .title('Lumina AI')
    .text('Here is a quick summary of your request.')
    .text(
      'For more details, visit [the documentation](https://example.com/docs)' +
      ' or check the [Wikipedia article](https://wikipedia.org/wiki/Artificial_intelligence).'
    )
    .tip('Answers are AI-generated and may contain errors.')
    .suggest(['Tell me more', 'Start over', 'Help'])
    .send(jid);
}

export async function sendCodeResponse(bot, jid) {
  await bot.ai()
    .title('Code Assistant')
    .text('Here is a binary search implementation in Python:')
    .code(
      'python',
      `def binary_search(arr, target):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1`
    )
    .text('And the equivalent in JavaScript:')
    .code(
      'javascript',
      `function binarySearch(arr, target) {
  let left = 0, right = arr.length - 1;
  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return -1;
}`
    )
    .suggest(['Explain the algorithm', 'Show another example', 'Analyze complexity'])
    .send(jid);
}

export async function sendTableResponse(bot, jid) {
  await bot.ai()
    .title('Comparison')
    .text('Here is a feature comparison across plans:')
    .table([
      ['Feature',         'Free',   'Pro',        'Enterprise'],
      ['Messages/month',  '1,000',  '50,000',     'Unlimited'],
      ['AI Rich',         '✗',      '✓',          '✓'],
      ['Carousel',        '✗',      '✓',          '✓'],
      ['Custom bot name', '✗',      '✓',          '✓'],
      ['Support',         'Email',  'Priority',   'Dedicated'],
      ['Price',           'Free',   '$29/month',  'Custom'],
    ])
    .suggest(['See all features', 'Compare again', 'Contact sales'])
    .send(jid);
}

export async function sendImageResponse(bot, jid) {
  await bot.ai()
    .title('Image Generator')
    .text('Here are the generated images based on your prompt:')
    .image([
      'https://example.com/gen/image1.jpg',
      'https://example.com/gen/image2.jpg',
      'https://example.com/gen/image3.jpg',
    ])
    .suggest(['Generate more', 'Try different style', 'Download all'])
    .send(jid);
}

export async function sendVideoResponse(bot, jid) {
  await bot.ai()
    .title('Video Summary')
    .text('Here is a short clip related to your query:')
    .video('https://example.com/clip.mp4', { autoFill: true })
    .suggest(['Watch full video', 'Find similar', 'Share'])
    .send(jid);
}

export async function sendSourcedResponse(bot, jid) {
  await bot.ai()
    .title('Research Assistant')
    .text(
      'Large language models are trained on vast datasets using self-supervised learning. ' +
      'The transformer architecture, introduced in 2017, is the foundation for most modern LLMs.'
    )
    .source([
      [
        'https://arxiv.org/favicon.ico',
        'https://arxiv.org/abs/1706.03762',
        'Attention Is All You Need — Vaswani et al.',
      ],
      [
        'https://wikipedia.org/favicon.ico',
        'https://wikipedia.org/wiki/Large_language_model',
        'Wikipedia — Large language model',
      ],
    ])
    .suggest(['Explain transformers', 'More about training', 'Summarize differently'])
    .send(jid);
}

export async function sendProductResponse(bot, jid) {
  await bot.ai()
    .title('Shopping Assistant')
    .text('Based on your preferences, here are some recommendations:')
    .product([
      {
        image: 'https://example.com/products/headphones.jpg',
        title: 'Sony WH-1000XM5',
        price: '$349',
        currency: 'USD',
      },
      {
        image: 'https://example.com/products/earbuds.jpg',
        title: 'AirPods Pro (2nd Gen)',
        price: '$249',
        currency: 'USD',
      },
    ])
    .suggest(['Filter by price', 'Compare specs', 'See reviews'])
    .send(jid);
}

export async function sendForwardedResponse(bot, jid) {
  await bot.ai()
    .title('Forwarded Answer')
    .text('This response was forwarded from a previous session.')
    .send(jid, { forwarded: true });
}

export async function sendQuotedResponse(bot, jid, originalMessage) {
  await bot.ai()
    .title('Reply')
    .text('Here is the answer to your question:')
    .text('The quick brown fox jumps over the lazy dog.')
    .send(jid, { quoted: originalMessage });
}

// Demo — runs all examples in sequence
async function main(sock) {
  const bot = new Bot(sock);
  const jid = '1234567890@s.whatsapp.net';

  await sendTextResponse(bot, jid);
  await sendCodeResponse(bot, jid);
  await sendTableResponse(bot, jid);
  await sendImageResponse(bot, jid);
  await sendVideoResponse(bot, jid);
  await sendSourcedResponse(bot, jid);
  await sendProductResponse(bot, jid);
  await sendForwardedResponse(bot, jid);
}
