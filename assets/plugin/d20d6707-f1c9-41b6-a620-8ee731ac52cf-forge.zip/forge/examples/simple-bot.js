import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@kyyinfinite/baileys';
import { Bot } from '@kyyinfinite/forge';

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('auth');

  const sock = makeWASocket({ auth: state, printQRInTerminal: true });
  const bot = new Bot(sock);

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'close') {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) start();
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      '';

    if (text === 'ping') {
      await bot.text(jid, 'pong');
      return;
    }

    if (text === 'help') {
      await bot.text(
        jid,
        'Commands:\nping — check if the bot is alive\nhelp — this menu'
      );
      return;
    }

    await bot.react(jid, msg.key, '👋');
  });
}

start();
