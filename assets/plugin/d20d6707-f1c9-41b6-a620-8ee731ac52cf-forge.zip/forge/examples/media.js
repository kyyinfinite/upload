import { Bot, Toolkit } from '@kyyinfinite/forge';

export async function sendBasicMedia(bot, jid) {
  await bot.image(jid, 'https://example.com/photo.jpg', { caption: 'A photo' });
  await bot.video(jid, 'https://example.com/clip.mp4', { caption: 'A clip' });
  await bot.audio(jid, 'https://example.com/track.ogg');
  await bot.audio(jid, 'https://example.com/voice.ogg', { ptt: true });
  await bot.document(jid, 'https://example.com/report.pdf', { fileName: 'report.pdf' });
  await bot.sticker(jid, 'https://example.com/sticker.webp');
}

export async function sendFromBuffer(bot, jid) {
  const imageBuffer = await Toolkit.fetchBuffer('https://example.com/photo.jpg');
  await bot.image(jid, imageBuffer, { caption: 'From buffer' });
}

export async function sendResizedImage(bot, jid) {
  const rawBuffer = await Toolkit.fetchBuffer('https://example.com/photo.jpg');
  const resized = await Toolkit.resize(rawBuffer, 800, 600);
  await bot.image(jid, resized, { caption: 'Resized to 800×600' });
}

export async function sendLocation(bot, jid) {
  await bot.location(jid, 37.7749, -122.4194, {
    name: 'San Francisco, CA',
    address: 'San Francisco, California, USA',
  });
}

export async function sendContact(bot, jid) {
  const vcard = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    'FN:John Doe',
    'TEL;TYPE=CELL:+15550001234',
    'EMAIL:john@example.com',
    'END:VCARD',
  ].join('\n');

  await bot.contact(jid, vcard, { name: 'John Doe' });
}

export async function sendReply(bot, jid, quotedMessage) {
  await bot.reply(jid, 'Got your message!', quotedMessage);
}

export async function sendReaction(bot, jid, messageKey) {
  await bot.react(jid, messageKey, '🔥');
}

export async function useToolkit(sock) {
  // Fetch a buffer
  const buf = await Toolkit.fetchBuffer('https://example.com/photo.jpg');

  // Resize it
  const resized = await Toolkit.resize(buf, 300, 300);

  // Upload to WhatsApp CDN and get a CDN URL
  const cdnUrl = await Toolkit.toUrl(sock, resized, 'image');
  console.log('CDN URL:', cdnUrl);

  // Resolve any media (URL / Buffer / base64 / array) to a CDN URL
  const resolved = await Toolkit.resolveMedia(
    sock,
    'https://example.com/photo.jpg',
    'image',
    { result: 'url' }
  );
  console.log('Resolved:', resolved);

  // Get MP4 metadata
  const videoBuffer = await Toolkit.fetchBuffer('https://example.com/clip.mp4');
  const duration = Toolkit.getMp4Duration(videoBuffer);
  const preview = await Toolkit.getMp4Preview(videoBuffer, { result: 'buffer' });
  console.log('Duration:', duration, 'seconds');
  console.log('Preview:', preview.length, 'bytes');
}

// Demo
async function main(sock) {
  const bot = new Bot(sock);
  const jid = '1234567890@s.whatsapp.net';

  await sendBasicMedia(bot, jid);
  await sendFromBuffer(bot, jid);
  await sendResizedImage(bot, jid);
  await sendLocation(bot, jid);
  await sendContact(bot, jid);
  await useToolkit(sock);
}
